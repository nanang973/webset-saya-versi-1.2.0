<?php
/**
 * FOOTER - Bagian Bawah Website
 */

// Get profile data untuk social media links
$profile = $conn->query("SELECT * FROM profile LIMIT 1")->fetch_assoc();
?>
    <!-- FOOTER -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><?php echo htmlspecialchars($profile['name'] ?? 'Nanang Khasan Bisri'); ?></h3>
                    <p>Web Developer | IoT Developer</p>
                </div>
                
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="<?php echo BASE_URL; ?>">Home</a></li>
                        <li><a href="<?php echo BASE_URL; ?>pages/about.php">Tentang</a></li>
                        <li><a href="<?php echo BASE_URL; ?>pages/portfolio.php">Portofolio</a></li>
                        <li><a href="<?php echo BASE_URL; ?>pages/blog.php">Blog</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Hubungi Kami</h4>
                    <div class="social-links">
                        <?php if (!empty($profile['phone'])): ?>
                            <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $profile['phone']); ?>" title="WhatsApp" target="_blank"><i class="fab fa-whatsapp"></i></a>
                        <?php endif; ?>
                        <?php if (!empty($profile['instagram_url'])): ?>
                            <a href="<?php echo htmlspecialchars($profile['instagram_url']); ?>" title="Instagram" target="_blank"><i class="fab fa-instagram"></i></a>
                        <?php endif; ?>
                        <?php if (!empty($profile['tiktok_url'])): ?>
                            <a href="<?php echo htmlspecialchars($profile['tiktok_url']); ?>" title="TikTok" target="_blank"><i class="fab fa-tiktok"></i></a>
                        <?php endif; ?>
                        <?php if (!empty($profile['telegram_url'])): ?>
                            <a href="<?php echo htmlspecialchars($profile['telegram_url']); ?>" title="Telegram" target="_blank"><i class="fab fa-telegram"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2025 <?php echo htmlspecialchars($profile['name'] ?? 'Nanang Khasan Bisri'); ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <!-- Scripts -->
    <script src="<?php echo ASSETS_URL; ?>js/main.js"></script>
</body>
</html>
