<?php
/**
 * HEADER - Navigasi Utama Website
 */
$current_page = basename($_SERVER['PHP_SELF']);

// Ensure profile data is available for the logo
if (!isset($profile)) {
    $profile_result = $conn->query("SELECT * FROM profile LIMIT 1");
    if ($profile_result && $profile_result->num_rows > 0) {
        $profile = $profile_result->fetch_assoc();
    } else {
        $profile = [];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?>Nanang Khasan Bisri | Portfolio</title>
    <meta name="description" content="Portfolio pribadi Nanang Khasan Bisri - Mahasiswa Teknik Informatika, IoT Developer, Web Developer">
    
    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/style.css">
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-brand">
                <a href="<?php echo BASE_URL; ?>" style="text-decoration: none;">
                    <?php if (!empty($profile['profile_picture'])): ?>
                        <img src="<?php echo htmlspecialchars(BASE_URL . $profile['profile_picture']); ?>" alt="Logo" class="nav-logo" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 2px solid var(--primary);">
                    <?php else: ?>
                        <div class="nav-logo-placeholder" style="width: 40px; height: 40px; border-radius: 50%; background: rgba(59, 130, 246, 0.1); display: flex; align-items: center; justify-content: center; color: var(--primary); border: 2px solid var(--primary);">
                            <i class="fas fa-code"></i>
                        </div>
                    <?php endif; ?>
                </a>
            </div>
            
            <ul class="nav-menu" id="navMenu">
                <li><a href="<?php echo BASE_URL; ?>" class="nav-link <?php echo $current_page == 'index.php' ? 'active' : ''; ?>">Home</a></li>
                <li><a href="<?php echo BASE_URL; ?>pages/about.php" class="nav-link <?php echo $current_page == 'about.php' ? 'active' : ''; ?>">Tentang</a></li>
                <li><a href="<?php echo BASE_URL; ?>pages/portfolio.php" class="nav-link <?php echo $current_page == 'portfolio.php' ? 'active' : ''; ?>">Portofolio</a></li>
                <li><a href="<?php echo BASE_URL; ?>pages/blog.php" class="nav-link <?php echo $current_page == 'blog.php' ? 'active' : ''; ?>">Blog</a></li>
                <li><a href="<?php echo BASE_URL; ?>pages/contact.php" class="nav-link <?php echo $current_page == 'contact.php' ? 'active' : ''; ?>">Kontak</a></li>
            </ul>
            
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>
</body>
</html>
