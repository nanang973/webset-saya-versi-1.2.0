<?php
/**
 * KONFIGURASI DATABASE & APLIKASI
 * Website Portofolio Nanang Khasan Bisri
 */

// Database Configuration
// UPDATE INI DENGAN CREDENTIALS HOSTING ANDA
define('DB_HOST', 'localhost');
define('DB_USER', 'ioigolhs_nanang');  // Ganti dengan username hosting Anda
define('DB_PASS', 'p(s.2NGu2s?^^H^N');  // Ganti dengan password database Anda
define('DB_NAME', 'ioigolhs_portofolio');  // Ganti dengan nama database Anda

// Koneksi Database
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Set charset UTF-8
$conn->set_charset("utf8");

// Base URL - Auto-detect mode (LOCAL vs PRODUCTION)
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];

// Deteksi mode - LOCAL jika localhost, 127.0.0.1, atau IP lokal (192.168.x.x, 10.0.x.x, dll)
$is_local = preg_match('/^(localhost|127\.0\.0\.1|192\.168\.|10\.|172\.)/i', $host);

if ($is_local) {
    // MODE LOKAL - Deteksi folder webset
    $base_dir = basename(dirname(__DIR__));
    
    // Jika berada di folder dengan "webset" dalam nama
    if (stripos($base_dir, 'webset') !== false) {
        define('BASE_URL', $protocol . '://' . $host . '/' . $base_dir . '/');
    } else {
        // Fallback: deteksi dari SCRIPT_NAME
        $script_path = dirname($_SERVER['SCRIPT_NAME']);
        if ($script_path === '/' || $script_path === '\\') {
            $script_path = '';
        }
        define('BASE_URL', $protocol . '://' . $host . $script_path . '/');
    }
} else {
    // MODE HOSTING - Hardcoded
    // ===== PRODUCTION SETTINGS =====
    // Ubah sesuai domain hosting Anda
    define('BASE_URL', 'https://nanangkhasan.my.id/');
    // ==============================
}

define('ASSETS_URL', BASE_URL . 'assets/');

// Timezone
date_default_timezone_set('Asia/Jakarta');

// Session start
session_start();

// SECURITY HEADERS
// Prevent clickjacking
header('X-Frame-Options: SAMEORIGIN');
// Prevent MIME sniffing
header('X-Content-Type-Options: nosniff');
// XSS Protection
header('X-XSS-Protection: 1; mode=block');
// Content Security Policy
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://fonts.googleapis.com; style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com; img-src 'self' data: https:; connect-src 'self'");
// Referrer Policy
header('Referrer-Policy: strict-origin-when-cross-origin');

// HTTPS Enforcement (allow localhost untuk development)
$is_localhost = in_array($_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1', 'localhost:80']);
if (!$is_localhost && $_SERVER['SERVER_PORT'] != 443 && empty($_SERVER['HTTPS'])) {
    $redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('HTTP/1.1 301 Moved Permanently');
    header('Location: ' . $redirect);
    exit;
}

// RATE LIMITING - Simple file-based
function checkRateLimit($identifier, $limit = 5, $window = 60) {
    $rate_limit_file = sys_get_temp_dir() . '/rate_limit_' . md5($identifier) . '.txt';
    $current_time = time();
    if (file_exists($rate_limit_file)) {
        $data = json_decode(file_get_contents($rate_limit_file), true);
        $request_times = $data['times'] ?? [];
        $request_times = array_filter($request_times, function($t) use ($current_time, $window) {
            return ($current_time - $t) < $window;
        });
        if (count($request_times) >= $limit) {
            return false;
        }
        $request_times[] = $current_time;
    } else {
        $request_times = [$current_time];
    }
    file_put_contents($rate_limit_file, json_encode(['times' => array_values($request_times)]));
    return true;
}

?>
