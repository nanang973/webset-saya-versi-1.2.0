<?php
/**
 * Helper function untuk merender konten blog yang disimpan dalam format JSON blocks
 */
function renderBlogContent($content) {
    // Jika content adalah string, coba decode dari JSON
    if (is_string($content)) {
        $decoded = json_decode($content, true);
        if (is_array($decoded)) {
            $content = $decoded;
        } else {
            // Jika bukan JSON, tampilkan sebagai plain text
            return htmlspecialchars($content);
        }
    }

    // Jika content bukan array, return sebagai plain text
    if (!is_array($content)) {
        return htmlspecialchars($content);
    }

    $html = '';

    foreach ($content as $block) {
        $type = $block['type'] ?? '';
        $blockContent = $block['content'] ?? [];

        switch($type) {
            case 'heading':
                $level = htmlspecialchars($blockContent['level'] ?? 'h2');
                $text = htmlspecialchars($blockContent['text'] ?? '');
                $html .= "<" . $level . ">" . $text . "</" . $level . ">";
                break;

            case 'paragraph':
                $text = $blockContent['text'] ?? '';
                $html .= "<p>" . nl2br(htmlspecialchars($text)) . "</p>";
                break;

            case 'image':
                $url = htmlspecialchars($blockContent['url'] ?? '');
                if ($url) {
                    $html .= '<figure style="margin: 30px 0; text-align: center;">';
                    $html .= '<img src="' . $url . '" alt="Article image" style="max-width: 100%; height: auto; border-radius: var(--radius-lg);">';
                    $html .= '</figure>';
                }
                break;

            case 'quote':
                $text = htmlspecialchars($blockContent['text'] ?? '');
                $html .= '<blockquote style="border-left: 4px solid var(--primary); padding-left: 20px; margin: 20px 0; font-style: italic; color: var(--text-muted);">' . nl2br($text) . '</blockquote>';
                break;

            case 'code':
                $text = htmlspecialchars($blockContent['text'] ?? '');
                $html .= '<pre style="background: var(--bg-dark); padding: 15px; border-radius: var(--radius-lg); overflow-x: auto;"><code>' . nl2br($text) . '</code></pre>';
                break;

            case 'video':
                $url = htmlspecialchars($blockContent['url'] ?? '');
                if ($url) {
                    $html .= '<div style="margin: 30px 0; position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: var(--radius-lg);"><iframe style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none;" src="' . $url . '" allowfullscreen></iframe></div>';
                }
                break;

            case 'list':
                $style = $blockContent['style'] ?? 'unordered';
                $items = $blockContent['items'] ?? [];
                
                // Fallback: parse dari text jika items kosong
                if (empty($items) && !empty($blockContent['text'])) {
                    $items = array_filter(array_map('trim', explode("\n", $blockContent['text'])));
                }
                
                if (!empty($items)) {
                    $tag = $style === 'ordered' ? 'ol' : 'ul';
                    $html .= '<' . $tag . ' style="margin-left: 20px; margin-bottom: 15px;">';
                    foreach ($items as $item) {
                        $html .= '<li>' . htmlspecialchars($item) . '</li>';
                    }
                    $html .= '</' . $tag . '>';
                }
                break;

            case 'spacer':
                $height = intval($blockContent['height'] ?? 20);
                $html .= '<div style="height: ' . $height . 'px;"></div>';
                break;

            default:
                // Unknown block type
                break;
        }
    }

    return $html;
}
