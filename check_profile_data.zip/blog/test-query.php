<?php
require_once '../includes/config.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Test Blog Query</title>
    <style>
        body { font-family: monospace; background: #f0f0f0; padding: 20px; }
        pre { background: white; padding: 15px; border-radius: 5px; overflow-x: auto; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <h1>Test Blog Query</h1>";

// Test query
$query = "SELECT * FROM blog_posts WHERE status = 'published' ORDER BY created_at DESC";
$result = $conn->query($query);
$posts = $result->fetch_all(MYSQLI_ASSOC);

echo "<h2>Query Results:</h2>";
echo "<pre>";
echo "Query: " . $query . "\n\n";
echo "Total posts: " . count($posts) . "\n\n";

foreach ($posts as $i => $post) {
    echo "Post " . ($i+1) . ":\n";
    echo "  ID: {$post['id']}\n";
    echo "  Title: {$post['title']}\n";
    echo "  Category: {$post['category']}\n";
    echo "  Status: {$post['status']}\n";
    echo "  Created: {$post['created_at']}\n\n";
}

echo "</pre>";

echo "<h2 class='success'>✓ Test selesai - lihat hasil di atas</h2>";
echo "<p><a href='../blog/index.php'>Kembali ke Blog Page</a></p>";

echo "</body></html>";
?>
