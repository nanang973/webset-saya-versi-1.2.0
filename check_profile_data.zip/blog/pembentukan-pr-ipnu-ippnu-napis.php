<?php
require_once '../includes/config.php';
$page_title = 'Pembentukan PR IPNU IPPNU Desa Napis';
include '../includes/header.php';
?>

    <style>
        /* ============================================
           ARTICLE HERO SECTION
           ============================================ */
        .article-hero {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(30, 58, 138, 0.1) 100%);
            border-bottom: 2px solid var(--primary);
            padding: 60px var(--spacing-md);
            margin-bottom: 40px;
        }

        .hero-content {
            animation: fadeInDown 0.8s ease;
        }

        .article-category {
            display: inline-block;
            background: var(--primary);
            color: white;
            padding: 6px 14px;
            border-radius: var(--radius-md);
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 1rem;
        }

        .article-hero h1 {
            font-size: 2.5rem;
            color: var(--text-light);
            margin-bottom: 1rem;
            line-height: 1.3;
        }

        .article-meta {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            color: var(--text-muted);
            font-size: 0.95rem;
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .meta-item i {
            color: var(--primary);
        }

        /* ============================================
           ARTICLE CONTENT
           ============================================ */
        .article-container {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-xl);
            padding: 40px;
            margin-bottom: 60px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        }

        .article-content {
            font-size: 1.05rem;
            line-height: 1.8;
            color: var(--text-light);
        }

        .article-content p {
            margin-bottom: 1.5rem;
            text-align: justify;
        }

        .article-content p:first-letter {
            font-weight: 600;
        }

        .highlight-box {
            background: rgba(59, 130, 246, 0.1);
            border-left: 4px solid var(--primary);
            padding: 20px;
            border-radius: var(--radius-lg);
            margin: 30px 0;
            font-weight: 500;
        }

        .highlight-box strong {
            color: var(--primary);
        }

        /* ============================================
           ARTICLE FOOTER
           ============================================ */
        .article-footer {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-xl);
            padding: 30px 40px;
            margin-bottom: 60px;
            border-top: 3px solid var(--primary);
        }

        .author-info {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 20px;
        }

        .author-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: white;
        }

        .author-details h3 {
            color: var(--primary);
            margin-bottom: 5px;
        }

        .author-details p {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .share-section {
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
            margin-top: 20px;
        }

        .share-title {
            font-weight: 600;
            margin-bottom: 12px;
            color: var(--text-light);
        }

        .share-buttons {
            display: flex;
            gap: 10px;
        }

        .share-btn {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(59, 130, 246, 0.1);
            color: var(--primary);
            border: 1px solid var(--border-color);
            border-radius: 50%;
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
        }

        .share-btn:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-3px);
        }

        /* ============================================
           RELATED ARTICLES
           ============================================ */
        .related-section {
            margin-bottom: 60px;
        }

        .section-title {
            font-size: 1.8rem;
            color: var(--text-light);
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--primary);
            display: inline-block;
        }

        .related-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        .related-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-lg);
            padding: 20px;
            transition: var(--transition);
        }

        .related-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary);
            box-shadow: 0 10px 30px rgba(59, 130, 246, 0.1);
        }

        .related-card h4 {
            color: var(--primary);
            margin-bottom: 8px;
            font-size: 0.95rem;
        }

        .related-card a {
            color: var(--text-light);
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }

        .related-card a:hover {
            color: var(--primary);
        }

        /* ============================================
           NEWSLETTER SECTION
           ============================================ */
        .newsletter-section {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.2) 0%, rgba(30, 58, 138, 0.15) 100%);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-xl);
            padding: 50px 40px;
            text-align: center;
            margin-bottom: 60px;
        }

        .newsletter-section h2 {
            font-size: 1.8rem;
            margin-bottom: 12px;
            color: var(--text-light);
        }

        .newsletter-section p {
            color: var(--text-muted);
            margin-bottom: 25px;
        }

        .newsletter-form {
            display: flex;
            gap: 10px;
            max-width: 500px;
            margin: 0 auto;
        }

        .newsletter-form input {
            flex: 1;
            padding: 12px 16px;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-lg);
            color: var(--text-light);
            font-family: 'Poppins', sans-serif;
        }

        .newsletter-form input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 15px rgba(59, 130, 246, 0.3);
        }

        .newsletter-form button {
            padding: 12px 24px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: var(--radius-lg);
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            white-space: nowrap;
        }

        .newsletter-form button:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }

        /* ============================================
           BACK TO BLOG BUTTON
           ============================================ */
        .back-to-blog {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 40px;
            transition: var(--transition);
        }

        .back-to-blog:hover {
            transform: translateX(-5px);
        }

        /* ============================================
           TOAST NOTIFICATION
           ============================================ */
        .toast-notification {
            position: fixed;
            bottom: -100px;
            left: 50%;
            transform: translateX(-50%);
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            color: var(--text-light);
            padding: 16px 24px;
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 1000;
            transition: bottom 0.3s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        .toast-notification.show {
            bottom: 20px;
        }

        .toast-notification i {
            color: var(--success);
            font-size: 1.2rem;
        }

        /* ============================================
           ANIMATIONS
           ============================================ */
        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* ============================================
           RESPONSIVE DESIGN
           ============================================ */
        @media (max-width: 768px) {
            .article-hero {
                padding: 40px var(--spacing-md);
            }

            .article-hero h1 {
                font-size: 1.8rem;
            }

            .article-container {
                padding: 25px;
            }

            .article-footer {
                padding: 25px;
            }

            .author-info {
                flex-direction: column;
                text-align: center;
            }

            .article-meta {
                flex-direction: column;
                gap: 10px;
            }

            .newsletter-form {
                flex-direction: column;
            }

            .newsletter-form button {
                width: 100%;
            }

            .related-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 480px) {
            .article-hero h1 {
                font-size: 1.5rem;
            }

            .article-container {
                padding: 16px;
            }

            .newsletter-section {
                padding: 30px 20px;
            }
        }
    </style>

    <!-- Article Hero -->
    <section class="article-hero">
        <div class="container">
            <div class="hero-content">
                <span class="article-category">Berita</span>
                <h1>Pembentukan Pimpinan Ranting (PR) IPNU IPPNU Desa Napis</h1>
                <div class="article-meta">
                    <div class="meta-item">
                        <i class="fas fa-calendar"></i>
                        <span>10 Januari 2026</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>Tambakrejo</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-user"></i>
                        <span>Nanang Khasan Bisri</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-clock"></i>
                        <span>8 min baca</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Article Container -->
    <div class="container">
        <a href="../pages/blog.php" class="back-to-blog">
            <i class="fas fa-arrow-left"></i>
            Kembali ke Blog
        </a>

        <!-- Article Content -->
        <article class="article-container">
            <div class="article-content">
                <p>
                    <strong>Tambakrejo, 10 Januari 2026</strong> – Pimpinan Anak Cabang (PAC) IPNU IPPNU Kecamatan Tambakrejo sukses melaksanakan kegiatan Pembentukan Pimpinan Ranting (PR) IPNU IPPNU Desa Napis. Kegiatan ini bertempat di Mushola Al-Mudtaqin, Desa Napis, pada Sabtu, 10 Januari 2026.
                </p>

                <p>
                    Kegiatan pembentukan ini merupakan langkah awal dalam memperkuat organisasi IPNU dan IPPNU di tingkat ranting. Acara diawali dengan sambutan Ketua PAC IPNU IPPNU Kecamatan Tambakrejo, yang menyampaikan tentang apa itu IPNU IPPNU serta menjelaskan tentang kegiatan apa saja yang biasa dilakukan di tingkatan ranting.
                </p>

                <div class="highlight-box">
                    <strong>💡 Dukungan Penuh dari Tokoh Masyarakat</strong><br>
                    Bapak Kiai Kahar selaku Ketua Tanfidz Desa Napis memberikan sambutan dan dukungan penuh terhadap terbentuknya Pimpinan Ranting IPNU IPPNU Desa Napis. Beliau memberikan motivasi dan arahan kepada para peserta pimpinan ranting.
                </div>

                <p>
                    Agenda utama kemudian dilanjutkan dengan pemilihan Ketua Pimpinan Ranting IPNU dan IPPNU Desa Napis oleh para pengurus PAC. Dari hasil pemilihan tersebut, terpilih:
                </p>

                <div class="highlight-box">
                    <strong>📋 Hasil Pemilihan Pimpinan Ranting</strong><br>
                    <strong>Ketua PR IPNU Desa Napis:</strong> M. Denis Saputra<br>
                    <strong>Ketua PR IPPNU Desa Napis:</strong> Evita Cahaya
                </div>

                <p>
                    Setelah seluruh rangkaian acara inti selesai, kegiatan ditutup dengan bakar-bakar sosis bersama. Kegiatan ini menjadi momen kebersamaan yang hangat untuk mempererat rasa kekeluargaan dan solidaritas antar kader serta peserta yang hadir.
                </p>

                <p>
                    Dengan terbentuknya Pimpinan Ranting IPNU IPPNU Desa Napis, diharapkan ke depan organisasi ini dapat menjadi penggerak kegiatan pelajar yang aktif, solid, dan berkontribusi positif bagi masyarakat Desa Napis.
                </p>
            </div>
        </article>

        <!-- Article Footer -->
        <div class="article-footer">
            <div class="author-info">
                <div class="author-avatar">
                    <i class="fas fa-pen-fancy"></i>
                </div>
                <div class="author-details">
                    <h3>Nanang Khasan Bisri</h3>
                    <p>Penulis & Full Stack Web Developer</p>
                    <p style="font-size: 0.85rem; margin-top: 5px;">Dokumentasi: Tim Media PAC IPNU IPPNU Tambakrejo</p>
                </div>
            </div>

            <div class="share-section">
                <div class="share-title">Bagikan Artikel:</div>
                <div class="share-buttons">
                    <a href="#" class="share-btn" title="Bagikan ke Facebook" onclick="shareArticle('facebook')">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="#" class="share-btn" title="Bagikan ke Twitter" onclick="shareArticle('twitter')">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="share-btn" title="Bagikan ke WhatsApp" onclick="shareArticle('whatsapp')">
                        <i class="fab fa-whatsapp"></i>
                    </a>
                    <a href="#" class="share-btn" title="Copy Link" onclick="copyLink()">
                        <i class="fas fa-link"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Newsletter Section -->
        <section class="newsletter-section">
            <h2>Dapatkan Update Berita Terbaru</h2>
            <p>Subscribe ke newsletter kami dan dapatkan artikel dan berita menarik lainnya</p>
            <form class="newsletter-form" onsubmit="subscribeNewsletter(event)">
                <input type="email" placeholder="Masukkan email Anda..." required>
                <button type="submit">Subscribe</button>
            </form>
        </section>

        <!-- Related Articles -->
        <section class="related-section">
            <h2 class="section-title">Artikel Terkait</h2>
            <div class="related-grid">
                <div class="related-card">
                    <h4>Tutorial</h4>
                    <a href="../pages/blog.php">Memulai dengan PHP Modern: Framework Laravel</a>
                </div>
                <div class="related-card">
                    <h4>Tips & Trik</h4>
                    <a href="../pages/blog.php">7 Tips Meningkatkan Performa JavaScript</a>
                </div>
                <div class="related-card">
                    <h4>Berita</h4>
                    <a href="../pages/blog.php">PHP 8.3 Dirilis dengan Fitur-Fitur Canggih Baru</a>
                </div>
            </div>
        </section>
    </div>

    <script>
        // Show Toast Notification
        function showToast(message) {
            const toast = document.createElement('div');
            toast.className = 'toast-notification';
            toast.innerHTML = `<i class="fas fa-check-circle"></i><span>${message}</span>`;
            document.body.appendChild(toast);
            setTimeout(() => toast.classList.add('show'), 10);
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        // Share Article
        function shareArticle(platform) {
            const url = window.location.href;
            const title = 'Pembentukan Pimpinan Ranting (PR) IPNU IPPNU Desa Napis';
            let shareUrl = '';

            switch(platform) {
                case 'facebook':
                    shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
                    break;
                case 'twitter':
                    shareUrl = `https://twitter.com/intent/tweet?url=${url}&text=${title}`;
                    break;
                case 'whatsapp':
                    shareUrl = `https://wa.me/?text=${title} ${url}`;
                    break;
            }

            if (shareUrl) {
                window.open(shareUrl, '_blank');
            }
        }

        // Copy Link
        function copyLink() {
            const url = window.location.href;
            navigator.clipboard.writeText(url).then(() => {
                showToast('✓ Link telah disalin ke clipboard!');
            });
        }

        // Newsletter Subscribe
        function subscribeNewsletter(event) {
            event.preventDefault();
            const form = event.target;
            const btn = form.querySelector('button');
            const originalText = btn.innerHTML;

            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mengirim...';
            btn.disabled = true;

            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.disabled = false;
                form.reset();
                showToast('✓ Terima kasih! Anda sudah subscribe ke newsletter kami.');
            }, 1200);
        }

        // Smooth scroll to top on load
        window.scrollTo(0, 0);
    </script>

<?php include '../includes/footer.php'; ?>
