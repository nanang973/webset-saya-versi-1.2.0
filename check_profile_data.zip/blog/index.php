<?php
require_once '../includes/config.php';
require_once '../includes/blog-renderer.php';

$page_title = 'Blog';
include '../includes/header.php';

// Get blog posts dari database
$query = "SELECT * FROM blog_posts WHERE status = 'published' ORDER BY created_at DESC";
$result = $conn->query($query);
$posts = $result->fetch_all(MYSQLI_ASSOC);

// Helper function untuk extract gambar dari JSON content
function extractImageFromContent($content) {
    if (is_string($content)) {
        $decoded = json_decode($content, true);
        if (is_array($decoded)) {
            foreach ($decoded as $block) {
                if ($block['type'] === 'image' && !empty($block['content']['url'])) {
                    return $block['content']['url'];
                }
            }
        }
    }
    return null;
}

// Helper function untuk extract teks preview dari JSON content
function extractTextPreview($content, $length = 150) {
    if (is_string($content)) {
        $decoded = json_decode($content, true);
        if (is_array($decoded)) {
            foreach ($decoded as $block) {
                if ($block['type'] === 'paragraph' && !empty($block['content']['text'])) {
                    $text = $block['content']['text'];
                    if (strlen($text) > $length) {
                        return substr($text, 0, $length);
                    }
                    return $text;
                }
            }
        }
    }
    return '';
}
?>

<style>
    .blog-hero {
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(30, 58, 138, 0.1) 100%);
        border-bottom: 2px solid var(--primary);
        padding: 60px var(--spacing-md);
        margin-bottom: 40px;
        text-align: center;
    }

    .blog-hero h1 {
        font-size: 2.5rem;
        color: var(--text-light);
        margin-bottom: 12px;
    }

    .blog-hero p {
        color: var(--text-muted);
        font-size: 1.1rem;
    }

    .blog-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 25px;
        margin-bottom: 60px;
    }

    .blog-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-lg);
        overflow: hidden;
        transition: var(--transition);
    }

    .blog-card:hover {
        transform: translateY(-5px);
        border-color: var(--primary);
        box-shadow: 0 10px 30px rgba(59, 130, 246, 0.1);
    }

    .blog-card-header {
        height: 200px;
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(30, 58, 138, 0.15));
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3rem;
        color: var(--primary);
    }

    .blog-card-body {
        padding: 20px;
    }

    .blog-category {
        display: inline-block;
        background: rgba(59, 130, 246, 0.2);
        color: var(--primary);
        padding: 4px 10px;
        border-radius: var(--radius-sm);
        font-size: 0.8rem;
        font-weight: 600;
        margin-bottom: 10px;
    }

    .blog-card h3 {
        color: var(--text-light);
        margin-bottom: 10px;
        font-size: 1.2rem;
        line-height: 1.4;
    }

    .blog-card p {
        color: var(--text-muted);
        font-size: 0.95rem;
        margin-bottom: 15px;
        line-height: 1.6;
    }

    .blog-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: 15px;
        border-top: 1px solid var(--border-color);
        font-size: 0.85rem;
        color: var(--text-muted);
    }

    .blog-link {
        color: var(--primary);
        text-decoration: none;
        font-weight: 600;
        transition: var(--transition);
    }

    .blog-link:hover {
        gap: 5px;
    }

    @media (max-width: 768px) {
        .blog-hero h1 {
            font-size: 1.8rem;
        }

        .blog-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<!-- Blog Hero -->
<section class="blog-hero">
    <div class="container">
        <h1>Blog & Artikel</h1>
        <p>Berbagi pengalaman, tutorial, dan insights tentang teknologi</p>
    </div>
</section>

<!-- Blog Grid -->
<div class="container">
    <?php if (empty($posts)): ?>
        <div style="text-align: center; padding: 60px 20px; color: var(--text-muted);">
            <i class="fas fa-inbox" style="font-size: 3rem; color: var(--primary); margin-bottom: 20px; display: block;"></i>
            <p>Belum ada artikel. Kembali lagi nanti!</p>
        </div>
    <?php else: ?>
    <div class="blog-grid">
        <?php foreach ($posts as $post): 
            $image = extractImageFromContent($post['content']);
            if (empty($image) && !empty($post['featured_image'])) {
                $image = $post['featured_image'];
            }
            if (empty($image) && !empty($post['image'])) {
                $image = $post['image'];
            }
            
            $description = !empty($post['description']) 
                ? $post['description'] 
                : extractTextPreview($post['content'], 150);
        ?>
        <!-- Blog Card -->
        <article class="blog-card">
            <div class="blog-card-header">
                <?php if (!empty($image)): ?>
                    <img src="<?php echo htmlspecialchars($image); ?>" 
                         alt="<?php echo htmlspecialchars($post['title']); ?>"
                         style="width: 100%; height: 100%; object-fit: cover;"
                         onerror="this.style.display='none'; this.parentElement.innerHTML='<i class=\"fas fa-newspaper\"></i>';">
                <?php else: ?>
                    <i class="fas fa-newspaper"></i>
                <?php endif; ?>
            </div>
            <div class="blog-card-body">
                <span class="blog-category"><?php echo htmlspecialchars($post['category']); ?></span>
                <h3><?php echo htmlspecialchars($post['title']); ?></h3>
                <p><?php echo htmlspecialchars($description); ?>...</p>
                <div class="blog-meta">
                    <span><i class="fas fa-calendar"></i> <?php echo date('d M Y', strtotime($post['created_at'])); ?></span>
                    <a href="<?php echo BASE_URL; ?>pages/blog-detail.php?id=<?php echo $post['id']; ?>" class="blog-link">Baca Selengkapnya →</a>
                </div>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
