<?php
/**
 * ADMIN TOPBAR - Include di semua halaman admin untuk hamburger button
 * Gunakan: <?php include 'topbar.php'; ?>
 */
$admin_username = $_SESSION['admin_username'] ?? 'Admin';
?>
<!-- TOP BAR -->
<div class="admin-topbar">
    <div class="topbar-left">
        <button id="sidebarToggle" class="sidebar-toggle">
            <i class="fas fa-bars"></i>
        </button>
        <h1><?php echo isset($page_title) ? $page_title : 'Admin'; ?></h1>
    </div>
    
    <div class="topbar-right">
        <span class="welcome-text">Selamat datang, <strong><?php echo htmlspecialchars($admin_username); ?></strong></span>
        <div class="user-menu">
            <img src="https://thumbs.dreamstime.com/b/icon-profile-circle-shadow-color-dark-blue-background-color-white-icon-profile-circle-shadow-color-dark-blue-194699287.jpg" alt="Avatar" class="user-avatar">
        </div>
    </div>
</div>
