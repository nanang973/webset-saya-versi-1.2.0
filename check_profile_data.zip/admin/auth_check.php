<?php
/**
 * AUTH CHECK - Session security validation
 * Include this di semua halaman admin yang memerlukan autentikasi
 */

// Session timeout (30 minutes)
$session_timeout = 30 * 60;

// Check jika session sudah ada
if (!isset($_SESSION['admin_id'])) {
    header("Location: " . ASSETS_URL . "../admin/login.php");
    exit;
}

// Check session timeout
if (isset($_SESSION['last_activity'])) {
    $inactive = time() - $_SESSION['last_activity'];
    if ($inactive > $session_timeout) {
        session_destroy();
        header("Location: login.php?timeout=1");
        exit;
    }
}

// Update last activity time
$_SESSION['last_activity'] = time();

// Session fingerprint validation (prevent session hijacking)
$user_agent = md5($_SERVER['HTTP_USER_AGENT']);
if (isset($_SESSION['user_agent'])) {
    if ($_SESSION['user_agent'] !== $user_agent) {
        session_destroy();
        header("Location: login.php?error=invalid_session");
        exit;
    }
} else {
    $_SESSION['user_agent'] = $user_agent;
}

// IP validation (optional - uncomment if needed)
// $user_ip = md5($_SERVER['REMOTE_ADDR']);
// if (isset($_SESSION['user_ip'])) {
//     if ($_SESSION['user_ip'] !== $user_ip) {
//         session_destroy();
//         header("Location: login.php?error=invalid_ip");
//         exit;
//     }
// } else {
//     $_SESSION['user_ip'] = $user_ip;
// }

// Prevent direct access dari browser history atau back button
header("Cache-Control: no-cache, no-store, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
?>
