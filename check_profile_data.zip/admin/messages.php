<?php
require_once '../includes/config.php';
require_once 'auth_check.php';

$page_title = "Pesan Masuk";
$message = '';
$error = '';

// Handle mark as read
if (isset($_GET['mark_read'])) {
    $id = intval($_GET['mark_read']);
    if ($conn->query("UPDATE contact_messages SET is_read = 1 WHERE id = $id")) {
        $message = "Pesan ditandai sudah dibaca";
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($conn->query("DELETE FROM contact_messages WHERE id = $id")) {
        $message = "Pesan berhasil dihapus";
    } else {
        $error = "Error: " . $conn->error;
    }
}

// Get all messages
$query = "SELECT id, name, email, subject, message, created_at, is_read FROM contact_messages ORDER BY created_at DESC";
$result = $conn->query($query);
$messages = $result->fetch_all(MYSQLI_ASSOC);

// Count unread messages
$unread_count = $conn->query("SELECT COUNT(*) as count FROM contact_messages WHERE is_read = 0")->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/style.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/admin.css">
    <style>
        .messages-list {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1rem;
        }
        
        .message-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 1.5rem;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .message-card:hover {
            border-color: var(--primary);
            box-shadow: 0 4px 12px rgba(14, 165, 233, 0.1);
        }
        
        .message-card.unread {
            background: linear-gradient(135deg, rgba(14, 165, 233, 0.05) 0%, rgba(14, 165, 233, 0.02) 100%);
            border-left: 4px solid var(--primary);
        }
        
        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 1rem;
        }
        
        .message-from {
            flex: 1;
        }
        
        .message-from h3 {
            margin: 0 0 0.5rem 0;
            font-size: 1.1rem;
            color: #fff;
        }
        
        .message-email {
            font-size: 0.9rem;
            color: #999;
            text-decoration: none;
        }
        
        .message-email:hover {
            color: var(--primary);
        }
        
        .message-date {
            color: #666;
            font-size: 0.85rem;
            text-align: right;
        }
        
        .message-unread-badge {
            display: inline-block;
            background: var(--primary);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 1rem;
        }
        
        .message-subject {
            font-weight: 600;
            color: #fff;
            margin-bottom: 0.75rem;
        }
        
        .message-preview {
            color: #aaa;
            font-size: 0.95rem;
            margin-bottom: 1rem;
            line-height: 1.4;
            max-height: 60px;
            overflow: hidden;
        }
        
        .message-actions {
            display: flex;
            gap: 0.75rem;
            padding-top: 1rem;
            border-top: 1px solid var(--border-color);
        }
        
        .message-actions a,
        .message-actions button {
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
            border-radius: 4px;
            cursor: pointer;
            border: none;
            text-decoration: none;
            transition: all 0.2s ease;
        }
        
        .btn-view {
            background: var(--primary);
            color: white;
            flex: 1;
        }
        
        .btn-view:hover {
            background: #0284c7;
        }
        
        .btn-mark {
            background: #6366f1;
            color: white;
        }
        
        .btn-mark:hover {
            background: #4f46e5;
        }
        
        .btn-delete {
            background: #ef4444;
            color: white;
        }
        
        .btn-delete:hover {
            background: #dc2626;
        }
        
        .btn-reply {
            background: #8b5cf6;
            color: white;
        }
        
        .btn-reply:hover {
            background: #7c3aed;
        }
        
        .btn-print {
            background: #10b981;
            color: white;
        }
        
        .btn-print:hover {
            background: #059669;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem 2rem;
            color: #666;
        }
        
        .empty-state i {
            font-size: 3rem;
            color: #444;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .messages-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .messages-header-info {
            display: flex;
            gap: 2rem;
            align-items: center;
        }
        
        .stat-small {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.95rem;
        }
        
        .stat-small strong {
            color: var(--primary);
            font-size: 1.2rem;
        }
    </style>
</head>
<body class="admin-page">
    <?php include 'sidebar.php'; ?>
    
    <div class="admin-main">
        <?php include 'topbar.php'; ?>
        
        <main class="admin-content">
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header">
                <div class="messages-header">
                    <div class="messages-header-info">
                        <div class="stat-small">
                            <i class="fas fa-envelope"></i>
                            <span>Total: <strong><?php echo count($messages); ?></strong></span>
                        </div>
                        <div class="stat-small">
                            <i class="fas fa-circle" style="color: var(--primary); font-size: 0.6rem;"></i>
                            <span>Baru: <strong><?php echo $unread_count; ?></strong></span>
                        </div>
                    </div>
                    <a href="javascript:printMessages()" class="btn btn-print">
                        <i class="fas fa-print"></i> Cetak Semua
                    </a>
                </div>
            </div>
            
            <div class="card-body">
                <?php if (!empty($messages)): ?>
                    <div class="messages-list">
                        <?php foreach ($messages as $msg): ?>
                            <div class="message-card <?php echo $msg['is_read'] ? '' : 'unread'; ?>">
                                <div class="message-header">
                                    <div class="message-from">
                                        <h3><?php echo htmlspecialchars($msg['name']); ?></h3>
                                        <a href="mailto:<?php echo htmlspecialchars($msg['email']); ?>" class="message-email">
                                            <?php echo htmlspecialchars($msg['email']); ?>
                                        </a>
                                    </div>
                                    <div style="display: flex; align-items: center; gap: 1rem;">
                                        <div class="message-date">
                                            <?php echo date('d M Y H:i', strtotime($msg['created_at'])); ?>
                                        </div>
                                        <?php if (!$msg['is_read']): ?>
                                            <span class="message-unread-badge">BARU</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <?php if (!empty($msg['subject'])): ?>
                                    <div class="message-subject">📌 <?php echo htmlspecialchars($msg['subject']); ?></div>
                                <?php endif; ?>
                                
                                <div class="message-preview">
                                    <?php echo htmlspecialchars(substr($msg['message'], 0, 150)); ?>
                                    <?php if (strlen($msg['message']) > 150): ?>...<?php endif; ?>
                                </div>
                                
                                <div class="message-actions">
                                    <button type="button" class="btn-view" onclick="viewMessage(<?php echo htmlspecialchars(json_encode($msg)); ?>)">
                                        <i class="fas fa-eye"></i> Lihat Lengkap
                                    </button>
                                    <a href="mailto:<?php echo htmlspecialchars($msg['email']); ?>?subject=Re:%20<?php echo urlencode($msg['subject'] ?? 'Reply'); ?>" class="btn-reply" target="_blank">
                                        <i class="fas fa-reply"></i> Balas
                                    </a>
                                    <?php if (!$msg['is_read']): ?>
                                        <a href="?mark_read=<?php echo $msg['id']; ?>" class="btn-mark">
                                            <i class="fas fa-check"></i> Sudah Dibaca
                                        </a>
                                    <?php endif; ?>
                                    <a href="?delete=<?php echo $msg['id']; ?>" class="btn-delete" onclick="return confirm('Hapus pesan ini?')">
                                        <i class="fas fa-trash"></i> Hapus
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>Tidak Ada Pesan</h3>
                        <p>Belum ada pesan masuk dari pengunjung website.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <!-- Modal untuk view message lengkap -->
    <div id="messageModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 1000; padding: 2rem;">
        <div style="background: var(--bg-card); border-radius: 12px; max-width: 600px; margin: auto; max-height: 80vh; overflow-y: auto; padding: 2rem; position: relative; top: 5vh;">
            <button onclick="closeModal()" style="position: absolute; top: 1rem; right: 1rem; background: transparent; border: none; font-size: 1.5rem; color: #999; cursor: pointer;">✕</button>
            
            <div id="modalContent"></div>
            
            <div style="margin-top: 2rem; padding-top: 2rem; border-top: 1px solid var(--border-color); display: flex; gap: 1rem;">
                <button onclick="copyToClipboard()" class="btn btn-primary">
                    <i class="fas fa-copy"></i> Salin
                </button>
                <button onclick="closeModal()" class="btn btn-outline">
                    <i class="fas fa-times"></i> Tutup
                </button>
            </div>
        </div>
    </div>
    
    <script>
        let currentMessage = null;
        
        function viewMessage(msg) {
            currentMessage = msg;
            const modal = document.getElementById('messageModal');
            const content = document.getElementById('modalContent');
            
            content.innerHTML = `
                <h2 style="margin: 0 0 1rem 0; color: #fff;">${escapeHtml(msg.name)}</h2>
                <p style="margin: 0 0 0.5rem 0; color: #aaa;">
                    <strong>Email:</strong> <a href="mailto:${escapeHtml(msg.email)}" style="color: var(--primary);">${escapeHtml(msg.email)}</a>
                </p>
                <p style="margin: 0 0 1rem 0; color: #999; font-size: 0.9rem;">
                    <i class="fas fa-clock"></i> ${new Date(msg.created_at).toLocaleString('id-ID')}
                </p>
                
                ${msg.subject ? `<p style="margin: 0 0 1rem 0; padding: 1rem; background: rgba(14, 165, 233, 0.1); border-left: 4px solid var(--primary); border-radius: 4px;"><strong>📌 Subjek:</strong> ${escapeHtml(msg.subject)}</p>` : ''}
                
                <div style="background: rgba(255,255,255,0.03); padding: 1.5rem; border-radius: 8px; border: 1px solid var(--border-color); white-space: pre-wrap; line-height: 1.6; color: #ccc;">
                    ${escapeHtml(msg.message)}
                </div>
            `;
            
            modal.style.display = 'block';
        }
        
        function closeModal() {
            document.getElementById('messageModal').style.display = 'none';
        }
        
        function escapeHtml(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, m => map[m]);
        }
        
        function copyToClipboard() {
            if (!currentMessage) return;
            
            const text = `${currentMessage.name}\n${currentMessage.email}\n\n${currentMessage.subject ? 'Subjek: ' + currentMessage.subject + '\n\n' : ''}${currentMessage.message}`;
            navigator.clipboard.writeText(text).then(() => {
                alert('Pesan disalin ke clipboard!');
            });
        }
        
        function printMessages() {
            window.open('print-messages.php', 'PrintWindow', 'width=900,height=600');
        }
        
        // Close modal when clicking outside
        document.getElementById('messageModal').addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });
    </script>
    
    <script src="<?php echo ASSETS_URL; ?>js/admin.js"></script>
        </main>
    </div>
</body>
</html>
