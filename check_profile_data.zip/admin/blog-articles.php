<?php
require_once '../includes/config.php';
require_once 'auth_check.php';  // Security check

$page_title = 'Blog & Artikel';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog & Artikel - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/style.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/admin.css">
    <style>
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 15px;
        }

        .admin-header h1 {
            margin: 0;
        }

        .articles-section {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-lg);
            padding: 30px;
        }

        .articles-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .articles-list-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            gap: 15px;
        }

        .articles-list-header h2 {
            margin: 0;
        }

        .table-container {
            overflow-x: auto;
        }

        .admin-table {
            width: 100%;
            border-collapse: collapse;
        }

        .admin-table thead {
            background: var(--bg-dark);
        }

        .admin-table th,
        .admin-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .admin-table th {
            font-weight: 600;
            color: var(--primary);
        }

        .admin-table tr:hover {
            background: rgba(59, 130, 246, 0.05);
        }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .status-published {
            background: rgba(16, 185, 129, 0.2);
            color: #10b981;
        }

        .status-draft {
            background: rgba(107, 114, 128, 0.2);
            color: #6b7280;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn {
            padding: 8px 12px;
            border: none;
            border-radius: var(--radius-md);
            cursor: pointer;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.85rem;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(59, 130, 246, 0.3);
        }

        .btn-secondary {
            background: var(--border-color);
            color: var(--text-light);
        }

        .btn-secondary:hover {
            background: var(--primary);
            color: white;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 15px;
            display: block;
        }

        @media (max-width: 768px) {
            .admin-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .articles-header {
                flex-direction: column;
            }

            .admin-table th,
            .admin-table td {
                padding: 10px;
            }

            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body class="admin-page">
    <?php include 'sidebar.php'; ?>
    
    <!-- MAIN CONTENT -->
    <div class="admin-main">
        <!-- TOP BAR -->
        <?php 
        $page_title = 'Daftar Artikel';
        include 'topbar.php'; 
        ?>
        
        <!-- PAGE CONTENT -->
        <div class="admin-content">
            <!-- ARTICLES LIST SECTION -->
            <div class="articles-section" id="articles-list">
                <div class="articles-header">
                    <div class="articles-list-header">
                        <h2><i class="fas fa-list-ul"></i> Daftar Semua Artikel</h2>
                        <a href="blog-builder.php" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Tambah Artikel
                        </a>
                    </div>
                </div>

                <div class="table-container">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th style="width: 40%">Judul</th>
                                <th style="width: 20%">Kategori</th>
                                <th style="width: 15%">Status</th>
                                <th style="width: 15%">Tanggal</th>
                                <th style="width: 20%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT id, title, category, status, created_at FROM blog_posts ORDER BY created_at DESC";
                            $result = $conn->query($query);
                            
                            if ($result->num_rows > 0) {
                                while ($post = $result->fetch_assoc()) {
                                    echo '<tr class="status-' . $post['status'] . '">';
                                    echo '<td><strong>' . htmlspecialchars($post['title']) . '</strong></td>';
                                    echo '<td>' . htmlspecialchars($post['category'] ?? '-') . '</td>';
                                    echo '<td><span class="status-badge status-' . $post['status'] . '">' . ucfirst($post['status']) . '</span></td>';
                                    echo '<td>' . date('d M Y', strtotime($post['created_at'])) . '</td>';
                                    echo '<td>';
                                    echo '<div class="action-buttons">';
                                    echo '<a href="blog-builder.php?id=' . $post['id'] . '" class="btn btn-secondary"><i class="fas fa-edit"></i> Edit</a>';
                                    echo '<button onclick="deleteArticle(' . $post['id'] . ')" class="btn btn-danger"><i class="fas fa-trash"></i> Hapus</button>';
                                    echo '</div>';
                                    echo '</td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo '<tr><td colspan="5"><div class="empty-state"><i class="fas fa-inbox"></i><p>Belum ada artikel. <strong><a href="blog-builder.php">Buat artikel baru sekarang!</a></strong></p></div></td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo ASSETS_URL; ?>js/admin.js"></script>
    <script>
        function deleteArticle(id) {
            if (confirm('Yakin ingin menghapus artikel ini?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'api/blog-delete.php';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'id';
                input.value = id;
                
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>

