<?php
require_once '../includes/config.php';
require_once 'auth_check.php';

// Get all messages
$query = "SELECT id, name, email, subject, message, created_at FROM contact_messages ORDER BY created_at DESC";
$result = $conn->query($query);
$messages = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Semua Pesan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #fff;
            color: #333;
            padding: 20px;
        }
        
        .print-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #ccc;
            padding-bottom: 20px;
        }
        
        .print-header h1 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        
        .print-header p {
            color: #666;
            font-size: 14px;
        }
        
        .message-item {
            margin-bottom: 25px;
            padding: 15px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            page-break-inside: avoid;
        }
        
        .message-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            border-bottom: 1px solid #f0f0f0;
            padding-bottom: 10px;
        }
        
        .message-from {
            font-weight: 600;
            color: #000;
        }
        
        .message-email {
            color: #666;
            font-size: 13px;
        }
        
        .message-date {
            color: #999;
            font-size: 12px;
        }
        
        .message-subject {
            margin: 10px 0;
            font-weight: 500;
            color: #333;
        }
        
        .message-body {
            color: #555;
            line-height: 1.6;
            white-space: pre-wrap;
            word-wrap: break-word;
            font-size: 14px;
        }
        
        .print-footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #ccc;
            text-align: center;
            color: #999;
            font-size: 12px;
        }
        
        @media print {
            body {
                padding: 0;
            }
            
            .message-item {
                break-inside: avoid;
            }
        }
        
        .button-group {
            text-align: center;
            margin: 20px 0;
        }
        
        button {
            background: #3b82f6;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            margin: 0 5px;
        }
        
        button:hover {
            background: #2563eb;
        }
    </style>
</head>
<body>
    <div class="print-header">
        <h1>Semua Pesan Masuk</h1>
        <p>Dicetak pada: <?php echo date('d M Y H:i'); ?></p>
        <p>Total pesan: <?php echo count($messages); ?></p>
    </div>
    
    <div class="button-group">
        <button onclick="window.print()">🖨️ Cetak</button>
        <button onclick="window.close()">✕ Tutup</button>
    </div>
    
    <div class="messages-list">
        <?php if (!empty($messages)): ?>
            <?php foreach ($messages as $msg): ?>
                <div class="message-item">
                    <div class="message-header">
                        <div>
                            <div class="message-from"><?php echo htmlspecialchars($msg['name']); ?></div>
                            <div class="message-email"><?php echo htmlspecialchars($msg['email']); ?></div>
                        </div>
                        <div class="message-date"><?php echo date('d M Y H:i', strtotime($msg['created_at'])); ?></div>
                    </div>
                    <?php if (!empty($msg['subject'])): ?>
                        <div class="message-subject">Subjek: <?php echo htmlspecialchars($msg['subject']); ?></div>
                    <?php endif; ?>
                    <div class="message-body"><?php echo htmlspecialchars($msg['message']); ?></div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="text-align: center; color: #999; padding: 40px;">Tidak ada pesan.</p>
        <?php endif; ?>
    </div>
    
    <div class="print-footer">
        <p>© <?php echo date('Y'); ?> Portfolio Admin Dashboard</p>
    </div>
</body>
</html>
