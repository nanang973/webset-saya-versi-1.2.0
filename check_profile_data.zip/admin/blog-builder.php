<?php
// Admin Blog Builder
require_once '../includes/config.php';

// Check auth
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Get post ID if editing
$post_id = isset($_GET['id']) ? intval($_GET['id']) : null;
$post = null;

if ($post_id) {
    $stmt = $conn->prepare("SELECT * FROM blog_posts WHERE id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $post = $result->fetch_assoc();
    
    if (!$post) {
        $_SESSION['error'] = 'Artikel tidak ditemukan';
        header('Location: dashboard.php');
        exit;
    }
    
    $post['content'] = json_decode($post['content'], true);
}

$page_title = $post ? 'Edit Artikel' : 'Buat Artikel Baru';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .blog-builder-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            height: 100vh;
            overflow: hidden;
        }

        .builder-panel {
            display: flex;
            flex-direction: column;
            height: 100%;
            overflow-y: auto;
            border-right: 2px solid var(--primary);
            padding: 20px;
        }

        .preview-panel {
            display: flex;
            flex-direction: column;
            height: 100%;
            overflow-y: auto;
            padding: 20px;
            background: var(--bg-dark);
        }

        .article-header {
            background: var(--bg-card);
            padding: 20px;
            border-radius: var(--radius-lg);
            border: 1px solid var(--border-color);
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-light);
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-md);
            color: var(--text-light);
            font-family: 'Poppins', sans-serif;
            font-size: 0.95rem;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 10px rgba(59, 130, 246, 0.3);
        }

        .blocks-section {
            margin-top: 30px;
        }

        .blocks-section h3 {
            margin-bottom: 15px;
            color: var(--primary);
            font-size: 1.1rem;
        }

        .add-block-buttons {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-bottom: 20px;
        }

        .add-block-btn {
            padding: 10px;
            background: rgba(59, 130, 246, 0.1);
            border: 1px solid var(--primary);
            color: var(--primary);
            border-radius: var(--radius-md);
            cursor: pointer;
            transition: var(--transition);
            font-weight: 600;
            font-size: 0.9rem;
        }

        .add-block-btn:hover {
            background: var(--primary);
            color: white;
        }

        .blocks-list {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .block-item {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-lg);
            padding: 15px;
            cursor: move;
            transition: var(--transition);
        }

        .block-item:hover {
            border-color: var(--primary);
            background: var(--bg-hover);
        }

        .block-item.dragging {
            opacity: 0.5;
            transform: rotate(2deg);
        }

        .block-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            cursor: pointer;
        }

        .block-type {
            display: inline-block;
            background: var(--primary);
            color: white;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            font-size: 0.75rem;
            font-weight: 600;
        }

        .block-actions {
            display: flex;
            gap: 5px;
        }

        .block-action-btn {
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(59, 130, 246, 0.1);
            border: 1px solid var(--primary);
            color: var(--primary);
            border-radius: var(--radius-sm);
            cursor: pointer;
            transition: var(--transition);
            font-size: 0.9rem;
        }

        .block-action-btn:hover {
            background: var(--primary);
            color: white;
        }

        .block-content {
            display: none;
        }

        .block-content.active {
            display: block;
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px solid var(--border-color);
        }

        .block-input {
            width: 100%;
            padding: 8px;
            background: var(--bg-dark);
            border: 1px solid var(--border-color);
            color: var(--text-light);
            border-radius: var(--radius-md);
            margin-bottom: 8px;
            font-family: 'Poppins', sans-serif;
        }

        .preview-content {
            background: var(--bg-card);
            padding: 30px;
            border-radius: var(--radius-lg);
            border: 1px solid var(--border-color);
        }

        .preview-content h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: var(--primary);
        }

        .preview-content h2 {
            font-size: 2rem;
            margin: 20px 0 10px;
        }

        .preview-content h3 {
            font-size: 1.5rem;
            margin: 15px 0 8px;
        }

        .preview-content h4 {
            font-size: 1.2rem;
            margin: 12px 0 6px;
        }

        .preview-content p {
            line-height: 1.8;
            margin-bottom: 15px;
            text-align: justify;
        }

        .preview-content img {
            max-width: 100%;
            height: auto;
            border-radius: var(--radius-lg);
            margin: 20px 0;
        }

        .preview-content blockquote {
            border-left: 4px solid var(--primary);
            padding: 15px 20px;
            margin: 20px 0;
            background: rgba(59, 130, 246, 0.1);
            font-style: italic;
            color: var(--text-muted);
        }

        .preview-content code {
            background: var(--bg-dark);
            padding: 2px 6px;
            border-radius: var(--radius-sm);
            font-family: 'Courier New', monospace;
            color: var(--primary);
        }

        .preview-content pre {
            background: var(--bg-dark);
            padding: 15px;
            border-radius: var(--radius-lg);
            overflow-x: auto;
            margin: 15px 0;
        }

        .preview-content pre code {
            padding: 0;
            background: transparent;
            color: var(--text-light);
        }

        .preview-content ul,
        .preview-content ol {
            margin-left: 30px;
            margin-bottom: 15px;
        }

        .preview-content li {
            margin-bottom: 5px;
        }

        .save-bar {
            position: fixed;
            bottom: 0;
            left: 250px;
            right: 0;
            background: var(--bg-card);
            border-top: 2px solid var(--primary);
            padding: 20px;
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.3);
            z-index: 50;
        }

        .save-bar button {
            padding: 12px 24px;
            border: none;
            border-radius: var(--radius-lg);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
            font-family: 'Poppins', sans-serif;
        }

        .btn-save-draft {
            background: var(--border-color);
            color: white;
        }

        .btn-save-draft:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(30, 40, 80, 0.3);
        }

        .btn-publish {
            background: var(--primary);
            color: white;
        }

        .btn-publish:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(59, 130, 246, 0.3);
        }

        .btn-cancel {
            background: transparent;
            color: var(--text-muted);
            border: 1px solid var(--border-color);
        }

        .btn-cancel:hover {
            color: var(--primary);
            border-color: var(--primary);
        }

        .builder-panel {
            padding-bottom: 100px;
        }

        @media (max-width: 1200px) {
            .blog-builder-container {
                grid-template-columns: 1fr;
            }

            .builder-panel {
                border-right: none;
                border-bottom: 2px solid var(--primary);
            }

            .save-bar {
                left: 0;
            }
        }

        .level-select {
            width: 80px;
            padding: 6px;
        }

        .meta-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        /* ============================================
           NOTIFICATION TOAST STYLES
           ============================================ */
        .notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            max-width: 400px;
            padding: 16px 24px;
            border-radius: var(--radius-lg);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
            z-index: 9999;
            animation: slideIn 0.3s ease-out;
            opacity: 0;
            transform: translateX(400px);
            transition: all 0.3s ease;
        }

        .notification.show {
            opacity: 1;
            transform: translateX(0);
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(400px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .notification-content {
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 500;
        }

        .notification-content i {
            font-size: 1.3rem;
            flex-shrink: 0;
        }

        .notification-success {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            border-left: 4px solid #0d9488;
        }

        .notification-error {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            border-left: 4px solid #991b1b;
        }

        .notification-info {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            color: white;
            border-left: 4px solid #1e40af;
        }

        @media (max-width: 768px) {
            .notification {
                bottom: 10px;
                right: 10px;
                left: 10px;
                max-width: none;
            }
        }
    </style>
</head>
<body>
    <!-- Admin Page Layout -->
    <div class="admin-page">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Main Content -->
        <div class="admin-main">
            <!-- Topbar -->
            <?php include 'topbar.php'; ?>

            <!-- Blog Builder -->
            <div class="admin-content">
                <div class="blog-builder-container">
                    <!-- Left Panel: Editor -->
                    <div class="builder-panel">
                        <!-- Article Header Info -->
                        <div class="article-header">
                            <h2><?php echo $page_title; ?></h2>
                            <hr style="margin: 15px 0; border: none; border-top: 1px solid var(--border-color);">
                            
                            <form id="blogForm">
                                <div class="form-group">
                                    <label for="title">Judul Artikel *</label>
                                    <input type="text" id="title" name="title" required value="<?php echo $post['title'] ?? ''; ?>" placeholder="Masukkan judul artikel...">
                                </div>

                                <div class="form-group">
                                    <label for="slug">Slug (URL-friendly) *</label>
                                    <input type="text" id="slug" name="slug" required value="<?php echo $post['slug'] ?? ''; ?>" placeholder="pembentukan-pr-ipnu-ippnu-napis">
                                    <small style="color: var(--text-muted);">Hanya huruf, angka, dan tanda strip (-)</small>
                                </div>

                                <div class="meta-row">
                                    <div class="form-group">
                                        <label for="category">Kategori</label>
                                        <select id="category" name="category">
                                            <option value="">Pilih Kategori</option>
                                            <option value="Tutorial" <?php echo ($post['category'] ?? '') === 'Tutorial' ? 'selected' : ''; ?>>Tutorial</option>
                                            <option value="Tips & Trik" <?php echo ($post['category'] ?? '') === 'Tips & Trik' ? 'selected' : ''; ?>>Tips & Trik</option>
                                            <option value="Berita" <?php echo ($post['category'] ?? '') === 'Berita' ? 'selected' : ''; ?>>Berita</option>
                                            <option value="Review" <?php echo ($post['category'] ?? '') === 'Review' ? 'selected' : ''; ?>>Review</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="featured_image">URL Gambar Utama</label>
                                        <input type="url" id="featured_image" name="featured_image" value="<?php echo $post['featured_image'] ?? ''; ?>" placeholder="https://example.com/image.jpg">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="excerpt">Ringkasan Artikel</label>
                                    <textarea id="excerpt" name="excerpt" placeholder="Tulis ringkasan singkat artikel Anda..." maxlength="500"><?php echo $post['excerpt'] ?? ''; ?></textarea>
                                    <small style="color: var(--text-muted);">Max 500 karakter</small>
                                </div>

                                <div class="form-group">
                                    <label for="tags">Tags (pisahkan dengan koma)</label>
                                    <input type="text" id="tags" name="tags" value="<?php echo $post['tags'] ?? ''; ?>" placeholder="IPNU, IPPNU, Organisasi">
                                </div>
                            </form>
                        </div>

                        <!-- Blocks Section -->
                        <div class="blocks-section">
                            <h3><i class="fas fa-cube"></i> Blok Konten</h3>
                            
                            <div class="add-block-buttons">
                                <button class="add-block-btn" onclick="addBlock('heading')"><i class="fas fa-heading"></i> Heading</button>
                                <button class="add-block-btn" onclick="addBlock('paragraph')"><i class="fas fa-align-left"></i> Paragraf</button>
                                <button class="add-block-btn" onclick="addBlock('image')"><i class="fas fa-image"></i> Gambar</button>
                                <button class="add-block-btn" onclick="addBlock('quote')"><i class="fas fa-quote-left"></i> Quote</button>
                                <button class="add-block-btn" onclick="addBlock('code')"><i class="fas fa-code"></i> Kode</button>
                                <button class="add-block-btn" onclick="addBlock('video')"><i class="fas fa-video"></i> Video</button>
                                <button class="add-block-btn" onclick="addBlock('list')"><i class="fas fa-list"></i> List</button>
                                <button class="add-block-btn" onclick="addBlock('spacer')"><i class="fas fa-arrows-alt-v"></i> Spasi</button>
                            </div>

                            <div class="blocks-list" id="blocksList"></div>
                        </div>
                    </div>

                    <!-- Right Panel: Preview -->
                    <div class="preview-panel">
                        <h3 style="margin-bottom: 15px; color: var(--primary);">
                            <i class="fas fa-eye"></i> Preview Live
                        </h3>
                        <div class="preview-content" id="previewContent"></div>
                    </div>
                </div>

                <!-- Save Bar -->
                <div class="save-bar">
                    <button class="btn-cancel" onclick="window.history.back()">
                        <i class="fas fa-times"></i> Batal
                    </button>
                    <button class="btn-save-draft" onclick="saveArticle('draft')">
                        <i class="fas fa-save"></i> Simpan Draft
                    </button>
                    <button class="btn-publish" onclick="saveArticle('published')">
                        <i class="fas fa-paper-plane"></i> Publish
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo ASSETS_URL; ?>js/admin.js"></script>

    <script>
        let blocks = [];
        const POST_ID = <?php echo $post_id ?? 'null'; ?>;

        // Initialize with existing content
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($post && !empty($post['content'])): ?>
            blocks = <?php echo json_encode($post['content']); ?>;
            renderBlocks();
            updatePreview();
            <?php endif; ?>
        });

        // Add new block
        function addBlock(type) {
            const block = {
                id: Date.now(),
                type: type,
                content: {
                    text: '',
                    level: 'h2',
                    url: '',
                    style: 'unordered',
                    items: [],
                    height: 20
                }
            };

            blocks.push(block);
            renderBlocks();
            updatePreview();
        }

        // Render blocks list
        function renderBlocks() {
            const blocksList = document.getElementById('blocksList');
            blocksList.innerHTML = '';

            blocks.forEach((block, index) => {
                const blockEl = createBlockElement(block, index);
                blocksList.appendChild(blockEl);
            });
        }

        // Create block HTML element
        function createBlockElement(block, index) {
            const div = document.createElement('div');
            div.className = 'block-item';
            div.draggable = true;
            div.dataset.blockId = block.id;

            let contentHTML = '';
            let blockLabel = '';

            switch(block.type) {
                case 'heading':
                    blockLabel = 'Heading';
                    contentHTML = `
                        <div class="form-group">
                            <label>Level</label>
                            <select class="level-select" onchange="updateBlockContent(${index}, 'level', this.value)">
                                <option value="h1" ${block.content.level === 'h1' ? 'selected' : ''}>H1</option>
                                <option value="h2" ${block.content.level === 'h2' ? 'selected' : ''}>H2</option>
                                <option value="h3" ${block.content.level === 'h3' ? 'selected' : ''}>H3</option>
                                <option value="h4" ${block.content.level === 'h4' ? 'selected' : ''}>H4</option>
                            </select>
                        </div>
                        <input type="text" class="block-input" placeholder="Teks heading..." value="${block.content.text}" onchange="updateBlockContent(${index}, 'text', this.value)">
                    `;
                    break;
                case 'paragraph':
                    blockLabel = 'Paragraf';
                    contentHTML = `
                        <textarea class="block-input" style="min-height: 100px;" placeholder="Tulis paragraf..." onchange="updateBlockContent(${index}, 'text', this.value)">${block.content.text}</textarea>
                    `;
                    break;
                case 'image':
                    blockLabel = 'Gambar';
                    contentHTML = `
                        <input type="url" class="block-input" placeholder="URL gambar (https://...)" value="${block.content.url}" onchange="updateBlockContent(${index}, 'url', this.value)">
                    `;
                    break;
                case 'quote':
                    blockLabel = 'Quote';
                    contentHTML = `
                        <textarea class="block-input" style="min-height: 80px;" placeholder="Tulis quote..." onchange="updateBlockContent(${index}, 'text', this.value)">${block.content.text}</textarea>
                    `;
                    break;
                case 'code':
                    blockLabel = 'Kode';
                    contentHTML = `
                        <textarea class="block-input" style="min-height: 120px; font-family: 'Courier New';" placeholder="Paste kode Anda..." onchange="updateBlockContent(${index}, 'text', this.value)">${block.content.text}</textarea>
                    `;
                    break;
                case 'video':
                    blockLabel = 'Video';
                    contentHTML = `
                        <input type="url" class="block-input" placeholder="YouTube/Vimeo embed URL" value="${block.content.url}" onchange="updateBlockContent(${index}, 'url', this.value)">
                        <small style="color: var(--text-muted);">Contoh: https://www.youtube.com/embed/dQw4w9WgXcQ</small>
                    `;
                    break;
                case 'list':
                    blockLabel = 'List';
                    contentHTML = `
                        <select class="block-input" onchange="updateBlockContent(${index}, 'style', this.value)">
                            <option value="unordered" ${block.content.style === 'unordered' ? 'selected' : ''}>Bullet List</option>
                            <option value="ordered" ${block.content.style === 'ordered' ? 'selected' : ''}>Numbered List</option>
                        </select>
                        <textarea class="block-input" style="min-height: 100px;" placeholder="Setiap item di baris baru..." onchange="updateBlockContent(${index}, 'text', this.value)">${(block.content.items || []).join('\\n')}</textarea>
                    `;
                    break;
                case 'spacer':
                    blockLabel = 'Spasi';
                    contentHTML = `
                        <label>Tinggi Spasi (px)</label>
                        <input type="number" class="block-input" min="10" max="200" value="${block.content.height}" onchange="updateBlockContent(${index}, 'height', this.value)">
                    `;
                    break;
            }

            div.innerHTML = `
                <div class="block-header" onclick="toggleBlockContent(this)">
                    <span>
                        <span class="block-type">${blockLabel}</span>
                        <span style="margin-left: 10px; color: var(--text-muted);" id="blockPreview${index}"></span>
                    </span>
                    <div class="block-actions">
                        <button type="button" class="block-action-btn" onclick="moveBlockUp(${index}); event.stopPropagation();"><i class="fas fa-arrow-up"></i></button>
                        <button type="button" class="block-action-btn" onclick="moveBlockDown(${index}); event.stopPropagation();"><i class="fas fa-arrow-down"></i></button>
                        <button type="button" class="block-action-btn" style="border-color: #ef4444; color: #ef4444;" onclick="deleteBlock(${index}); event.stopPropagation();"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
                <div class="block-content">${contentHTML}</div>
            `;

            // Update preview text
            const previewEl = div.querySelector(`#blockPreview${index}`);
            if (block.type === 'heading' || block.type === 'paragraph') {
                previewEl.textContent = block.content.text.substring(0, 50);
            } else if (block.type === 'image') {
                previewEl.textContent = 'Gambar';
            } else {
                previewEl.textContent = '';
            }

            return div;
        }

        // Toggle block content
        function toggleBlockContent(header) {
            const content = header.nextElementSibling;
            content.classList.toggle('active');
        }

        // Update block content
        function updateBlockContent(index, field, value) {
            if (field === 'items') {
                blocks[index].content.items = value.split('\n').filter(item => item.trim());
            } else {
                blocks[index].content[field] = value;
            }
            updatePreview();
        }

        // Move block up
        function moveBlockUp(index) {
            if (index > 0) {
                [blocks[index], blocks[index - 1]] = [blocks[index - 1], blocks[index]];
                renderBlocks();
                updatePreview();
            }
        }

        // Move block down
        function moveBlockDown(index) {
            if (index < blocks.length - 1) {
                [blocks[index], blocks[index + 1]] = [blocks[index + 1], blocks[index]];
                renderBlocks();
                updatePreview();
            }
        }

        // Delete block
        function deleteBlock(index) {
            if (confirm('Yakin ingin menghapus blok ini?')) {
                blocks.splice(index, 1);
                renderBlocks();
                updatePreview();
            }
        }

        // Update preview
        function updatePreview() {
            const preview = document.getElementById('previewContent');
            const title = document.getElementById('title').value;
            
            let html = '';
            
            if (title) {
                html += `<h1>${escapeHtml(title)}</h1>`;
            }

            blocks.forEach(block => {
                switch(block.type) {
                    case 'heading':
                        html += `<${block.content.level}>${escapeHtml(block.content.text)}</${block.content.level}>`;
                        break;
                    case 'paragraph':
                        html += `<p>${block.content.text.split('\n').join('<br>')}</p>`;
                        break;
                    case 'image':
                        if (block.content.url) {
                            html += `<img src="${block.content.url}" alt="Article image" style="max-width: 100%; height: auto;">`;
                        }
                        break;
                    case 'quote':
                        html += `<blockquote>${block.content.text}</blockquote>`;
                        break;
                    case 'code':
                        html += `<pre><code>${escapeHtml(block.content.text)}</code></pre>`;
                        break;
                    case 'video':
                        if (block.content.url) {
                            html += `<iframe width="100%" height="400" src="${block.content.url}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen style="border-radius: 8px; margin: 20px 0;"></iframe>`;
                        }
                        break;
                    case 'list':
                        const items = block.content.items || (block.content.text ? block.content.text.split('\n').filter(i => i.trim()) : []);
                        const tag = block.content.style === 'ordered' ? 'ol' : 'ul';
                        html += `<${tag}>` + items.map(item => `<li>${escapeHtml(item)}</li>`).join('') + `</${tag}>`;
                        break;
                    case 'spacer':
                        html += `<div style="height: ${block.content.height}px;"></div>`;
                        break;
                }
            });

            preview.innerHTML = html;
        }

        // Show notification toast
        function showNotification(message, type = 'success', duration = 3000) {
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
                <div class="notification-content">
                    <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
                    <span>${message}</span>
                </div>
            `;
            document.body.appendChild(notification);

            // Trigger animation
            setTimeout(() => notification.classList.add('show'), 10);

            // Remove after duration
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => notification.remove(), 300);
            }, duration);
        }

        // Save article
        function saveArticle(status) {
            const title = document.getElementById('title').value;
            const slug = document.getElementById('slug').value;

            if (!title || !slug) {
                showNotification('Judul dan Slug harus diisi!', 'error');
                return;
            }

            if (blocks.length === 0) {
                showNotification('Tambahkan minimal 1 blok konten!', 'error');
                return;
            }

            const formData = new FormData();
            formData.append('action', POST_ID ? 'update' : 'create');
            formData.append('id', POST_ID);
            formData.append('title', title);
            formData.append('slug', slug);
            formData.append('excerpt', document.getElementById('excerpt').value);
            formData.append('featured_image', document.getElementById('featured_image').value);
            formData.append('category', document.getElementById('category').value);
            formData.append('tags', document.getElementById('tags').value);
            formData.append('content', JSON.stringify(blocks));
            formData.append('status', status);

            const btn = event.target;
            const originalText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan...';

            fetch('api/blog-save.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                // Check if response is valid before parsing JSON
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then(text => {
                // Try to parse JSON
                let data;
                try {
                    data = JSON.parse(text);
                } catch (e) {
                    console.error('Invalid JSON response:', text);
                    throw new Error('Server returned invalid response');
                }

                btn.innerHTML = originalText;
                btn.disabled = false;

                if (data.success) {
                    showNotification(data.message, 'success', 2000);
                    setTimeout(() => {
                        window.location.href = 'blog-posts.php';
                    }, 1500);
                } else {
                    showNotification('Error: ' + data.message, 'error');
                }
            })
            .catch(error => {
                btn.innerHTML = originalText;
                btn.disabled = false;
                console.error('Fetch error:', error);
                showNotification('Error: ' + error.message, 'error');
            });
        }

        // Escape HTML
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Auto-generate slug from title
        document.getElementById('title')?.addEventListener('change', function() {
            if (!document.getElementById('slug').value) {
                const slug = this.value
                    .toLowerCase()
                    .trim()
                    .replace(/[^\w\s-]/g, '')
                    .replace(/\s+/g, '-')
                    .replace(/-+/g, '-');
                document.getElementById('slug').value = slug;
            }
        });
    </script>
</body>
</html>
