<?php
require_once '../includes/config.php';
require_once 'auth_check.php';  // Security check

$action = $_GET['action'] ?? 'list';
$message = '';
$error = '';

// DELETE
if ($action == 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($conn->query("DELETE FROM portfolios WHERE id = $id")) {
        $message = 'Proyek berhasil dihapus!';
    } else {
        $error = 'Gagal menghapus proyek!';
    }
    $action = 'list';
}

// ADD/EDIT
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_GET['id']) ? intval($_GET['id']) : null;
    $title = htmlspecialchars($_POST['title'] ?? '');
    $description = htmlspecialchars($_POST['description'] ?? '');
    $category = htmlspecialchars($_POST['category'] ?? '');
    $link = htmlspecialchars($_POST['link'] ?? '');
    $github_link = htmlspecialchars($_POST['github_link'] ?? '');
    $technologies = htmlspecialchars($_POST['technologies'] ?? '');
    $image = htmlspecialchars($_POST['image'] ?? '');
    
    if (empty($title) || empty($description)) {
        $error = 'Judul dan deskripsi harus diisi!';
    } else {
        // Handle image upload
        if (isset($_FILES['portfolio_image']) && $_FILES['portfolio_image']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['portfolio_image'];
            
            // Validate MIME type
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime_type = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            if (!in_array($mime_type, $allowed_types)) {
                $error = 'Tipe file tidak diizinkan. Gunakan JPG, PNG, GIF, atau WebP';
            } else if ($file['size'] > 10 * 1024 * 1024) { // 10MB max
                $error = 'File terlalu besar. Maksimal 10MB!';
            } else {
                // Create directory if not exists
                $upload_dir = '../assets/images/portfolio/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                // Generate unique filename
                $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                $filename = 'portfolio_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                $filepath = $upload_dir . $filename;
                
                if (move_uploaded_file($file['tmp_name'], $filepath)) {
                    $image = 'assets/images/portfolio/' . $filename;
                    
                    // Delete old image if exists
                    if ($id) {
                        $old_result = $conn->query("SELECT image FROM portfolios WHERE id = $id");
                        $old_portfolio = $old_result->fetch_assoc();
                        if (!empty($old_portfolio['image'])) {
                            $old_file = '../' . $old_portfolio['image'];
                            if (file_exists($old_file)) {
                                unlink($old_file);
                            }
                        }
                    }
                } else {
                    $error = 'Gagal mengunggah file gambar!';
                }
            }
        }
        
        if (empty($error)) {
            if ($id) {
                // Update
                if (!empty($image)) {
                    $stmt = $conn->prepare("UPDATE portfolios SET title=?, description=?, category=?, link=?, github_link=?, technologies=?, image=? WHERE id=?");
                    $stmt->bind_param("sssssssi", $title, $description, $category, $link, $github_link, $technologies, $image, $id);
                } else {
                    $stmt = $conn->prepare("UPDATE portfolios SET title=?, description=?, category=?, link=?, github_link=?, technologies=? WHERE id=?");
                    $stmt->bind_param("ssssssi", $title, $description, $category, $link, $github_link, $technologies, $id);
                }
                $message = 'Proyek berhasil diperbarui!';
            } else {
                // Insert
                if (!empty($image)) {
                    $stmt = $conn->prepare("INSERT INTO portfolios (title, description, category, link, github_link, technologies, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("sssssss", $title, $description, $category, $link, $github_link, $technologies, $image);
                } else {
                    $stmt = $conn->prepare("INSERT INTO portfolios (title, description, category, link, github_link, technologies) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("ssssss", $title, $description, $category, $link, $github_link, $technologies);
                }
                $message = 'Proyek berhasil ditambahkan!';
            }
            
            if ($stmt->execute()) {
                $action = 'list';
            } else {
                $error = 'Terjadi kesalahan: ' . $stmt->error;
            }
            $stmt->close();
        }
    }
}

// GET EDIT DATA
$edit_portfolio = null;
if ($action == 'edit' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM portfolios WHERE id = $id");
    $edit_portfolio = $result->fetch_assoc();
    if (!$edit_portfolio) {
        header("Location: portfolio.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/style.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/admin.css">
</head>
<body class="admin-page">
    <?php include 'sidebar.php'; ?>
    
    <div class="admin-main">
        <?php 
        $page_title = $action == 'edit' ? 'Edit Proyek' : 'Kelola Portfolio';
        include 'topbar.php'; 
        ?>
        
        <main class="admin-content">
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($action == 'list'): ?>
            <!-- LIST VIEW -->
            <div class="form-container">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <h2>Daftar Proyek Portfolio</h2>
                    <a href="portfolio.php?action=create" class="btn btn-primary">+ Tambah Proyek</a>
                </div>
                
                <div class="table-container">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Judul</th>
                                <th>Kategori</th>
                                <th>Teknologi</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT id, title, category, technologies, created_at FROM portfolios ORDER BY created_at DESC";
                            $result = $conn->query($query);
                            
                            if ($result->num_rows > 0) {
                                while ($portfolio = $result->fetch_assoc()) {
                                    echo '<tr>';
                                    echo '<td><strong>' . htmlspecialchars($portfolio['title']) . '</strong></td>';
                                    echo '<td>' . htmlspecialchars($portfolio['category']) . '</td>';
                                    echo '<td><small>' . htmlspecialchars(substr($portfolio['technologies'], 0, 40)) . '...</small></td>';
                                    echo '<td>' . date('d M Y', strtotime($portfolio['created_at'])) . '</td>';
                                    echo '<td>';
                                    echo '<a href="portfolio.php?action=edit&id=' . $portfolio['id'] . '" class="btn btn-sm btn-secondary">Edit</a> ';
                                    echo '<a href="portfolio.php?action=delete&id=' . $portfolio['id'] . '" class="btn btn-sm btn-danger" onclick="return confirm(\'Yakin hapus proyek ini?\')">Hapus</a>';
                                    echo '</td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo '<tr><td colspan="5" style="text-align: center; padding: 2rem;">Belum ada proyek</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        
        <?php else: ?>
            <!-- FORM VIEW -->
            <div class="form-container">
                <h2><?php echo $action == 'edit' ? 'Edit Proyek' : 'Tambah Proyek Baru'; ?></h2>
                <form method="POST" enctype="multipart/form-data" class="admin-form">
                    <div class="form-group full">
                        <label for="title">Judul Proyek *</label>
                        <input type="text" id="title" name="title" required value="<?php echo htmlspecialchars($edit_portfolio['title'] ?? ''); ?>">
                    </div>
                    
                    <!-- Image Upload Section -->
                    <div class="form-group full">
                        <label>Gambar Proyek</label>
                        <div id="image-upload-section" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 10px; padding: 20px; margin-bottom: 1rem; text-align: center;">
                            <div id="image-preview" style="margin-bottom: 15px;">
                                <?php if (!empty($edit_portfolio['image'])): ?>
                                    <img src="<?php echo htmlspecialchars(BASE_URL . $edit_portfolio['image']); ?>" alt="Preview" style="max-width: 100%; max-height: 200px; border-radius: 8px;">
                                <?php else: ?>
                                    <div style="color: white; opacity: 0.7;">
                                        <i class="fas fa-image" style="font-size: 3rem;"></i>
                                        <p>Belum ada gambar</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <input type="file" id="portfolio_image" name="portfolio_image" accept="image/*" style="display: none;">
                            <button type="button" onclick="document.getElementById('portfolio_image').click();" class="btn btn-light">
                                <i class="fas fa-upload"></i> Pilih Gambar
                            </button>
                            <input type="hidden" id="image" name="image" value="<?php echo htmlspecialchars($edit_portfolio['image'] ?? ''); ?>">
                            <div id="upload-status" style="margin-top: 10px; color: white; display: none;"></div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="category">Kategori</label>
                        <select id="category" name="category">
                            <option value="">-- Pilih Kategori --</option>
                            <option value="Web Development" <?php echo ($edit_portfolio['category'] ?? '') == 'Web Development' ? 'selected' : ''; ?>>Web Development</option>
                            <option value="IoT" <?php echo ($edit_portfolio['category'] ?? '') == 'IoT' ? 'selected' : ''; ?>>IoT</option>
                            <option value="Desktop App" <?php echo ($edit_portfolio['category'] ?? '') == 'Desktop App' ? 'selected' : ''; ?>>Desktop App</option>
                            <option value="Mobile App" <?php echo ($edit_portfolio['category'] ?? '') == 'Mobile App' ? 'selected' : ''; ?>>Mobile App</option>
                            <option value="Other" <?php echo ($edit_portfolio['category'] ?? '') == 'Other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="technologies">Teknologi yang Digunakan</label>
                        <input type="text" id="technologies" name="technologies" placeholder="Contoh: PHP, MySQL, HTML5, CSS3" value="<?php echo htmlspecialchars($edit_portfolio['technologies'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group full">
                        <label for="description">Deskripsi *</label>
                        <textarea id="description" name="description" rows="6" required><?php echo htmlspecialchars($edit_portfolio['description'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="link">Link Project</label>
                        <input type="url" id="link" name="link" placeholder="https://example.com" value="<?php echo htmlspecialchars($edit_portfolio['link'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="github_link">GitHub Link</label>
                        <input type="url" id="github_link" name="github_link" placeholder="https://github.com/..." value="<?php echo htmlspecialchars($edit_portfolio['github_link'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group full">
                        <div style="display: flex; gap: 1rem;">
                            <button type="submit" class="btn btn-primary">Simpan Proyek</button>
                            <a href="portfolio.php" class="btn btn-outline">Batal</a>
                        </div>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </main>
    
    <script src="<?php echo ASSETS_URL; ?>js/admin.js"></script>
    <script>
        // Portfolio Image Upload Handler
        document.getElementById('portfolio_image')?.addEventListener('change', async function() {
            const file = this.files[0];
            if (!file) return;
            
            // Validate file type
            const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            if (!validTypes.includes(file.type)) {
                alert('File harus JPG, PNG, GIF, atau WebP');
                this.value = '';
                return;
            }
            
            // Validate file size (10MB max)
            if (file.size > 10 * 1024 * 1024) {
                alert('File terlalu besar! Maksimal 10MB');
                this.value = '';
                return;
            }
            
            // Show preview
            const reader = new FileReader();
            reader.onload = e => {
                const preview = document.getElementById('image-preview');
                preview.innerHTML = `<img src="${e.target.result}" alt="Preview" style="max-width: 100%; max-height: 200px; border-radius: 8px;">`;
            };
            reader.readAsDataURL(file);
            
            // Upload file
            const statusDiv = document.getElementById('upload-status');
            statusDiv.style.display = 'block';
            statusDiv.textContent = 'Mengunggah...';
            statusDiv.style.color = '#fbbf24';
            
            const formData = new FormData();
            formData.append('portfolio_image', file);
            
            try {
                const response = await fetch('api/upload-portfolio-image.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('image').value = data.image;
                    statusDiv.textContent = '✓ Gambar berhasil diunggah!';
                    statusDiv.style.color = '#10b981';
                } else {
                    alert('Error: ' + (data.error || 'Gagal mengunggah'));
                    statusDiv.textContent = data.error || 'Gagal mengunggah';
                    statusDiv.style.color = '#ef4444';
                    this.value = '';
                }
            } catch (error) {
                console.error('Upload error:', error);
                alert('Terjadi kesalahan saat mengunggah');
                statusDiv.textContent = 'Error: ' + error.message;
                statusDiv.style.color = '#ef4444';
                this.value = '';
            }
        });
    </script>
        </main>
    </div>
</body>
</html>
</body>
</html>
