<?php
require_once '../includes/config.php';
require_once 'auth_check.php';  // Security check

$page_title = "Kelola Profil & Skills";
$message = '';
$error = '';

// Get current profile
$profile = $conn->query("SELECT * FROM profile LIMIT 1")->fetch_assoc();

// Handle profile picture upload via AJAX
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['profile_picture'])) {
    header('Content-Type: application/json');
    
    $response = [
        'success' => false,
        'message' => '',
        'filename' => ''
    ];
    
    $file = $_FILES['profile_picture'];
    
    // Validation
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $response['message'] = 'File upload error: ' . $file['error'];
        http_response_code(400);
        echo json_encode($response);
        exit;
    }
    
    // Check file size (5MB max)
    $max_size = 5 * 1024 * 1024;
    if ($file['size'] > $max_size) {
        $response['message'] = 'File terlalu besar. Maksimal 5MB';
        http_response_code(400);
        echo json_encode($response);
        exit;
    }
    
    // Check MIME type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($mime_type, $allowed_types)) {
        $response['message'] = 'Tipe file tidak diizinkan. Gunakan JPG, PNG, GIF, atau WebP';
        http_response_code(400);
        echo json_encode($response);
        exit;
    }
    
    // Create upload directory if not exists
    $upload_dir = '../assets/images/profile/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    // Generate unique filename
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'profile_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $filepath = $upload_dir . $filename;
    
    // Move file
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        // Delete old profile picture if exists
        $old_profile = $conn->query("SELECT profile_picture FROM profile LIMIT 1")->fetch_assoc();
        if ($old_profile && !empty($old_profile['profile_picture'])) {
            $old_file = '..' . DIRECTORY_SEPARATOR . $old_profile['profile_picture'];
            if (file_exists($old_file)) {
                unlink($old_file);
            }
        }
        
        // Update database
        $relative_path = 'assets/images/profile/' . $filename;
        $sql = "UPDATE profile SET profile_picture = '" . $conn->real_escape_string($relative_path) . "' LIMIT 1";
        
        if ($conn->query($sql)) {
            $response['success'] = true;
            $response['message'] = 'Foto profil berhasil diperbarui!';
            $response['filename'] = BASE_URL . $relative_path;
            http_response_code(200);
        } else {
            $response['message'] = 'Error: ' . $conn->error;
            unlink($filepath);
            http_response_code(500);
        }
    } else {
        $response['message'] = 'Gagal mengunggah file';
        http_response_code(500);
    }
    
    echo json_encode($response);
    exit;
}

// Handle form submission (text fields only)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_FILES['profile_picture'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $title = $conn->real_escape_string($_POST['title']);
    $bio = $conn->real_escape_string($_POST['bio']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $location = $conn->real_escape_string($_POST['location']);
    $github_url = $conn->real_escape_string($_POST['github_url']);
    $linkedin_url = $conn->real_escape_string($_POST['linkedin_url']);
    $instagram_url = $conn->real_escape_string($_POST['instagram_url']);
    $twitter_url = $conn->real_escape_string($_POST['twitter_url']);
    $tiktok_url = $conn->real_escape_string($_POST['tiktok_url']);
    $facebook_url = $conn->real_escape_string($_POST['facebook_url']);
    $telegram_url = $conn->real_escape_string($_POST['telegram_url']);
    
    if (isset($profile['id'])) {
        // Update
        $sql = "UPDATE profile SET name='$name', title='$title', bio='$bio', email='$email', 
                phone='$phone', location='$location', github_url='$github_url', 
                linkedin_url='$linkedin_url', instagram_url='$instagram_url', 
                twitter_url='$twitter_url', tiktok_url='$tiktok_url', 
                facebook_url='$facebook_url', telegram_url='$telegram_url' WHERE id=" . $profile['id'];
        
        if ($conn->query($sql)) {
            $message = "Profil berhasil diperbarui!";
            $profile = $conn->query("SELECT * FROM profile LIMIT 1")->fetch_assoc();
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/style.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/admin.css">
</head>
<body class="admin-page">
    <?php include 'sidebar.php'; ?>
    
    <div class="admin-main">
        <?php include 'topbar.php'; ?>
        
        <main class="admin-content">
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="form-container">
            <!-- Profile Picture Upload Section -->
            <div class="profile-picture-section" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 10px; padding: 30px; margin-bottom: 30px; text-align: center;">
                <h3 style="color: white; margin-top: 0;">Foto Profil</h3>
                <div class="profile-picture-preview" style="margin: 20px 0;">
                    <?php if (!empty($profile['profile_picture'])): ?>
                        <img id="picture-preview" src="<?php echo htmlspecialchars(BASE_URL . $profile['profile_picture']); ?>" alt="Profile Picture" style="max-width: 200px; height: 200px; border-radius: 50%; object-fit: cover; border: 4px solid white; box-shadow: 0 4px 8px rgba(0,0,0,0.2);">
                    <?php else: ?>
                        <div id="picture-preview" style="width: 200px; height: 200px; margin: 0 auto; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px dashed white;">
                            <i class="fas fa-user-circle" style="font-size: 80px; color: white; opacity: 0.5;"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <form id="picture-upload-form" style="display: inline-block;">
                    <input type="file" id="profile_picture" name="profile_picture" accept="image/*" style="display: none;">
                    <button type="button" onclick="document.getElementById('profile_picture').click();" class="btn btn-light" style="margin: 10px;">
                        <i class="fas fa-upload"></i> Pilih Foto
                    </button>
                </form>
                <div id="upload-status" style="margin-top: 15px; color: white; display: none;"></div>
            </div>
            
            <!-- Profile Information Form -->
            <form method="POST" class="admin-form">
                <div class="form-group">
                    <label for="name">Nama Lengkap</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($profile['name'] ?? ''); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="title">Jabatan/Title</label>
                    <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($profile['title'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="bio">Biografi</label>
                    <textarea id="bio" name="bio" rows="5"><?php echo htmlspecialchars($profile['bio'] ?? ''); ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($profile['email'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="phone">Telepon</label>
                    <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($profile['phone'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="location">Lokasi</label>
                    <input type="text" id="location" name="location" value="<?php echo htmlspecialchars($profile['location'] ?? ''); ?>">
                </div>
                
                <h3 style="margin-top: 30px;">Social Media</h3>
                
                <div class="form-group">
                    <label for="github_url">GitHub URL</label>
                    <input type="url" id="github_url" name="github_url" value="<?php echo htmlspecialchars($profile['github_url'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="linkedin_url">LinkedIn URL</label>
                    <input type="url" id="linkedin_url" name="linkedin_url" value="<?php echo htmlspecialchars($profile['linkedin_url'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="instagram_url">Instagram URL</label>
                    <input type="url" id="instagram_url" name="instagram_url" value="<?php echo htmlspecialchars($profile['instagram_url'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="twitter_url">Twitter URL</label>
                    <input type="url" id="twitter_url" name="twitter_url" value="<?php echo htmlspecialchars($profile['twitter_url'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="tiktok_url">TikTok URL</label>
                    <input type="url" id="tiktok_url" name="tiktok_url" value="<?php echo htmlspecialchars($profile['tiktok_url'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="facebook_url">Facebook URL</label>
                    <input type="url" id="facebook_url" name="facebook_url" value="<?php echo htmlspecialchars($profile['facebook_url'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="telegram_url">Telegram URL</label>
                    <input type="url" id="telegram_url" name="telegram_url" value="<?php echo htmlspecialchars($profile['telegram_url'] ?? ''); ?>">
                </div>
                
                <button type="submit" class="btn btn-primary">Simpan Profil</button>
            </form>
        </div>

        <!-- SKILLS MANAGEMENT -->
        <div class="form-container" style="margin-top: 50px;">
            <h2>Kelola Skills</h2>
            <p style="margin-bottom: 20px; color: #999;">Kelola keahlian dan profisiensi Anda di sini.</p>
            <a href="skills.php" class="btn btn-primary">Kelola Skills →</a>
        </div>

        <!-- SKILLS LIST -->
        <div class="table-container" style="margin-top: 50px;">
            <h2>Daftar Skills</h2>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Proficiency</th>
                        <th>Icon</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $skills_result = $conn->query("SELECT * FROM skills ORDER BY proficiency DESC");
                    if ($skills_result && $skills_result->num_rows > 0) {
                        while ($skill = $skills_result->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($skill['name']) . '</td>';
                            echo '<td>';
                            echo '<div class="progress-bar" style="width: 100px;">';
                            echo '<div style="width: ' . $skill['proficiency'] . '%; background: #3b82f6;"></div>';
                            echo '</div>' . $skill['proficiency'] . '%';
                            echo '</td>';
                            echo '<td><i class="fas ' . htmlspecialchars($skill['icon']) . '"></i></td>';
                            echo '<td>';
                            echo '<a href="skills.php?edit=' . $skill['id'] . '" class="btn btn-sm btn-secondary">Edit</a> ';
                            echo '<a href="skills.php?delete=' . $skill['id'] . '" class="btn btn-sm btn-danger" onclick="return confirm(\'Hapus skill ini?\')">Hapus</a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="4" style="text-align: center; padding: 20px; color: #999;">Tidak ada skills. <a href="skills.php">Tambah skills baru</a></td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>
    
    <script src="<?php echo ASSETS_URL; ?>js/admin.js"></script>
    <script>
        // Handle profile picture upload
        document.getElementById('profile_picture').addEventListener('change', function(e) {
            const file = this.files[0];
            if (!file) return;
            
            const uploadStatus = document.getElementById('upload-status');
            const previewImg = document.getElementById('picture-preview');
            
            // Show file info
            uploadStatus.style.display = 'block';
            uploadStatus.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mengunggah...';
            
            // Create FormData
            const formData = new FormData();
            formData.append('profile_picture', file);
            
            // Upload file
            fetch('<?php echo BASE_URL; ?>admin/profile.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error('HTTP ' + response.status + ': ' + text);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    uploadStatus.innerHTML = '<i class="fas fa-check"></i> ' + data.message;
                    uploadStatus.style.color = '#2ecc71';
                    
                    // Update preview image
                    if (previewImg.tagName === 'IMG') {
                        previewImg.src = '<?php echo BASE_URL; ?>' + data.filename + '?t=' + new Date().getTime();
                    } else {
                        // Replace placeholder with image
                        const img = document.createElement('img');
                        img.id = 'picture-preview';
                        img.src = '<?php echo BASE_URL; ?>' + data.filename;
                        img.alt = 'Profile Picture';
                        img.style.cssText = 'max-width: 200px; height: 200px; border-radius: 50%; object-fit: cover; border: 4px solid white; box-shadow: 0 4px 8px rgba(0,0,0,0.2);';
                        previewImg.replaceWith(img);
                        document.getElementById('picture-preview').addEventListener('load', function() {
                            // After image loads, hide status after 3 seconds
                            setTimeout(() => {
                                uploadStatus.style.display = 'none';
                            }, 3000);
                        });
                    }
                } else {
                    uploadStatus.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + data.message;
                    uploadStatus.style.color = '#e74c3c';
                }
                
                // Hide status after 5 seconds
                setTimeout(() => {
                    if (data.success) {
                        uploadStatus.style.display = 'none';
                    }
                }, 5000);
            })
            .catch(error => {
                uploadStatus.innerHTML = '<i class="fas fa-exclamation-circle"></i> Error: ' + error.message;
                uploadStatus.style.color = '#e74c3c';
                console.error('Upload error:', error);
                console.error('Full response:', error.response);
            });
        });
    </script>        </main>
    </div>
</body>
</html>