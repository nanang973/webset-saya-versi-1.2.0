<?php
require_once '../includes/config.php';
require_once 'auth_check.php';  // Security check

// Skills page dah gabung ke profile.php
// Jika ada action edit/delete, proses di sini dan redirect kembali ke profile

$page_title = "Kelola Skills";
$message = '';
$error = '';

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($conn->query("DELETE FROM skills WHERE id=$id")) {
        $message = "Skill berhasil dihapus!";
        header('Location: profile.php?message=Skill berhasil dihapus');
        exit;
    } else {
        $error = "Error: " . $conn->error;
        header('Location: profile.php?error=' . urlencode($error));
        exit;
    }
}

// Get all skills
$skills = $conn->query("SELECT * FROM skills ORDER BY name");

// Handle form submission (add/edit)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $skill_id = $_POST['skill_id'] ?? null;
    $name = $conn->real_escape_string($_POST['name']);
    $proficiency = intval($_POST['proficiency']);
    $icon = $conn->real_escape_string($_POST['icon']);
    
    if ($skill_id) {
        // Update
        $sql = "UPDATE skills SET name='$name', proficiency=$proficiency, icon='$icon' WHERE id=$skill_id";
        $action = "diperbarui";
    } else {
        // Insert
        $sql = "INSERT INTO skills (name, proficiency, icon) VALUES ('$name', $proficiency, '$icon')";
        $action = "ditambahkan";
    }
    
    if ($conn->query($sql)) {
        $message = "Skill berhasil $action!";
        $skills = $conn->query("SELECT * FROM skills ORDER BY name");
    } else {
        $error = "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/style.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/admin.css">
</head>
<body class="admin-page">
    <?php include 'sidebar.php'; ?>
    
    <div class="admin-main">
        <?php include 'topbar.php'; ?>
        
        <main class="admin-content">
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="form-container">
            <h2>Tambah / Edit Skill</h2>
            <form method="POST" class="admin-form">
                <input type="hidden" name="skill_id" id="skill_id">
                
                <div class="form-group">
                    <label for="name">Nama Skill *</label>
                    <input type="text" id="name" name="name" required placeholder="Contoh: PHP, React, IoT">
                </div>
                
                <div class="form-group">
                    <label for="proficiency">Proficiency Level *</label>
                    <div style="display: flex; align-items: center; gap: 1rem;">
                        <input type="range" id="proficiency" name="proficiency" min="0" max="100" value="50" style="flex: 1;">
                        <span id="proficiency_value">50</span>%
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="icon">Icon (Font Awesome class) <span style="color: var(--primary); cursor: pointer;" onclick="openIconPicker()" title="Klik untuk memilih icon">📋</span></label>
                    <div style="display: flex; gap: 10px;">
                        <input type="text" id="icon" name="icon" placeholder="Contoh: fa-code, fa-database" value="fa-code" style="flex: 1;">
                        <button type="button" class="btn btn-secondary" onclick="openIconPicker()" style="white-space: nowrap;">Pilih Icon</button>
                    </div>
                    <small style="color: var(--text-muted); margin-top: 5px; display: block;">Gunakan nama class Font Awesome 6. Contoh: <code>fa-php</code>, <code>fa-react</code>, <code>fa-database</code>, dll.</small>
                </div>
                
                <div class="form-group full">
                    <div style="display: flex; gap: 1rem;">
                        <button type="submit" class="btn btn-primary">Simpan Skill</button>
                        <button type="reset" class="btn btn-outline">Reset Form</button>
                    </div>
                </div>
            </form>
        </div>
        
        <div class="table-container" style="margin-top: 50px;">
            <h2>Daftar Skills</h2>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Proficiency</th>
                        <th>Icon</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($skill = $skills->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($skill['name']); ?></td>
                        <td>
                            <div class="progress-bar" style="width: 100px;">
                                <div style="width: <?php echo $skill['proficiency']; ?>%; background: #3b82f6;"></div>
                            </div>
                            <?php echo $skill['proficiency']; ?>%
                        </td>
                        <td><i class="fas <?php echo htmlspecialchars($skill['icon']); ?>"></i></td>
                        <td>
                            <button class="btn btn-sm btn-secondary" onclick="editSkill(<?php echo htmlspecialchars(json_encode($skill)); ?>)">Edit</button>
                            <a href="?delete=<?php echo $skill['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus skill ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
    
    <!-- ICON PICKER MODAL -->
    <div id="iconModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 1000; overflow-y: auto;">
        <div style="background: var(--bg-card); margin: 20px auto; padding: 30px; border-radius: 10px; max-width: 900px; color: var(--text-light);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <div>
                    <h2 style="margin: 0 0 5px 0;">Pilih Icon Font Awesome 6</h2>
                    <small style="color: var(--text-muted);">Klik icon untuk memilih, atau cari berdasarkan nama</small>
                </div>
                <button onclick="closeIconPicker()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-light);">&times;</button>
            </div>
            
            <div style="margin-bottom: 20px;">
                <input type="text" id="iconSearch" placeholder="Cari icon... (Contoh: php, database, code)" 
                       style="width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: 5px; background: var(--bg-dark); color: var(--text-light);">
            </div>
            
            <div style="background: var(--bg-dark); padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid var(--primary);">
                <p style="margin: 0; font-size: 13px; color: var(--text-muted);">
                    <strong>💡 Tips:</strong> Pilih icon dari daftar di bawah, atau masukkan nama icon secara manual (e.g., fa-php, fa-database, fa-rocket).
                    Lihat <a href="https://fontawesome.com/icons" target="_blank" style="color: var(--primary);">fontawesome.com/icons</a> untuk daftar lengkap.
                </p>
            </div>
            
            <div id="iconList" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(90px, 1fr)); gap: 10px; max-height: 400px; overflow-y: auto;">
                <!-- Icons will be generated by JavaScript -->
            </div>
        </div>
    </div>
    
    <script>
        // List of popular Font Awesome 6 icons for development skills
        const popularIcons = [
            // Languages
            { name: 'PHP', icon: 'fa-php' },
            { name: 'JavaScript', icon: 'fa-js' },
            { name: 'Python', icon: 'fa-python' },
            { name: 'Java', icon: 'fa-java' },
            { name: 'C++', icon: 'fa-cpp' },
            { name: 'C#', icon: 'fa-csharp' },
            { name: 'HTML', icon: 'fa-html5' },
            { name: 'CSS', icon: 'fa-css3' },
            
            // Frameworks
            { name: 'React', icon: 'fa-react' },
            { name: 'Vue', icon: 'fa-vuejs' },
            { name: 'Angular', icon: 'fa-angular' },
            { name: 'Node.js', icon: 'fa-node' },
            { name: 'Docker', icon: 'fa-docker' },
            
            // Databases
            { name: 'Database', icon: 'fa-database' },
            { name: 'MySQL', icon: 'fa-database' },
            { name: 'MongoDB', icon: 'fa-leaf' },
            
            // Tools & General
            { name: 'Code', icon: 'fa-code' },
            { name: 'Git', icon: 'fa-git' },
            { name: 'GitHub', icon: 'fa-github' },
            { name: 'Terminal', icon: 'fa-terminal' },
            { name: 'Laptop', icon: 'fa-laptop' },
            { name: 'Server', icon: 'fa-server' },
            { name: 'Cloud', icon: 'fa-cloud' },
            { name: 'Gear', icon: 'fa-gear' },
            { name: 'Tools', icon: 'fa-tools' },
            { name: 'Wrench', icon: 'fa-wrench' },
            { name: 'Rocket', icon: 'fa-rocket' },
            { name: 'Lightbulb', icon: 'fa-lightbulb' },
            { name: 'Brain', icon: 'fa-brain' },
            { name: 'Chart', icon: 'fa-chart-bar' },
            { name: 'Mobile', icon: 'fa-mobile' },
            { name: 'Responsive', icon: 'fa-object-group' },
            { name: 'Lock', icon: 'fa-lock' },
            { name: 'Shield', icon: 'fa-shield' },
            { name: 'Test', icon: 'fa-flask' },
            { name: 'Book', icon: 'fa-book' },
            { name: 'Graduation', icon: 'fa-graduation-cap' },
            { name: 'Award', icon: 'fa-award' },
            { name: 'Star', icon: 'fa-star' },
        ];
        
        function openIconPicker() {
            document.getElementById('iconModal').style.display = 'block';
            populateIconList(popularIcons);
        }
        
        function closeIconPicker() {
            document.getElementById('iconModal').style.display = 'none';
        }
        
        function populateIconList(icons) {
            const iconList = document.getElementById('iconList');
            iconList.innerHTML = '';
            
            icons.forEach(item => {
                const div = document.createElement('div');
                div.style.cssText = 'text-align: center; padding: 10px; border: 1px solid var(--border-color); border-radius: 5px; cursor: pointer; transition: all 0.3s; background: var(--bg-dark);';
                div.innerHTML = `
                    <div style="font-size: 24px; margin-bottom: 5px;"><i class="fas ${item.icon}"></i></div>
                    <small style="font-size: 11px; color: var(--text-muted);">${item.icon}</small>
                `;
                div.onmouseover = () => {
                    div.style.background = 'var(--primary)';
                    div.style.color = 'white';
                };
                div.onmouseout = () => {
                    div.style.background = 'var(--bg-dark)';
                    div.style.color = 'var(--text-light)';
                };
                div.onclick = () => selectIcon(item.icon);
                iconList.appendChild(div);
            });
        }
        
        function selectIcon(icon) {
            document.getElementById('icon').value = icon;
            closeIconPicker();
        }
        
        // Search functionality
        document.getElementById('iconSearch')?.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const filtered = popularIcons.filter(item => 
                item.name.toLowerCase().includes(searchTerm) || 
                item.icon.toLowerCase().includes(searchTerm)
            );
            populateIconList(filtered.length > 0 ? filtered : popularIcons);
        });
        
        // Close modal when clicking outside
        document.getElementById('iconModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeIconPicker();
            }
        });
    </script>
    
    <script>
        document.getElementById('proficiency').addEventListener('input', function() {
            document.getElementById('proficiency_value').textContent = this.value;
        });
        
        function editSkill(skill) {
            document.getElementById('skill_id').value = skill.id;
            document.getElementById('name').value = skill.name;
            document.getElementById('proficiency').value = skill.proficiency;
            document.getElementById('proficiency_value').textContent = skill.proficiency;
            document.getElementById('icon').value = skill.icon;
            window.scrollTo(0, 0);
        }
    </script>
    
    <script src="<?php echo ASSETS_URL; ?>js/admin.js"></script>
        </main>
    </div>
</body>
</html>
