<?php
require_once '../includes/config.php';
require_once 'auth_check.php';

$page_title = "Pengaturan Admin";
$message = '';
$error = '';

// Get current admin user data
$admin_id = $_SESSION['admin_id'];
$admin_result = $conn->query("SELECT id, username FROM admin_users WHERE id = $admin_id");
$admin_user = $admin_result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'change_username') {
        $new_username = htmlspecialchars($_POST['new_username'] ?? '');
        $current_password = $_POST['current_password'] ?? '';
        
        if (empty($new_username) || empty($current_password)) {
            $error = 'Username baru dan password harus diisi!';
        } else {
            // Verify current password
            $verify_result = $conn->query("SELECT password FROM admin_users WHERE id = $admin_id");
            $verify_user = $verify_result->fetch_assoc();
            
            if (!password_verify($current_password, $verify_user['password'])) {
                $error = 'Password saat ini tidak sesuai!';
            } else {
                // Check if username already exists
                $check_result = $conn->query("SELECT id FROM admin_users WHERE username = '" . $conn->real_escape_string($new_username) . "' AND id != $admin_id");
                
                if ($check_result->num_rows > 0) {
                    $error = 'Username sudah digunakan!';
                } else {
                    $sql = "UPDATE admin_users SET username = '" . $conn->real_escape_string($new_username) . "' WHERE id = $admin_id";
                    if ($conn->query($sql)) {
                        $_SESSION['admin_username'] = $new_username;
                        $admin_user['username'] = $new_username;
                        $message = 'Username berhasil diubah!';
                    } else {
                        $error = 'Error: ' . $conn->error;
                    }
                }
            }
        }
    } 
    
    else if ($action == 'change_password') {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error = 'Semua field password harus diisi!';
        } else if ($new_password !== $confirm_password) {
            $error = 'Password baru tidak cocok!';
        } else if (strlen($new_password) < 6) {
            $error = 'Password minimal 6 karakter!';
        } else {
            // Verify current password
            $verify_result = $conn->query("SELECT password FROM admin_users WHERE id = $admin_id");
            $verify_user = $verify_result->fetch_assoc();
            
            if (!password_verify($current_password, $verify_user['password'])) {
                $error = 'Password saat ini tidak sesuai!';
            } else {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $sql = "UPDATE admin_users SET password = '" . $conn->real_escape_string($hashed_password) . "' WHERE id = $admin_id";
                
                if ($conn->query($sql)) {
                    $message = 'Password berhasil diubah! Silakan login kembali.';
                    // Redirect to login after 2 seconds
                    echo '<meta http-equiv="refresh" content="2;url=login.php">';
                } else {
                    $error = 'Error: ' . $conn->error;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/style.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/admin.css">
</head>
<body class="admin-page">
    <?php include 'sidebar.php'; ?>
    
    <div class="admin-main">
        <?php include 'topbar.php'; ?>
        
        <main class="admin-content">
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="form-container">
            <!-- Username & Password Requirements -->
            <div style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); border-radius: 10px; padding: 20px; margin-bottom: 30px; color: white;">
                <h3 style="margin-top: 0; color: white;">📋 Ketentuan Username & Password</h3>
                <div style="line-height: 2;">
                    <p style="margin: 0.5rem 0;">
                        <strong style="font-size: 1.05rem; color: #ffd700;">Username:</strong>
                        <br><small style="color: #f0f0f0; font-weight: 500; font-size: 0.95rem;">• Minimal 3 karakter, maksimal 20 karakter<br>• Hanya boleh huruf, angka, dan underscore (_)<br>• Tidak boleh dimulai dengan angka</small>
                    </p>
                    <p style="margin: 1rem 0 0.5rem 0; border-top: 1px solid rgba(255,255,255,0.3); padding-top: 1rem;">
                        <strong style="font-size: 1.05rem; color: #ffd700;">Password:</strong>
                        <br><small style="color: #f0f0f0; font-weight: 500; font-size: 0.95rem;">• Minimal 8 karakter<br>• Kombinasi huruf besar, huruf kecil, angka, dan simbol direkomendasikan<br>• Jangan gunakan tanggal lahir atau nama pengguna</small>
                    </p>
                </div>
            </div>
            
            <!-- Change Username Form -->
            <div style="margin-bottom: 40px; padding: 20px; background: var(--bg-card); border-radius: 10px; border: 1px solid var(--border-color);">
                <h2 style="margin-top: 0;">Ubah Username</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="change_username">
                    
                    <div class="form-group">
                        <label for="new_username">Username Baru *</label>
                        <input type="text" id="new_username" name="new_username" required 
                               placeholder="Masukkan username baru"
                               value="<?php echo htmlspecialchars($admin_user['username']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="current_password_1">Password Saat Ini *</label>
                        <input type="password" id="current_password_1" name="current_password" required 
                               placeholder="Masukkan password Anda">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Ubah Username
                    </button>
                </form>
            </div>
            
            <!-- Change Password Form -->
            <div style="padding: 20px; background: var(--bg-card); border-radius: 10px; border: 1px solid var(--border-color);">
                <h2 style="margin-top: 0;">Ubah Password</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="change_password">
                    
                    <div class="form-group">
                        <label for="current_password_2">Password Saat Ini *</label>
                        <input type="password" id="current_password_2" name="current_password" required 
                               placeholder="Masukkan password Anda saat ini">
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">Password Baru *</label>
                        <input type="password" id="new_password" name="new_password" required 
                               placeholder="Masukkan password baru (minimal 6 karakter)"
                               minlength="6">
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Konfirmasi Password Baru *</label>
                        <input type="password" id="confirm_password" name="confirm_password" required 
                               placeholder="Ulangi password baru"
                               minlength="6">
                    </div>
                    
                    <div style="background: #f0f4ff; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid var(--primary);">
                        <p style="margin: 0; color: #555;">
                            <i class="fas fa-info-circle"></i> 
                            <strong>Catatan:</strong> Password harus minimal 6 karakter dan akan langsung berlaku. Anda perlu login kembali.
                        </p>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-lock"></i> Ubah Password
                    </button>
                </form>
            </div>
        </div>
    </main>
    
    <script src="<?php echo ASSETS_URL; ?>js/admin.js"></script>
</body>
</html>
