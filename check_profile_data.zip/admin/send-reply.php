<?php
header('Content-Type: application/json; charset=utf-8');
ob_start();

$response = ['success' => false, 'message' => 'Terjadi kesalahan'];

try {
    require_once '../includes/config.php';
    require_once 'auth_check.php';
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }
    
    $message_id = intval($_POST['message_id'] ?? 0);
    $subject = trim($_POST['subject'] ?? '');
    $reply_message = trim($_POST['reply_message'] ?? '');
    
    if (!$message_id || !$subject || !$reply_message) {
        throw new Exception('Data tidak lengkap');
    }
    
    $stmt = $conn->prepare("SELECT id, name, email FROM contact_messages WHERE id = ?");
    $stmt->bind_param("i", $message_id);
    $stmt->execute();
    $msg_result = $stmt->get_result();
    
    if ($msg_result->num_rows === 0) {
        throw new Exception('Pesan tidak ditemukan');
    }
    
    $original_msg = $msg_result->fetch_assoc();
    $to_email = $original_msg['email'];
    $to_name = $original_msg['name'];
    $stmt->close();
    
    $settings_result = $conn->query("SELECT admin_name, admin_email FROM settings LIMIT 1");
    $from_name = 'Admin';
    $from_email = 'noreply@portfolio.local';
    
    if ($settings_result && $settings_result->num_rows > 0) {
        $settings = $settings_result->fetch_assoc();
        if (!empty($settings['admin_name'])) $from_name = $settings['admin_name'];
        if (!empty($settings['admin_email'])) $from_email = $settings['admin_email'];
    }
    
    // Try to send email
    $mail_sent = false;
    $mail_error = '';
    
    // Check if mail function is available
    if (function_exists('mail')) {
        $headers = "MIME-Version: 1.0\r\nContent-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: " . $from_name . " <" . $from_email . ">\r\n";
        
        $email_body = "<html><head><style>body{font-family:Arial,sans-serif;color:#333;}.container{max-width:600px;margin:0 auto;padding:20px;}.header{background:#3b82f6;color:white;padding:20px;border-radius:5px;margin-bottom:20px;}.content{background:#f5f5f5;padding:20px;border-radius:5px;margin-bottom:20px;}.footer{color:#999;font-size:12px;text-align:center;}</style></head><body><div class='container'><div class='header'><h2>Balasan Pesan</h2></div><div class='content'><p>Halo <strong>" . htmlspecialchars($to_name) . "</strong>,</p><p>Terima kasih telah menghubungi kami. Berikut adalah balasan kami:</p><hr><p><strong>Subjek:</strong> " . htmlspecialchars($subject) . "</p><p>" . nl2br(htmlspecialchars($reply_message)) . "</p><hr><p>Salam hormat,<br><strong>" . htmlspecialchars($from_name) . "</strong></p></div><div class='footer'><p>Email otomatis - jangan membalas email ini</p></div></div></body></html>";
        
        $mail_sent = @mail($to_email, $subject, $email_body, $headers);
        if (!$mail_sent) {
            $mail_error = 'Mail function not configured properly';
        }
    } else {
        $mail_error = 'Mail function not available';
    }
    
    // Mark message as read regardless
    $update_stmt = $conn->prepare("UPDATE contact_messages SET is_read = 1 WHERE id = ?");
    $update_stmt->bind_param("i", $message_id);
    $update_stmt->execute();
    $update_stmt->close();
    
    // Create a log of reply (optional - won't break if table doesn't exist)
    $check_table = $conn->query("SHOW TABLES LIKE 'message_replies'");
    if ($check_table && $check_table->num_rows > 0) {
        $log_stmt = $conn->prepare("INSERT INTO message_replies (message_id, from_name, from_email, subject, reply_message, sent_via_email, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        if ($log_stmt) {
            $sent_via = $mail_sent ? 'email' : 'manual';
            $log_stmt->bind_param("isssss", $message_id, $from_name, $from_email, $subject, $reply_message, $sent_via);
            $log_stmt->execute();
            $log_stmt->close();
        }
    }
    
    $response['success'] = true;
    if ($mail_sent) {
        $response['message'] = 'Balasan berhasil dikirim ke ' . htmlspecialchars($to_email);
    } else {
        $response['message'] = 'Balasan disimpan (Email gagal dikirim - silakan setup mail server)';
    }
    
} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

ob_end_clean();
echo json_encode($response);
?>
