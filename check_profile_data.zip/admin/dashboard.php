<?php
require_once '../includes/config.php';
require_once 'auth_check.php';  // Security check

$admin_username = $_SESSION['admin_username'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Nanang Khasan Bisri</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/style.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="admin-page">
    <?php include 'sidebar.php'; ?>
    
    <!-- MAIN CONTENT -->
    <div class="admin-main">
        <!-- TOP BAR -->
        <?php 
        $page_title = 'Dashboard';
        include 'topbar.php'; 
        ?>
        
        <!-- PAGE CONTENT -->
        <div class="admin-content">
            
            <div class="dashboard-grid">
                <!-- Stats -->
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-newspaper"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Blog Posts</h3>
                        <p class="stat-number">
                            <?php
                            $query = "SELECT COUNT(*) as count FROM blog_posts";
                            $result = $conn->query($query);
                            $row = $result->fetch_assoc();
                            echo $row['count'];
                            ?>
                        </p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-briefcase"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Portfolio</h3>
                        <p class="stat-number">
                            <?php
                            $query = "SELECT COUNT(*) as count FROM portfolios";
                            $result = $conn->query($query);
                            $row = $result->fetch_assoc();
                            echo $row['count'];
                            ?>
                        </p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div class="stat-info">
                        <h3>New Messages</h3>
                        <p class="stat-number">
                            <?php
                            $query = "SELECT COUNT(*) as count FROM contact_messages WHERE is_read = 0";
                            $result = $conn->query($query);
                            $row = $result->fetch_assoc();
                            echo $row['count'];
                            ?>
                        </p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Skills</h3>
                        <p class="stat-number">
                            <?php
                            $query = "SELECT COUNT(*) as count FROM skills";
                            $result = $conn->query($query);
                            $row = $result->fetch_assoc();
                            echo $row['count'];
                            ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- Analytics Stats -->
            <div class="dashboard-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Kunjungan</h3>
                        <p class="stat-number" id="totalVisits">-</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Pengunjung Unik</h3>
                        <p class="stat-number" id="uniqueVisitors">-</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-file"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Halaman Dikunjungi</h3>
                        <p class="stat-number" id="totalPages">-</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-calendar-day"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Hari Ini</h3>
                        <p class="stat-number" id="todayVisits">-</p>
                    </div>
                </div>
            </div>
            

            <!-- Recent Posts -->
            <div class="card mt-40">
                <div class="card-header card-header-responsive">
                    <h2>Blog Posts Terbaru</h2>
                    <a href="blog-posts.php" class="btn btn-primary">Kelola Blog</a>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Judul</th>
                                <th>Kategori</th>
                                <th>Status</th>
                                <th>Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT id, title, category, status, created_at FROM blog_posts ORDER BY created_at DESC LIMIT 5";
                            $result = $conn->query($query);
                            
                            if ($result->num_rows > 0) {
                                while ($post = $result->fetch_assoc()) {
                                    echo '<tr>';
                                    echo '<td>' . htmlspecialchars($post['title']) . '</td>';
                                    echo '<td><span class="badge">' . htmlspecialchars($post['category']) . '</span></td>';
                                    echo '<td><span class="status-' . $post['status'] . '">' . ucfirst($post['status']) . '</span></td>';
                                    echo '<td>' . date('d M Y', strtotime($post['created_at'])) . '</td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo '<tr><td colspan="5" class="text-center">Belum ada artikel</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="<?php echo ASSETS_URL; ?>js/admin.js"></script>
</body>
</html>