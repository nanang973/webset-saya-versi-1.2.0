<?php
session_start();
header('Content-Type: application/json');

// Test if we can access the upload API
$result = [
    'session_started' => true,
    'has_admin_id' => isset($_SESSION['admin_id']),
    'session_data' => $_SESSION
];

echo json_encode($result, JSON_PRETTY_PRINT);
?>
