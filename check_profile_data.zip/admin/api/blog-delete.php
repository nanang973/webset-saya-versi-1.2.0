<?php
require_once '../../includes/config.php';

// Check auth
if (!isset($_SESSION['admin_id'])) {
    http_response_code(401);
    exit('Unauthorized');
}

// Check POST method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed');
}

// Get ID
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;

if ($id <= 0) {
    http_response_code(400);
    exit('Invalid article ID');
}

// Delete artikel
$stmt = $conn->prepare("DELETE FROM blog_posts WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    // Redirect kembali ke halaman blog-articles.php dengan success message
    $_SESSION['message'] = 'Artikel berhasil dihapus!';
    header('Location: ../blog-articles.php');
} else {
    $_SESSION['error'] = 'Gagal menghapus artikel: ' . $stmt->error;
    header('Location: ../blog-articles.php');
}

$stmt->close();
