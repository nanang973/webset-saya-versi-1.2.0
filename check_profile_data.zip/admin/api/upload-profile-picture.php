<?php
// Prevent caching and set JSON header FIRST
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

require_once '../../includes/config.php';

// Session validation for AJAX
if (!isset($_SESSION['admin_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Handle file upload for profile picture
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_picture'])) {
    $response = [
        'success' => false,
        'message' => '',
        'filename' => ''
    ];
    
    $file = $_FILES['profile_picture'];
    
    // Validation
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $response['message'] = 'File upload error: ' . $file['error'];
        http_response_code(400);
        echo json_encode($response);
        exit;
    }
    
    // Check file size (5MB max)
    $max_size = 5 * 1024 * 1024;
    if ($file['size'] > $max_size) {
        $response['message'] = 'File terlalu besar. Maksimal 5MB';
        http_response_code(400);
        echo json_encode($response);
        exit;
    }
    
    // Check MIME type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($mime_type, $allowed_types)) {
        $response['message'] = 'Tipe file tidak diizinkan. Gunakan JPG, PNG, GIF, atau WebP';
        http_response_code(400);
        echo json_encode($response);
        exit;
    }
    
    // Create upload directory if not exists
    $upload_dir = '../../assets/images/profile/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    // Generate unique filename
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'profile_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $filepath = $upload_dir . $filename;
    
    // Move file
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        // Delete old profile picture if exists
        $old_profile = $conn->query("SELECT profile_picture FROM profile LIMIT 1")->fetch_assoc();
        if ($old_profile && !empty($old_profile['profile_picture'])) {
            $old_file = $upload_dir . basename($old_profile['profile_picture']);
            if (file_exists($old_file)) {
                unlink($old_file);
            }
        }
        
        // Update database
        $relative_path = 'assets/images/profile/' . $filename;
        $sql = "UPDATE profile SET profile_picture = '" . $conn->real_escape_string($relative_path) . "' LIMIT 1";
        
        if ($conn->query($sql)) {
            $response['success'] = true;
            $response['message'] = 'Foto profil berhasil diperbarui!';
            $response['filename'] = $relative_path;
        } else {
            $response['message'] = 'Error: ' . $conn->error;
            unlink($filepath); // Remove file if DB update fails
        }
    } else {
        $response['message'] = 'Gagal mengunggah file';
        http_response_code(500);
    }
    
    http_response_code($response['success'] ? 200 : 400);
    echo json_encode($response);
    exit;

http_response_code(400);
echo json_encode(['success' => false, 'message' => 'Invalid request']);
?>
