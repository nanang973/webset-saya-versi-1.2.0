<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

require_once '../../includes/config.php';

// Session validation
if (!isset($_SESSION['admin_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Handle file upload for blog images
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['blog_image'])) {
    $response = [
        'success' => false,
        'message' => '',
        'url' => ''
    ];
    
    $file = $_FILES['blog_image'];
    
    // Validation
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $response['message'] = 'File upload error: ' . $file['error'];
        http_response_code(400);
        echo json_encode($response);
        exit;
    }
    
    // Check file size (10MB max for blog images)
    $max_size = 10 * 1024 * 1024;
    if ($file['size'] > $max_size) {
        $response['message'] = 'File terlalu besar. Maksimal 10MB';
        http_response_code(400);
        echo json_encode($response);
        exit;
    }
    
    // Check MIME type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($mime_type, $allowed_types)) {
        $response['message'] = 'Tipe file tidak diizinkan. Gunakan JPG, PNG, GIF, atau WebP';
        http_response_code(400);
        echo json_encode($response);
        exit;
    }
    
    // Create upload directory if not exists
    $upload_dir = '../../assets/images/blog/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    // Generate unique filename
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'blog_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $filepath = $upload_dir . $filename;
    
    // Move file
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        // File uploaded successfully
        $relative_path = 'assets/images/blog/' . $filename;
        
        $response['success'] = true;
        $response['message'] = 'Gambar berhasil diupload!';
        $response['url'] = BASE_URL . $relative_path;
        http_response_code(200);
    } else {
        $response['message'] = 'Gagal mengunggah file';
        http_response_code(500);
    }
    
    echo json_encode($response);
    exit;
}

http_response_code(400);
echo json_encode(['success' => false, 'message' => 'Invalid request']);
?>
