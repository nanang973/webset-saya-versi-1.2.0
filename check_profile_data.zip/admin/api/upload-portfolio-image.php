<?php
require_once '../../includes/config.php';

header('Content-Type: application/json');

// Security check
if (!isset($_SESSION['admin_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

// Check if file is uploaded
if (!isset($_FILES['portfolio_image']) || $_FILES['portfolio_image']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Tidak ada file atau terjadi error saat upload']);
    exit;
}

$file = $_FILES['portfolio_image'];

// Validate MIME type
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime_type = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

$allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
if (!in_array($mime_type, $allowed_types)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Tipe file tidak diizinkan']);
    exit;
}

// Validate file size (10MB max)
$max_size = 10 * 1024 * 1024;
if ($file['size'] > $max_size) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'File terlalu besar. Maksimal 10MB']);
    exit;
}

// Create upload directory
$upload_dir = '../../assets/images/portfolio/';
if (!is_dir($upload_dir)) {
    if (!mkdir($upload_dir, 0755, true)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Gagal membuat direktori upload']);
        exit;
    }
}

// Generate unique filename
$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = 'portfolio_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
$filepath = $upload_dir . $filename;

// Move uploaded file
if (move_uploaded_file($file['tmp_name'], $filepath)) {
    $image_path = 'assets/images/portfolio/' . $filename;
    echo json_encode([
        'success' => true,
        'image' => $image_path,
        'message' => 'Gambar berhasil diunggah'
    ]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Gagal memindahkan file']);
}
?>
