<?php
// API untuk Save/Update Blog Articles
error_reporting(0);
ini_set('display_errors', 0);

require_once '../../includes/config.php';

// Set header JSON FIRST before any output
header('Content-Type: application/json; charset=utf-8');
ob_clean();

// Check auth
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$action = $_POST['action'] ?? '';
$id = $_POST['id'] ?? null;
$title = $_POST['title'] ?? '';
$slug = $_POST['slug'] ?? '';
$excerpt = $_POST['excerpt'] ?? '';
$featured_image = $_POST['featured_image'] ?? '';
$category = $_POST['category'] ?? '';
$tags = $_POST['tags'] ?? '';
$content = $_POST['content'] ?? '[]';
$status = $_POST['status'] ?? 'draft';

// Validation
if (empty($title) || empty($slug)) {
    echo json_encode(['success' => false, 'message' => 'Judul dan slug tidak boleh kosong']);
    exit;
}

// Validate JSON content
$content_array = json_decode($content, true);
if (!$content_array) {
    echo json_encode(['success' => false, 'message' => 'Format konten tidak valid']);
    exit;
}

// Sanitize slug
$slug = preg_replace('/[^a-z0-9-]/', '', strtolower($slug));
$slug = preg_replace('/-+/', '-', $slug);
$slug = trim($slug, '-');

try {
    if ($action === 'create') {
        // Check if slug already exists
        $checkStmt = $conn->prepare("SELECT id FROM blog_posts WHERE slug = ?");
        $checkStmt->bind_param("s", $slug);
        $checkStmt->execute();
        if ($checkStmt->get_result()->num_rows > 0) {
            echo json_encode(['success' => false, 'message' => 'Slug sudah digunakan']);
            exit;
        }

        // Insert new article
        $stmt = $conn->prepare("
            INSERT INTO blog_posts 
            (title, slug, excerpt, featured_image, content, category, tags, status, author_id, published_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $author_id = $_SESSION['admin_id'];
        $published_at = ($status === 'published') ? date('Y-m-d H:i:s') : null;

        $stmt->bind_param(
            "ssssssssss",
            $title,
            $slug,
            $excerpt,
            $featured_image,
            $content,
            $category,
            $tags,
            $status,
            $author_id,
            $published_at
        );

        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Artikel berhasil dibuat',
                'article_id' => $stmt->insert_id
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $stmt->error]);
        }

    } elseif ($action === 'update') {
        // Update existing article
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'ID artikel tidak ditemukan']);
            exit;
        }

        // Check if slug is used by another article
        $checkStmt = $conn->prepare("SELECT id FROM blog_posts WHERE slug = ? AND id != ?");
        $checkStmt->bind_param("si", $slug, $id);
        $checkStmt->execute();
        if ($checkStmt->get_result()->num_rows > 0) {
            echo json_encode(['success' => false, 'message' => 'Slug sudah digunakan']);
            exit;
        }

        $published_at = ($status === 'published') ? date('Y-m-d H:i:s') : null;

        $stmt = $conn->prepare("
            UPDATE blog_posts 
            SET title = ?, slug = ?, excerpt = ?, featured_image = ?, 
                content = ?, category = ?, tags = ?, status = ?, published_at = ?, updated_at = NOW()
            WHERE id = ?
        ");

        $stmt->bind_param(
            "sssssssssi",
            $title,
            $slug,
            $excerpt,
            $featured_image,
            $content,
            $category,
            $tags,
            $status,
            $published_at,
            $id
        );

        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Artikel berhasil diperbarui'
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $stmt->error]);
        }

    } else {
        echo json_encode(['success' => false, 'message' => 'Action tidak dikenali']);
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
