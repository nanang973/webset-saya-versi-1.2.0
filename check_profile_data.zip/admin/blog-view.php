<?php
require_once '../includes/config.php';

$slug = $_GET['slug'] ?? '';

if (!$slug) {
    header('Location: ../index.php');
    exit;
}

// Get article
$stmt = $conn->prepare("
    SELECT * FROM blog_articles 
    WHERE slug = ? AND status = 'published'
");
$stmt->bind_param("s", $slug);
$stmt->execute();
$result = $stmt->get_result();
$article = $result->fetch_assoc();

if (!$article) {
    header('Location: ../index.php');
    exit;
}

// Update view count
$update_stmt = $conn->prepare("UPDATE blog_articles SET view_count = view_count + 1 WHERE id = ?");
$update_stmt->bind_param("i", $article['id']);
$update_stmt->execute();

// Decode content
$content_blocks = json_decode($article['content'], true) ?? [];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($article['title']); ?> - Nanang Khasan</title>
    <meta name="description" content="<?php echo htmlspecialchars($article['excerpt']); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    
    <style>
        :root {
            --primary: #3b82f6;
            --primary-dark: #1e40af;
            --bg-dark: #000000;
            --bg-card: #111111;
            --text-light: #ffffff;
            --text-muted: #9ca3af;
            --border-color: #1e40af;
            --success: #10b981;
            
            --spacing-md: 1.5rem;
            --spacing-lg: 2rem;
            --radius-lg: 0.75rem;
            
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-light);
            line-height: 1.6;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 0 var(--spacing-md);
        }

        /* Header */
        .header {
            background: var(--bg-card);
            border-bottom: 1px solid var(--border-color);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .navbar {
            padding: 1rem 0;
        }

        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo a {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 700;
            font-size: 1.3rem;
            transition: var(--transition);
        }

        .logo a:hover {
            transform: translateY(-2px);
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            transition: var(--transition);
            font-weight: 500;
        }

        .nav-links a:hover {
            color: var(--primary);
        }

        /* Article Hero */
        .article-hero {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(30, 58, 138, 0.1) 100%);
            border-bottom: 2px solid var(--primary);
            padding: 60px var(--spacing-md);
            margin-bottom: 40px;
        }

        .article-category {
            display: inline-block;
            background: var(--primary);
            color: white;
            padding: 6px 14px;
            border-radius: var(--radius-lg);
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 1rem;
        }

        .article-hero h1 {
            font-size: 2.5rem;
            color: var(--text-light);
            margin-bottom: 1rem;
            line-height: 1.3;
        }

        .article-meta {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            color: var(--text-muted);
            font-size: 0.95rem;
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .meta-item i {
            color: var(--primary);
        }

        /* Article Content */
        .article-container {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-lg);
            padding: 40px;
            margin-bottom: 60px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        }

        .article-content {
            font-size: 1.05rem;
            line-height: 1.8;
            color: var(--text-light);
        }

        .article-content h1,
        .article-content h2,
        .article-content h3,
        .article-content h4 {
            margin: 25px 0 15px;
            color: var(--primary);
        }

        .article-content h1 {
            font-size: 2.2rem;
        }

        .article-content h2 {
            font-size: 1.8rem;
        }

        .article-content h3 {
            font-size: 1.4rem;
        }

        .article-content h4 {
            font-size: 1.1rem;
        }

        .article-content p {
            margin-bottom: 1.5rem;
            text-align: justify;
        }

        .article-content img {
            max-width: 100%;
            height: auto;
            border-radius: var(--radius-lg);
            margin: 25px 0;
            display: block;
        }

        .article-content blockquote {
            border-left: 4px solid var(--primary);
            padding: 20px 25px;
            margin: 25px 0;
            background: rgba(59, 130, 246, 0.1);
            font-style: italic;
            color: var(--text-muted);
        }

        .article-content code {
            background: var(--bg-dark);
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
            color: var(--primary);
        }

        .article-content pre {
            background: var(--bg-dark);
            padding: 20px;
            border-radius: var(--radius-lg);
            overflow-x: auto;
            margin: 20px 0;
            border: 1px solid var(--border-color);
        }

        .article-content pre code {
            padding: 0;
            background: transparent;
            color: var(--text-light);
            font-size: 0.9rem;
        }

        .article-content ul,
        .article-content ol {
            margin-left: 30px;
            margin-bottom: 20px;
        }

        .article-content li {
            margin-bottom: 8px;
        }

        /* Article Footer */
        .article-footer {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-lg);
            padding: 30px 40px;
            margin-bottom: 60px;
            border-top: 3px solid var(--primary);
        }

        .author-info {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 20px;
        }

        .author-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: white;
        }

        .author-details h3 {
            color: var(--primary);
            margin-bottom: 5px;
        }

        .author-details p {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        /* Footer */
        .footer {
            background: var(--bg-card);
            border-top: 1px solid var(--border-color);
            padding: 40px var(--spacing-md) 20px;
        }

        .footer-content {
            text-align: center;
            color: var(--text-muted);
        }

        @media (max-width: 768px) {
            .article-hero h1 {
                font-size: 1.8rem;
            }

            .article-container {
                padding: 25px;
            }

            .article-hero {
                padding: 40px var(--spacing-md);
            }

            .author-info {
                flex-direction: column;
                text-align: center;
            }

            .article-meta {
                flex-direction: column;
                gap: 10px;
            }

            .nav-links {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar">
            <div class="container">
                <div class="navbar-content">
                    <div class="logo">
                        <a href="../index.php">
                            <i class="fas fa-code"></i>
                            <span>Nanang Khasan</span>
                        </a>
                    </div>
                    <ul class="nav-links">
                        <li><a href="../index.php">Beranda</a></li>
                        <li><a href="../pages/about.php">Tentang</a></li>
                        <li><a href="../pages/portfolio.php">Portfolio</a></li>
                        <li><a href="#" style="color: var(--primary);">Blog</a></li>
                        <li><a href="../pages/contact.php">Kontak</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <!-- Article Hero -->
        <section class="article-hero">
            <div class="container">
                <?php if ($article['category']): ?>
                <span class="article-category"><?php echo htmlspecialchars($article['category']); ?></span>
                <?php endif; ?>
                
                <h1><?php echo htmlspecialchars($article['title']); ?></h1>
                
                <div class="article-meta">
                    <div class="meta-item">
                        <i class="fas fa-calendar"></i>
                        <span><?php echo date('d F Y', strtotime($article['published_at'])); ?></span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-user"></i>
                        <span>Nanang Khasan Bisri</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-eye"></i>
                        <span><?php echo number_format($article['view_count']); ?> views</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Article Container -->
        <div class="container">
            <!-- Article Content -->
            <article class="article-container">
                <div class="article-content">
                    <?php
                    foreach ($content_blocks as $block) {
                        switch ($block['type']) {
                            case 'heading':
                                $level = $block['content']['level'] ?? 'h2';
                                echo "<$level>" . htmlspecialchars($block['content']['text']) . "</$level>";
                                break;

                            case 'paragraph':
                                echo "<p>" . nl2br(htmlspecialchars($block['content']['text'])) . "</p>";
                                break;

                            case 'image':
                                if ($block['content']['url']) {
                                    echo '<img src="' . htmlspecialchars($block['content']['url']) . '" alt="Article image">';
                                }
                                break;

                            case 'quote':
                                echo "<blockquote>" . htmlspecialchars($block['content']['text']) . "</blockquote>";
                                break;

                            case 'code':
                                echo "<pre><code>" . htmlspecialchars($block['content']['text']) . "</code></pre>";
                                break;

                            case 'video':
                                if ($block['content']['url']) {
                                    echo '<iframe width="100%" height="400" src="' . htmlspecialchars($block['content']['url']) . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen style="border-radius: 8px; margin: 20px 0;"></iframe>';
                                }
                                break;

                            case 'list':
                                $items = $block['content']['items'] ?? [];
                                $tag = ($block['content']['style'] ?? 'unordered') === 'ordered' ? 'ol' : 'ul';
                                echo "<$tag>";
                                foreach ($items as $item) {
                                    echo "<li>" . htmlspecialchars($item) . "</li>";
                                }
                                echo "</$tag>";
                                break;

                            case 'spacer':
                                $height = $block['content']['height'] ?? 20;
                                echo "<div style='height: " . intval($height) . "px;'></div>";
                                break;
                        }
                    }
                    ?>
                </div>
            </article>

            <!-- Article Footer -->
            <div class="article-footer">
                <div class="author-info">
                    <div class="author-avatar">
                        <i class="fas fa-pen-fancy"></i>
                    </div>
                    <div class="author-details">
                        <h3>Nanang Khasan Bisri</h3>
                        <p>Full Stack Web Developer & Content Creator</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <p>&copy; 2026 Nanang Khasan Bisri. Semua hak dilindungi.</p>
            </div>
        </div>
    </footer>
</body>
</html>
