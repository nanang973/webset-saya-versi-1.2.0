<?php
// Test setup database blog_articles
require_once '../includes/config.php';

echo "<h2>Blog Articles Table Check</h2>";

// Check if table exists
$result = $conn->query("SELECT * FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'blog_articles'");

if ($result && $result->num_rows > 0) {
    echo "<p style='color: green;'><strong>✓ Table blog_articles sudah ada!</strong></p>";
    
    // Count articles
    $count = $conn->query("SELECT COUNT(*) as total FROM blog_articles");
    $row = $count->fetch_assoc();
    echo "<p>Total artikel: <strong>" . $row['total'] . "</strong></p>";
    
    // Show table structure
    echo "<h3>Table Structure:</h3>";
    $structure = $conn->query("DESCRIBE blog_articles");
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th></tr>";
    while ($field = $structure->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($field['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($field['Type']) . "</td>";
        echo "<td>" . htmlspecialchars($field['Null']) . "</td>";
        echo "<td>" . htmlspecialchars($field['Key'] ?? '') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
} else {
    echo "<p style='color: red;'><strong>✗ Table blog_articles TIDAK ada!</strong></p>";
    echo "<p>Klik link ini untuk setup: <a href='setup-blog.php'><strong>Setup Database</strong></a></p>";
}

echo "<hr>";
echo "<p><a href='blog-articles.php'>← Back to Blog Articles</a></p>";
?>
