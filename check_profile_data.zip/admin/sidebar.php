<?php
/**
 * ADMIN SIDEBAR - Include di semua halaman admin
 */
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="admin-sidebar" id="adminSidebar">
    <div class="sidebar-brand">
        <h2>Admin Panel</h2>
    </div>
    
    <nav class="sidebar-menu">
        <a href="dashboard.php" class="menu-item <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
        <a href="blog-articles.php" class="menu-item <?php echo $current_page == 'blog-articles.php' || $current_page == 'blog-builder.php' || $current_page == 'blog-posts.php' ? 'active' : ''; ?>">
            <i class="fas fa-newspaper"></i>
            <span>Blog</span>
        </a>
        <a href="portfolio.php" class="menu-item <?php echo $current_page == 'portfolio.php' ? 'active' : ''; ?>">
            <i class="fas fa-briefcase"></i>
            <span>Portfolio</span>
        </a>
        <a href="profile.php" class="menu-item <?php echo $current_page == 'profile.php' || $current_page == 'skills.php' ? 'active' : ''; ?>">
            <i class="fas fa-user"></i>
            <span>Profil</span>
        </a>
        <a href="messages.php" class="menu-item <?php echo $current_page == 'messages.php' ? 'active' : ''; ?>">
            <i class="fas fa-envelope"></i>
            <span>Pesan Masuk</span>
        </a>
        <a href="settings.php" class="menu-item <?php echo $current_page == 'settings.php' ? 'active' : ''; ?>">
            <i class="fas fa-cog"></i>
            <span>Pengaturan</span>
        </a>
    </nav>
    
    <div class="sidebar-footer">
        <p>Admin: <?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'Admin'); ?></p>
        <a href="logout.php" class="btn btn-sm btn-outline" style="width: 100%;">Logout</a>
    </div>
</aside>
