<?php
require_once '../includes/config.php';
require_once 'auth_check.php';  // Security check

$action = $_GET['action'] ?? 'list';
$message = '';
$error = '';

// DELETE - dengan POST + CSRF token
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $action == 'delete') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = 'Request tidak valid (CSRF token)!';
    } else {
        $id = intval($_POST['id'] ?? 0);
        if ($id > 0) {
            // Get file path sebelum delete
            $stmt = $conn->prepare("SELECT html_file FROM blog_posts WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $post = $result->fetch_assoc();
            $stmt->close();
            
            // Delete dari database menggunakan prepared statement
            $delete_stmt = $conn->prepare("DELETE FROM blog_posts WHERE id = ?");
            $delete_stmt->bind_param("i", $id);
            
            if ($delete_stmt->execute()) {
                // Delete file if exists
                if (!empty($post['html_file'])) {
                    $file_path = '../' . $post['html_file'];
                    if (file_exists($file_path)) {
                        unlink($file_path);
                    }
                }
                $message = 'Artikel berhasil dihapus!';
            } else {
                $error = 'Gagal menghapus artikel: ' . $delete_stmt->error;
            }
            $delete_stmt->close();
        }
    }
    $action = 'list';
}

// Generate CSRF token untuk form
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ADD/EDIT
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $action != 'delete') {
    $id = isset($_GET['id']) ? intval($_GET['id']) : null;
    $title = htmlspecialchars($_POST['title'] ?? '', ENT_QUOTES, 'UTF-8');
    $category = htmlspecialchars($_POST['category'] ?? '', ENT_QUOTES, 'UTF-8');
    $description = htmlspecialchars($_POST['description'] ?? '', ENT_QUOTES, 'UTF-8');
    $status = htmlspecialchars($_POST['status'] ?? 'draft', ENT_QUOTES, 'UTF-8');
    $image = htmlspecialchars($_POST['image'] ?? '', ENT_QUOTES, 'UTF-8');
    $html_file = htmlspecialchars($_POST['html_file'] ?? '', ENT_QUOTES, 'UTF-8');
    
    if (empty($title) || empty($description)) {
        $error = 'Judul dan deskripsi harus diisi!';
    } else {
        // Handle HTML file upload
        if (isset($_FILES['html_file']) && $_FILES['html_file']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['html_file'];
            
            // Validate file type - check MIME type
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime_type = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            
            if ($mime_type !== 'text/html' && $mime_type !== 'text/plain') {
                $error = 'File harus berupa HTML (.html) dengan MIME type yang benar!';
            } else if ($file['size'] > 5 * 1024 * 1024) { // 5MB max
                $error = 'File terlalu besar. Maksimal 5MB!';
            } else {
                // Create directory if not exists
                $upload_dir = '../assets/blog-html/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                    // Create .htaccess untuk prevent execution
                    file_put_contents($upload_dir . '.htaccess', "AddType text/plain .html\n");
                }
                
                // Generate unique filename
                $filename = 'blog_' . time() . '_' . bin2hex(random_bytes(4)) . '.html';
                $filepath = $upload_dir . $filename;
                
                if (move_uploaded_file($file['tmp_name'], $filepath)) {
                    $html_file = 'assets/blog-html/' . $filename;
                    
                    // Delete old HTML file if exists
                    if ($id) {
                        $old_stmt = $conn->prepare("SELECT html_file FROM blog_posts WHERE id = ?");
                        $old_stmt->bind_param("i", $id);
                        $old_stmt->execute();
                        $old_result = $old_stmt->get_result();
                        $old_post = $old_result->fetch_assoc();
                        $old_stmt->close();
                        
                        if (!empty($old_post['html_file'])) {
                            $old_file = '../' . $old_post['html_file'];
                            if (file_exists($old_file)) {
                                unlink($old_file);
                            }
                        }
                    }
                } else {
                    $error = 'Gagal mengunggah file HTML!';
                }
            }
        }
        
        if (empty($error)) {
            if ($id) {
                // Update - dengan prepared statement
                if (!empty($html_file)) {
                    $stmt = $conn->prepare("UPDATE blog_posts SET title=?, category=?, description=?, status=?, image=?, html_file=? WHERE id=?");
                    $stmt->bind_param("ssssssi", $title, $category, $description, $status, $image, $html_file, $id);
                } else {
                    $stmt = $conn->prepare("UPDATE blog_posts SET title=?, category=?, description=?, status=?, image=? WHERE id=?");
                    $stmt->bind_param("sssssi", $title, $category, $description, $status, $image, $id);
                }
                $message = 'Artikel berhasil diperbarui!';
            } else {
                // Insert - dengan prepared statement
                if (!empty($html_file)) {
                    $stmt = $conn->prepare("INSERT INTO blog_posts (title, category, description, status, image, html_file) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("ssssss", $title, $category, $description, $status, $image, $html_file);
                } else {
                    $error = 'File HTML harus diupload untuk artikel baru!';
                    $stmt = null;
                }
            }
            
            if ($stmt) {
                if ($stmt->execute()) {
                    $action = 'list';
                } else {
                    $error = 'Terjadi kesalahan: ' . $conn->error;
                }
                $stmt->close();
            }
        }
    }
}

// GET EDIT DATA
$edit_post = null;
if ($action == 'edit' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM blog_posts WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $edit_post = $result->fetch_assoc();
    $stmt->close();
    
    if (!$edit_post) {
        header("Location: blog-posts.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Posts - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/style.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/admin.css">
</head>
<body class="admin-page">
    <?php include 'sidebar.php'; ?>
    
    <!-- MAIN CONTENT -->
    <div class="admin-main">
        <?php 
        $page_title = $action == 'edit' ? 'Edit Artikel' : 'Kelola Blog Posts';
        include 'topbar.php'; 
        ?>
        
        <main class="admin-content">
            <?php if ($message): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($action == 'list'): ?>
                <!-- LIST VIEW -->
                <div class="form-container">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                        <h2>Daftar Artikel Blog</h2>
                        <a href="blog-posts.php?action=create" class="btn btn-primary">+ Tambah Artikel</a>
                    </div>
                    
                    <div class="table-container">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Judul</th>
                                    <th>Kategori</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT id, title, category, status, created_at FROM blog_posts ORDER BY created_at DESC";
                                $result = $conn->query($query);
                                
                                if ($result->num_rows > 0) {
                                    while ($post = $result->fetch_assoc()) {
                                        echo '<tr>';
                                        echo '<td><strong>' . htmlspecialchars($post['title']) . '</strong></td>';
                                        echo '<td>' . htmlspecialchars($post['category']) . '</td>';
                                        echo '<td><span class="status-' . $post['status'] . '">' . ucfirst($post['status']) . '</span></td>';
                                        echo '<td>' . date('d M Y', strtotime($post['created_at'])) . '</td>';
                                        echo '<td>';
                                        echo '<a href="blog-posts.php?action=edit&id=' . $post['id'] . '" class="btn btn-sm btn-secondary">Edit</a> ';
                                        echo '<form method="POST" action="blog-posts.php?action=delete" style="display:inline;">';
                                        echo '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($_SESSION['csrf_token']) . '">';
                                        echo '<input type="hidden" name="id" value="' . $post['id'] . '">';
                                        echo '<button type="submit" class="btn btn-sm btn-danger" onclick="return confirm(\'Yakin hapus artikel ini?\')">Hapus</button>';
                                        echo '</form>';
                                        echo '</td>';
                                        echo '</tr>';
                                    }
                                } else {
                                    echo '<tr><td colspan="5" style="text-align: center; padding: 2rem;">Belum ada artikel</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            
            <?php else: ?>
                <!-- FORM VIEW -->
                <div class="form-container">
                    <h2><?php echo $action == 'edit' ? 'Edit Artikel' : 'Tambah Artikel Baru'; ?></h2>
                    <form method="POST" enctype="multipart/form-data" class="admin-form">
                        <div class="form-group full">
                            <label for="title">Judul Artikel *</label>
                            <input type="text" id="title" name="title" required value="<?php echo htmlspecialchars($edit_post['title'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="category">Kategori</label>
                            <input type="text" id="category" name="category" value="<?php echo htmlspecialchars($edit_post['category'] ?? ''); ?>">
                        </div>
                        
                        <!-- Image Upload Section -->
                        <div class="form-group full">
                            <label>Gambar Artikel</label>
                            <div id="image-upload-section" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 10px; padding: 20px; margin-bottom: 1rem; text-align: center;">
                                <div id="image-preview" style="margin-bottom: 15px;">
                                    <?php if (!empty($edit_post['image'])): ?>
                                        <img src="<?php echo htmlspecialchars(BASE_URL . $edit_post['image']); ?>" alt="Preview" style="max-width: 100%; max-height: 200px; border-radius: 8px;">
                                    <?php else: ?>
                                        <div style="color: white; opacity: 0.7;">
                                            <i class="fas fa-image" style="font-size: 3rem;"></i>
                                            <p>Belum ada gambar</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <input type="file" id="blog_image" name="blog_image" accept="image/*" style="display: none;">
                                <button type="button" onclick="document.getElementById('blog_image').click();" class="btn btn-light">
                                    <i class="fas fa-upload"></i> Pilih Gambar
                                </button>
                                <input type="hidden" id="image" name="image" value="<?php echo htmlspecialchars($edit_post['image'] ?? ''); ?>">
                                <div id="upload-status" style="margin-top: 10px; color: white; display: none;"></div>
                            </div>
                        </div>
                        
                        <!-- Description Section -->
                        <div class="form-group full">
                            <label for="description">Deskripsi Singkat Artikel *</label>
                            <textarea id="description" name="description" rows="3" required placeholder="Deskripsi singkat untuk preview artikel"><?php echo htmlspecialchars($edit_post['description'] ?? ''); ?></textarea>
                        </div>
                        
                        <!-- HTML File Upload Section -->
                        <div class="form-group full">
                            <label>File HTML Artikel <?php echo $action != 'edit' ? '*' : ''; ?></label>
                            <div style="background: linear-gradient(135deg, #764ba2 0%, #667eea 100%); border-radius: 10px; padding: 20px; margin-bottom: 1rem; text-align: center;">
                                <div style="margin-bottom: 15px; color: white;">
                                    <?php if (!empty($edit_post['html_file'])): ?>
                                        <p><i class="fas fa-file-code"></i> File sudah di-upload</p>
                                        <small><?php echo htmlspecialchars($edit_post['html_file']); ?></small>
                                    <?php else: ?>
                                        <p style="opacity: 0.7;">Belum ada file HTML</p>
                                    <?php endif; ?>
                                </div>
                                <input type="file" id="html_file_input" name="html_file" accept=".html" style="display: none;">
                                <button type="button" onclick="document.getElementById('html_file_input').click();" class="btn btn-light">
                                    <i class="fas fa-upload"></i> Pilih File HTML
                                </button>
                                <div id="html-upload-status" style="margin-top: 10px; color: white; display: none;"></div>
                                <small style="display: block; margin-top: 10px; color: white; opacity: 0.8;">Format: .html, Ukuran maksimal: 5MB</small>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select id="status" name="status">
                                <option value="draft" <?php echo ($edit_post['status'] ?? '') == 'draft' ? 'selected' : ''; ?>>Draft</option>
                                <option value="published" <?php echo ($edit_post['status'] ?? '') == 'published' ? 'selected' : ''; ?>>Published</option>
                            </select>
                        </div>
                        
                        <div class="form-group full">
                            <div style="display: flex; gap: 1rem;">
                                <button type="submit" class="btn btn-primary">Simpan Artikel</button>
                                <a href="blog-posts.php" class="btn btn-outline">Batal</a>
                            </div>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="<?php echo ASSETS_URL; ?>js/admin.js"></script>
    <script>
        // Handle blog image upload
        document.getElementById('blog_image').addEventListener('change', function(e) {
            const file = this.files[0];
            if (!file) return;
            
            const uploadStatus = document.getElementById('upload-status');
            const imagePreview = document.getElementById('image-preview');
            
            uploadStatus.style.display = 'block';
            uploadStatus.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mengunggah...';
            
            const formData = new FormData();
            formData.append('blog_image', file);
            formData.append('alt_text', document.getElementById('title').value);
            
            fetch('<?php echo BASE_URL; ?>admin/api/upload-blog-image.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error('HTTP ' + response.status + ': ' + text);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    uploadStatus.innerHTML = '<i class="fas fa-check"></i> ' + data.message;
                    uploadStatus.style.color = '#2ecc71';
                    
                    // Update hidden input with image URL
                    document.getElementById('image').value = data.url.replace('<?php echo BASE_URL; ?>', '');
                    
                    // Update preview
                    imagePreview.innerHTML = '<img src="' + data.url + '" alt="Preview" style="max-width: 100%; max-height: 200px; border-radius: 8px;">';
                    
                    setTimeout(() => {
                        uploadStatus.style.display = 'none';
                    }, 3000);
                } else {
                    uploadStatus.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + data.message;
                    uploadStatus.style.color = '#e74c3c';
                }
            })
            .catch(error => {
                uploadStatus.innerHTML = '<i class="fas fa-exclamation-circle"></i> Error: ' + error.message;
                uploadStatus.style.color = '#e74c3c';
                console.error('Upload error:', error);
            });
        });
        
        // Handle HTML file selection display
        document.getElementById('html_file_input').addEventListener('change', function(e) {
            const file = this.files[0];
            if (file) {
                const statusDiv = document.getElementById('html-upload-status');
                statusDiv.style.display = 'block';
                statusDiv.innerHTML = '<i class="fas fa-check"></i> File terpilih: ' + file.name + ' (' + Math.round(file.size / 1024) + ' KB)';
            }
        });
    </script>        </main>
    </div>
</body>
</html>