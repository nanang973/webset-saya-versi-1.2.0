<?php
require_once '../includes/config.php';

// Rate limiting untuk login attempts (5 attempts per 5 minutes)
$login_identifier = 'login_' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
if (!checkRateLimit($login_identifier, 5, 300)) {
    die('<h2 style="color:red; text-align:center; margin-top:50px;">Terlalu banyak percobaan login. Coba lagi dalam 5 menit.</h2>');
}

// Generate CSRF token jika belum ada
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = '';

// Cek login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = 'Request tidak valid (CSRF token)!';
    } else {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            $error = 'Username dan password harus diisi!';
        } else {
            // Sanitize username
            $username = htmlspecialchars(trim($username), ENT_QUOTES, 'UTF-8');
            
            // Query user dengan prepared statement (aman dari SQL injection)
            $stmt = $conn->prepare("SELECT id, username, password FROM admin_users WHERE username = ?");
            if (!$stmt) {
                $error = 'Database error: ' . $conn->error;
            } else {
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $user = $result->fetch_assoc();
                    
                    // Cek password dengan password_verify (bcrypt)
                    if (password_verify($password, $user['password'])) {
                        // Set session dengan security
                        $_SESSION['admin_id'] = $user['id'];
                        $_SESSION['admin_username'] = $user['username'];
                        $_SESSION['admin_created'] = time();
                        $_SESSION['last_activity'] = time();
                        $_SESSION['user_agent'] = md5($_SERVER['HTTP_USER_AGENT'] ?? '');
                        $_SESSION['ip_address'] = md5($_SERVER['REMOTE_ADDR'] ?? '');
                        
                        // Regenerate session ID untuk prevent fixation
                        session_regenerate_id(true);
                        
                        header("Location: dashboard.php");
                        exit;
                    }
                }
                $stmt->close();
                
                // Generic error message (jangan reveal apakah username atau password yang salah)
                $error = 'Username atau password salah!';
            }
        }
    }
}
?>
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Nanang Khasan Bisri</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/style.css">
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>css/admin.css">
</head>
<body class="admin-login-page">
    <div class="login-container">
        <div class="login-box">
            <h1>Admin Panel</h1>
            <p>Masuk ke dashboard admin</p>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if (isset($_GET['timeout'])): ?>
                <div class="alert alert-warning">Sesi Anda telah berakhir. Silakan login kembali.</div>
            <?php endif; ?>
            
            <form method="POST" class="login-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required autofocus>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Login</button>
            </form>
        </div>
    </div>
</body>
</html>
