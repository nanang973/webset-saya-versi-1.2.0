// ============================================
// ADMIN JAVASCRIPT
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    // Sidebar Toggle Logic for Mobile
    const sidebarToggle = document.getElementById('sidebarToggle');
    const adminSidebar = document.getElementById('adminSidebar');
    
    // Ensure overlay exists
    let adminOverlay = document.querySelector('.admin-overlay');
    if (!adminOverlay) {
        adminOverlay = document.createElement('div');
        adminOverlay.className = 'admin-overlay';
        document.body.appendChild(adminOverlay);
    }

    function toggleSidebar(e) {
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }
        document.body.classList.toggle('sidebar-open');
        
        // Update icon if exists
        const icon = sidebarToggle ? sidebarToggle.querySelector('i') : null;
        if (icon) {
            if (document.body.classList.contains('sidebar-open')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        }
    }

    function closeSidebar() {
        document.body.classList.remove('sidebar-open');
        const icon = sidebarToggle ? sidebarToggle.querySelector('i') : null;
        if (icon) {
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
        }
    }

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', toggleSidebar);
        // Remove touch event if it causes double firing, or handle carefully
        // sidebarToggle.addEventListener('touchend', toggleSidebar); 
    }

    if (adminOverlay) {
        adminOverlay.addEventListener('click', closeSidebar);
    }

    // Close sidebar when clicking menu item on mobile
    if (window.innerWidth <= 768) {
        const menuItems = document.querySelectorAll('.sidebar-menu .menu-item');
        menuItems.forEach(item => {
            item.addEventListener('click', function() {
                // Allow navigation to proceed, but close sidebar
                closeSidebar();
            });
        });
    }
    
    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
        if (sidebarMenu && !sidebarMenu.contains(e.target) && sidebarToggle && !sidebarToggle.contains(e.target)) {
            if (window.innerWidth <= 768) {
                sidebarMenu.classList.remove('active');
            }
        }
    });
    
    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = 'var(--danger)';
                } else {
                    field.style.borderColor = 'var(--border-color)';
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Mohon isi semua field yang wajib!');
            }
        });
    });
    
    // Input focus effect
    document.querySelectorAll('input, textarea, select').forEach(input => {
        input.addEventListener('focus', function() {
            this.style.borderColor = 'var(--primary)';
        });
        
        input.addEventListener('blur', function() {
            if (this.value) {
                this.style.borderColor = 'var(--primary)';
            } else {
                this.style.borderColor = 'var(--border-color)';
            }
        });
    });
    
    // Confirm delete
    document.querySelectorAll('a[onclick*="confirm"]').forEach(link => {
        link.addEventListener('click', function(e) {
            if (!confirm('Yakin ingin menghapus data ini?')) {
                e.preventDefault();
            }
        });
    });
    
    // Auto-hide alerts after 5 seconds
    document.querySelectorAll('.alert').forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.3s ease';
            alert.style.opacity = '0';
            setTimeout(() => {
                alert.style.display = 'none';
            }, 300);
        }, 5000);
    });
});