<?php
require_once '../includes/config.php';
$page_title = 'Tentang Saya';
include '../includes/header.php';

// Get profile data from database
$profile = $conn->query("SELECT * FROM profile LIMIT 1")->fetch_assoc();
$name = $profile['name'] ?? 'Portfolio Owner';
$title = $profile['title'] ?? 'Developer';
$bio = $profile['bio'] ?? '';
$location = $profile['location'] ?? '';

// Get experience data from database
$exp_result = $conn->query("SELECT * FROM experience ORDER BY end_date DESC");
$exp_list = $exp_result->fetch_all(MYSQLI_ASSOC);
?>

<!-- ABOUT HERO -->
<section class="page-hero">
    <div class="container">
        <h1>Tentang Saya</h1>
        <p>Mengenal lebih jauh tentang perjalanan saya</p>
    </div>
</section>

<!-- ABOUT CONTENT -->
<section class="about-section">
    <div class="container">
        <!-- PROFILE CARD -->
        <div style="background: linear-gradient(135deg, var(--bg-card) 0%, rgba(59, 130, 246, 0.1) 100%); border-radius: 15px; padding: 30px 20px; margin-bottom: 30px; text-align: center; animation: fadeInContent 0.6s ease-out forwards;">
            <!-- Content -->
            <div>
                <!-- Profile Picture Circular -->
                <div style="margin-bottom: 30px;">
                    <?php if (!empty($profile['profile_picture'])): ?>
                        <img src="<?php echo htmlspecialchars(BASE_URL . $profile['profile_picture']); ?>" 
                             alt="<?php echo htmlspecialchars($profile['name'] ?? 'Profil'); ?>" 
                             style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; border: 4px solid var(--primary); box-shadow: 0 8px 20px rgba(59, 130, 246, 0.3);">
                    <?php else: ?>
                        <div style="width: 150px; height: 150px; margin: 0 auto; border-radius: 50%; background: rgba(59, 130, 246, 0.2); display: flex; align-items: center; justify-content: center; border: 4px solid var(--primary);">
                            <i class="fas fa-user-circle" style="font-size: 80px; color: var(--primary);"></i>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Name & Title -->
                <h1 style="margin: 20px 0 10px 0; font-size: 2.5rem;"><?php echo htmlspecialchars($name); ?></h1>
                <p style="font-size: 1.2rem; color: var(--primary); margin-bottom: 20px; font-weight: 500;">
                    <i class="fas fa-briefcase"></i> <?php echo htmlspecialchars($title); ?>
                </p>
                
                <!-- Bio -->
                <p style="max-width: 600px; margin: 0 auto 30px; font-size: 1rem; line-height: 1.6; text-align: justify;">
                    <?php echo nl2br(htmlspecialchars($bio)); ?>
                </p>
            </div>
        </div>
        
        <!-- EXPERIENCE SECTION -->
<?php if (!empty($exp_list)): ?>
<section style="padding: 30px 0; animation: fadeInContent 0.6s ease-out 0.3s forwards; opacity: 0;">
    <div class="container">
        <h2 style="margin-bottom: 20px; text-align: center;">💼 Pengalaman Kerja</h2>
        
        <div style="display: grid; gap: 20px;">
            <?php foreach ($exp_list as $exp): ?>
                <div style="background: var(--bg-card); padding: 25px; border-radius: 10px; border-left: 4px solid var(--primary);">
                    <h3 style="margin: 0 0 10px 0; color: var(--text-light);"><?php echo htmlspecialchars($exp['title'] ?? ''); ?></h3>
                    <p style="margin: 0 0 15px 0; color: var(--text-muted); font-weight: 500;">
                        <?php echo htmlspecialchars($exp['company'] ?? ''); ?> • 
                        <?php echo date('M Y', strtotime($exp['start_date'] ?? '')); ?> - 
                        <?php echo $exp['end_date'] ? date('M Y', strtotime($exp['end_date'])) : 'Sekarang'; ?>
                    </p>
                    <?php if ($exp['description']): ?>
                        <p style="margin: 0; color: var(--text-muted); line-height: 1.6;"><?php echo htmlspecialchars($exp['description']); ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
