<?php
require_once '../includes/config.php';
require_once '../includes/blog-renderer.php';

// Get blog post ID from URL
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

if (!$id) {
    header("Location: blog.php");
    exit;
}

// Get blog post dari database
$stmt = $conn->prepare("SELECT * FROM blog_posts WHERE id = ? AND status = 'published'");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: blog.php");
    exit;
}

$post = $result->fetch_assoc();
$page_title = $post['title'];
include '../includes/header.php';
?>

<style>
    .article-hero {
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(30, 58, 138, 0.1) 100%);
        border-bottom: 2px solid var(--primary);
        padding: 60px var(--spacing-md);
        margin-bottom: 40px;
    }

    .article-hero h1 {
        font-size: 2.5rem;
        color: var(--text-light);
        margin-bottom: 1rem;
        line-height: 1.3;
    }

    .article-meta {
        display: flex;
        gap: 20px;
        flex-wrap: wrap;
        color: var(--text-muted);
        font-size: 0.95rem;
    }

    .meta-item {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .meta-item i {
        color: var(--primary);
    }

    .article-container {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-xl);
        padding: 40px;
        margin-bottom: 60px;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
    }

    .article-content {
        font-size: 1.05rem;
        line-height: 1.8;
        color: var(--text-light);
    }

    .article-content p {
        margin-bottom: 1.5rem;
        text-align: justify;
    }

    .article-content h2,
    .article-content h3 {
        color: var(--primary);
        margin-top: 2rem;
        margin-bottom: 1rem;
    }

    .article-content ul,
    .article-content ol {
        margin-bottom: 1.5rem;
        margin-left: 2rem;
    }

    .article-content li {
        margin-bottom: 0.5rem;
    }

    .back-to-blog {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        color: var(--primary);
        text-decoration: none;
        font-weight: 600;
        margin-bottom: 40px;
        transition: var(--transition);
    }

    .back-to-blog:hover {
        transform: translateX(-5px);
    }

    @media (max-width: 768px) {
        .article-hero {
            padding: 40px var(--spacing-md);
        }

        .article-hero h1 {
            font-size: 1.8rem;
        }

        .article-container {
            padding: 25px;
        }

        .article-meta {
            flex-direction: column;
            gap: 10px;
        }
    }
</style>

<!-- Article Hero -->
<section class="article-hero">
    <div class="container">
        <span class="article-category" style="display: inline-block; background: var(--primary); color: white; padding: 6px 14px; border-radius: var(--radius-md); font-size: 0.85rem; font-weight: 600; text-transform: uppercase; margin-bottom: 1rem;">
            <?php echo htmlspecialchars($post['category']); ?>
        </span>
        <h1><?php echo htmlspecialchars($post['title']); ?></h1>
        <div class="article-meta">
            <div class="meta-item">
                <i class="fas fa-calendar"></i>
                <span><?php echo date('d F Y', strtotime($post['created_at'])); ?></span>
            </div>
            <div class="meta-item">
                <i class="fas fa-clock"></i>
                <span>5 min baca</span>
            </div>
        </div>
    </div>
</section>

<!-- Article Container -->
<div class="container">
    <a href="blog.php" class="back-to-blog">
        <i class="fas fa-arrow-left"></i>
        Kembali ke Blog
    </a>

    <!-- Article Content -->
    <article class="article-container">
        <div class="article-content">
            <?php echo renderBlogContent($post['content']); ?>
        </div>
    </article>

    <!-- Back Button -->
    <div style="text-align: center; margin-bottom: 40px;">
        <a href="blog.php" class="back-to-blog" style="justify-content: center;">
            <i class="fas fa-arrow-left"></i>
            Kembali ke Blog
        </a>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

