<?php
require_once '../includes/config.php';
require_once '../includes/blog-renderer.php';

$page_title = 'Blog';
include '../includes/header.php';

// Get blog posts
$query = "SELECT * FROM blog_posts WHERE status = 'published' ORDER BY created_at DESC";
$result = $conn->query($query);
$posts = $result->fetch_all(MYSQLI_ASSOC);

// Helper function untuk extract gambar dari JSON content
function extractImageFromContent($content) {
    if (is_string($content)) {
        $decoded = json_decode($content, true);
        if (is_array($decoded)) {
            foreach ($decoded as $block) {
                if ($block['type'] === 'image' && !empty($block['content']['url'])) {
                    return $block['content']['url'];
                }
            }
        }
    }
    return null;
}

// Helper function untuk extract teks preview dari JSON content
function extractTextPreview($content, $length = 150) {
    if (is_string($content)) {
        $decoded = json_decode($content, true);
        if (is_array($decoded)) {
            foreach ($decoded as $block) {
                if ($block['type'] === 'paragraph' && !empty($block['content']['text'])) {
                    $text = $block['content']['text'];
                    if (strlen($text) > $length) {
                        return substr($text, 0, $length);
                    }
                    return $text;
                }
            }
        }
    }
    return '';
}
?>

<!-- BLOG HERO -->
<section class="blog-hero">
    <div class="container">
        <h1>Blog & Artikel</h1>
        <p>Berbagi pengetahuan dan pengalaman</p>
    </div>
</section>

<!-- BLOG CONTENT -->
<section class="blog-section">
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; flex-wrap: wrap; gap: 15px;">
            <h2 class="section-title" style="margin: 0;">Artikel Terbaru</h2>
            <div style="display: flex; gap: 15px; align-items: center;">
                <div class="search-box">
                    <input type="text" id="blogSearch" placeholder="Cari artikel...">
                    <i class="fas fa-search"></i>
                </div>
            </div>
        </div>
        
        <?php if (empty($posts)): ?>
            <div class="empty-state">
                <i class="fas fa-inbox"></i>
                <p>Belum ada artikel. Kembali lagi nanti!</p>
            </div>
        <?php else: ?>
            <div class="blog-grid">
                <?php foreach ($posts as $post): 
                    $image = extractImageFromContent($post['content']);
                    if (empty($image) && !empty($post['featured_image'])) {
                        $image = $post['featured_image'];
                    }
                    if (empty($image) && !empty($post['image'])) {
                        $image = $post['image'];
                    }
                    
                    $description = !empty($post['description']) 
                        ? $post['description'] 
                        : extractTextPreview($post['content'], 150);
                ?>
                    <article class="blog-card">
                        <div class="blog-image">
                            <?php if (!empty($image)): ?>
                                <img src="<?php echo htmlspecialchars($image); ?>" 
                                     alt="<?php echo htmlspecialchars($post['title']); ?>"
                                     onerror="this.style.display='none'; this.parentElement.classList.add('no-image');">
                            <?php else: ?>
                                <!-- Icon placeholder jika tidak ada gambar -->
                            <?php endif; ?>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" style="width: 80%; height: 80%; <?php echo !empty($image) ? 'display: none;' : ''; ?>" class="placeholder-icon">
                                <circle cx="100" cy="100" r="80" fill="rgba(59, 130, 246, 0.2)" stroke="#3b82f6" stroke-width="2"/>
                                <rect x="60" y="70" width="80" height="16" fill="#3b82f6" rx="2"/>
                                <rect x="60" y="95" width="80" height="4" fill="#3b82f6" rx="1"/>
                                <rect x="60" y="105" width="80" height="4" fill="#3b82f6" rx="1"/>
                                <rect x="60" y="115" width="80" height="4" fill="#3b82f6" rx="1"/>
                            </svg>
                        </div>
                        <div class="blog-content">
                            <span class="blog-category"><?php echo htmlspecialchars($post['category']); ?></span>
                            <h3><?php echo htmlspecialchars($post['title']); ?></h3>
                            <p><?php echo htmlspecialchars($description); ?>...</p>
                            <div class="blog-meta">
                                <span><?php echo date('d M Y', strtotime($post['created_at'])); ?></span>
                                <a href="blog-detail.php?id=<?php echo $post['id']; ?>" class="btn-link">Baca Selengkapnya →</a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<script>
    // Blog search functionality
    document.getElementById('blogSearch').addEventListener('keyup', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        const blogCards = document.querySelectorAll('.blog-card');
        
        blogCards.forEach(card => {
            const title = card.querySelector('h3').textContent.toLowerCase();
            const description = card.querySelector('p').textContent.toLowerCase();
            const category = card.querySelector('.blog-category').textContent.toLowerCase();
            
            if (title.includes(searchTerm) || description.includes(searchTerm) || category.includes(searchTerm)) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
    });
</script>

<?php include '../includes/footer.php'; ?>
