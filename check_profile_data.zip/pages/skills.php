<?php
require_once '../includes/config.php';
$page_title = 'Skills';
include '../includes/header.php';

// Get all skills
$skills_result = $conn->query("SELECT * FROM skills ORDER BY proficiency DESC");
$skills_data = $skills_result->fetch_all(MYSQLI_ASSOC);
?>

<!-- SKILLS HERO -->
<section class="page-hero">
    <div class="container">
        <h1>Skills & Expertise</h1>
        <p>Teknologi dan keahlian yang saya kuasai</p>
    </div>
</section>

<!-- SKILLS CONTENT -->
<section class="skills-section">
    <div class="container">
        <h2 class="section-title">Kemampuan</h2>
        
        <div class="skills-grid">
            <?php foreach ($skills_data as $index => $skill): ?>
                <div class="skill-item" style="animation: slideInUp 0.8s ease-out forwards; animation-delay: <?php echo ($index * 0.08); ?>s;">
                    <div class="skill-header">
                        <span><?php echo htmlspecialchars($skill['name']); ?></span>
                        <span><?php echo intval($skill['proficiency']); ?>%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress" style="width: <?php echo intval($skill['proficiency']); ?>%"></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- TECH STACK -->
<section class="tech-stack">
    <div class="container">
        <h2 class="section-title">Technology Stack</h2>
        
        <div class="tech-grid">
            <div class="tech-item">
                <i class="fab fa-html5"></i>
                <span>HTML5</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-css3-alt"></i>
                <span>CSS3</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-js-square"></i>
                <span>JavaScript</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-php"></i>
                <span>PHP</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-github"></i>
                <span>Git</span>
            </div>
            <div class="tech-item">
                <i class="fas fa-database"></i>
                <span>MySQL</span>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>
