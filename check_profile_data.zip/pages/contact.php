<?php
require_once '../includes/config.php';
$page_title = 'Kontak';
include '../includes/header.php';

// Get profile for contact info
$profile = $conn->query("SELECT * FROM profile LIMIT 1")->fetch_assoc();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars($_POST['name'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');
    $subject = htmlspecialchars($_POST['subject'] ?? '');
    $message_content = htmlspecialchars($_POST['message'] ?? '');
    
    if (empty($name) || empty($email) || empty($subject) || empty($message_content)) {
        $error = 'Semua field harus diisi!';
    } else {
        // Simpan ke database
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $subject, $message_content);
        
        if ($stmt->execute()) {
            $message = 'Pesan Anda berhasil dikirim! Saya akan segera meresponnya.';
        } else {
            $error = 'Terjadi kesalahan. Silakan coba lagi.';
        }
        $stmt->close();
    }
}
?>

<!-- CONTACT HERO -->
<section class="page-hero">
    <div class="container">
        <h1>Hubungi Saya</h1>
        <p>Mari terhubung dan berkolaborasi</p>
    </div>
</section>

<!-- CONTACT CONTENT -->
<section class="contact-section">
    <div class="container">
        <div class="contact-grid">
            <!-- Contact Info -->
            <div class="contact-info">
                <h2>Informasi Kontak</h2>
                
                <div class="info-item">
                    <div class="info-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div>
                        <h4>Email</h4>
                        <a href="mailto:<?php echo htmlspecialchars($profile['email'] ?? ''); ?>">
                            <?php echo htmlspecialchars($profile['email'] ?? 'kontak@contoh.com'); ?>
                        </a>
                    </div>
                </div>
                
                <div class="info-item">
                    <div class="info-icon">
                        <i class="fas fa-phone"></i>
                    </div>
                    <div>
                        <h4>WhatsApp</h4>
                        <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $profile['phone'] ?? ''); ?>">
                            <?php echo htmlspecialchars($profile['phone'] ?? '+62 XXX XXXX XXXX'); ?>
                        </a>
                    </div>
                </div>
                
                <div class="info-item">
                    <div class="info-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div>
                        <h4>Lokasi</h4>
                        <a href="<?php echo htmlspecialchars($profile['location'] ?? ''); ?>" target="_blank">
                            <?php echo htmlspecialchars($profile['location'] ?? 'Kota, Provinsi, Indonesia'); ?>
                        </a>
                    </div>
                </div>
                
                <h3>Ikuti Saya</h3>
                <div class="social-links">
                    <?php if (!empty($profile['github_url'])): ?>
                        <a href="<?php echo htmlspecialchars($profile['github_url']); ?>" title="GitHub" target="_blank"><i class="fab fa-github"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($profile['linkedin_url'])): ?>
                        <a href="<?php echo htmlspecialchars($profile['linkedin_url']); ?>" title="LinkedIn" target="_blank"><i class="fab fa-linkedin"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($profile['instagram_url'])): ?>
                        <a href="<?php echo htmlspecialchars($profile['instagram_url']); ?>" title="Instagram" target="_blank"><i class="fab fa-instagram"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($profile['twitter_url'])): ?>
                        <a href="<?php echo htmlspecialchars($profile['twitter_url']); ?>" title="Twitter" target="_blank"><i class="fab fa-twitter"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($profile['tiktok_url'])): ?>
                        <a href="<?php echo htmlspecialchars($profile['tiktok_url']); ?>" title="TikTok" target="_blank"><i class="fab fa-tiktok"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($profile['facebook_url'])): ?>
                        <a href="<?php echo htmlspecialchars($profile['facebook_url']); ?>" title="Facebook" target="_blank"><i class="fab fa-facebook"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($profile['telegram_url'])): ?>
                        <a href="<?php echo htmlspecialchars($profile['telegram_url']); ?>" title="Telegram" target="_blank"><i class="fab fa-telegram"></i></a>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Contact Form -->
            <div class="contact-form-wrapper">
                <h2>Kirim Pesan</h2>
                
                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST" class="contact-form">
                    <div class="form-group">
                        <label for="name">Nama Lengkap</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="subject">Subjek</label>
                        <input type="text" id="subject" name="subject" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="message">Pesan</label>
                        <textarea id="message" name="message" rows="5" required></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Kirim Pesan</button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>
