<?php
require_once '../includes/config.php';
$page_title = 'Portfolio';
include '../includes/header.php';

// Get portfolio projects from database
$portfolios_result = $conn->query("SELECT * FROM portfolios ORDER BY id DESC");
$portfolios = $portfolios_result->fetch_all(MYSQLI_ASSOC);

// Get unique categories
$categories = array_unique(array_column($portfolios, 'category'));
?>

<!-- PORTFOLIO HERO -->
<section class="page-hero">
    <div class="container">
        <h1>Portofolio Saya</h1>
        <p>Proyek-proyek yang telah saya kerjakan</p>
    </div>
</section>

<!-- PORTFOLIO CONTENT -->
<section class="portfolio-section">
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <h2 class="section-title" style="margin: 0;">Semua Proyek</h2>
            <div class="search-box" style="position: relative; width: 250px;">
                <input type="text" id="portfolioSearch" placeholder="Cari proyek..." 
                       style="width: 100%; padding: 10px 40px 10px 15px; border: 2px solid var(--primary); border-radius: 8px; background: transparent; color: var(--text-light); font-size: 14px;">
                <i class="fas fa-search" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: var(--primary); pointer-events: none;"></i>
            </div>
        </div>
        
        <!-- Filter Buttons -->
        <div class="filter-buttons" style="display: flex; gap: 10px; margin-bottom: 30px; flex-wrap: wrap;">
            <button class="filter-btn active" data-filter="all" style="padding: 8px 20px; border: 2px solid var(--primary); background: var(--primary); color: white; border-radius: 25px; cursor: pointer; font-weight: 500; transition: all 0.3s;">Semua</button>
            <?php foreach ($categories as $cat): ?>
                <button class="filter-btn" data-filter="<?php echo strtolower(str_replace(' ', '-', htmlspecialchars($cat))); ?>" style="padding: 8px 20px; border: 2px solid var(--primary); background: transparent; color: var(--primary); border-radius: 25px; cursor: pointer; font-weight: 500; transition: all 0.3s;">
                    <?php echo htmlspecialchars($cat); ?>
                </button>
            <?php endforeach; ?>
        </div>
        
        <?php if (empty($portfolios)): ?>
            <div class="empty-state">
                <i class="fas fa-briefcase"></i>
                <p>Belum ada proyek yang ditambahkan.</p>
            </div>
        <?php else: ?>
            <!-- Portfolio Grid - Same style as Blog Grid -->
            <div class="blog-grid" id="portfolioGrid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 25px;">
                <?php foreach ($portfolios as $project): 
                    $category_key = strtolower(str_replace(' ', '-', htmlspecialchars($project['category'])));
                    $tech_array = array_filter(array_map('trim', explode(',', $project['technologies'])));
                ?>
                    <article class="blog-card portfolio-card" data-category="<?php echo $category_key; ?>" style="display: flex; flex-direction: column; background: var(--bg-card); border-radius: 12px; overflow: hidden; transition: all 0.3s ease; cursor: pointer; border: 1px solid var(--border-color);">
                        <div class="blog-image" style="height: 180px; overflow: hidden; background: #f0f0f0; position: relative;">
                            <?php if (!empty($project['image'])): ?>
                                <img src="<?php echo BASE_URL . htmlspecialchars($project['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($project['title']); ?>"
                                     style="width: 100%; height: 100%; object-fit: cover;">
                            <?php else: ?>
                                <i class="fas fa-project-diagram" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 3rem; color: #ccc;"></i>
                            <?php endif; ?>
                        </div>
                        
                        <div class="blog-content" style="flex: 1; padding: 20px; display: flex; flex-direction: column;">
                            <span class="blog-category" style="display: inline-block; background: var(--primary); color: white; padding: 4px 12px; border-radius: 20px; font-size: 12px; margin-bottom: 12px; width: fit-content; font-weight: 600;">
                                <?php echo htmlspecialchars($project['category']); ?>
                            </span>
                            
                            <h3 class="blog-title" style="margin: 0 0 10px 0; font-size: 1.1rem; color: var(--text);">
                                <?php echo htmlspecialchars($project['title']); ?>
                            </h3>
                            
                            <p class="blog-desc" style="margin: 0 0 15px 0; color: var(--text-light); font-size: 0.9rem; line-height: 1.5; flex: 1;">
                                <?php echo htmlspecialchars(substr($project['description'], 0, 120)) . (strlen($project['description']) > 120 ? '...' : ''); ?>
                            </p>
                            
                            <!-- Tech Tags -->
                            <div class="tech-tags" style="display: flex; gap: 8px; margin-bottom: 15px; flex-wrap: wrap;">
                                <?php foreach (array_slice($tech_array, 0, 3) as $tech): ?>
                                    <span style="background: rgba(var(--primary-rgb), 0.1); color: var(--primary); padding: 4px 10px; border-radius: 15px; font-size: 0.8rem; font-weight: 500;">
                                        <?php echo htmlspecialchars($tech); ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>
                            
                            <!-- Links -->
                            <div style="display: flex; gap: 10px;">
                                <a href="<?php echo htmlspecialchars($project['link']); ?>" class="btn-link" target="_blank" style="text-decoration: none; color: var(--primary); font-weight: 600; display: inline-flex; align-items: center; gap: 5px; transition: gap 0.3s;">
                                    Lihat Detail →
                                </a>
                                <?php if (!empty($project['github_link'])): ?>
                                    <a href="<?php echo htmlspecialchars($project['github_link']); ?>" class="btn-link" target="_blank" style="text-decoration: none; color: var(--primary); font-weight: 600; display: inline-flex; align-items: center; gap: 5px; transition: gap 0.3s;">
                                        <i class="fab fa-github"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div style="text-align: center; margin-top: 40px;">
            <a href="contact.php" class="btn btn-primary">Hubungi Saya</a>
        </div>
    </div>
</section>

<script>
    // Portfolio search functionality
    document.getElementById('portfolioSearch').addEventListener('keyup', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        const portfolioCards = document.querySelectorAll('.portfolio-card');
        
        portfolioCards.forEach(card => {
            const title = card.querySelector('h3').textContent.toLowerCase();
            const description = card.querySelector('p:nth-of-type(2)').textContent.toLowerCase();
            const category = card.querySelector('.category-tag').textContent.toLowerCase();
            
            if (title.includes(searchTerm) || description.includes(searchTerm) || category.includes(searchTerm)) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
    });

    // Filter buttons functionality
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const filter = this.getAttribute('data-filter');
            const cards = document.querySelectorAll('.portfolio-card');
            
            cards.forEach(card => {
                if (filter === 'all' || card.getAttribute('data-category') === filter) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
</script>

<?php include '../includes/footer.php'; ?>
