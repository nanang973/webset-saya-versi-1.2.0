-- ============================================
-- Blog Articles Table untuk CMS Blog Builder
-- ============================================

CREATE TABLE IF NOT EXISTS `blog_articles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `excerpt` TEXT,
  `featured_image` VARCHAR(500),
  `content` LONGTEXT NOT NULL COMMENT 'JSON format: [{"type":"heading","level":"h2","text":"..."},{"type":"paragraph","text":"..."},...]',
  `category` VARCHAR(100),
  `tags` VARCHAR(500),
  `status` ENUM('draft', 'published') DEFAULT 'draft',
  `view_count` INT DEFAULT 0,
  `author_id` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `published_at` DATETIME,
  INDEX `idx_slug` (`slug`),
  INDEX `idx_status` (`status`),
  INDEX `idx_category` (`category`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Insert sample data (optional)
-- ============================================

INSERT INTO `blog_articles` (`title`, `slug`, `excerpt`, `featured_image`, `content`, `category`, `tags`, `status`, `author_id`, `published_at`) 
VALUES (
  'Pembentukan Pimpinan Ranting IPNU IPPNU Desa Napis',
  'pembentukan-pr-ipnu-ippnu-napis',
  'Pimpinan Anak Cabang (PAC) IPNU IPPNU Kecamatan Tambakrejo sukses melaksanakan kegiatan Pembentukan Pimpinan Ranting (PR) IPNU IPPNU Desa Napis.',
  'https://via.placeholder.com/800x400/3b82f6/ffffff?text=IPNU+IPPNU',
  '[
    {"type":"heading","level":"h2","text":"Tambakrejo, 10 Januari 2026"},
    {"type":"paragraph","text":"Pimpinan Anak Cabang (PAC) IPNU IPPNU Kecamatan Tambakrejo sukses melaksanakan kegiatan Pembentukan Pimpinan Ranting (PR) IPNU IPPNU Desa Napis. Kegiatan ini bertempat di Mushola Al-Mudtaqin, Desa Napis, pada Sabtu, 10 Januari 2026."},
    {"type":"spacer","height":"20"},
    {"type":"heading","level":"h3","text":"Pembentukan Organisasi di Tingkat Ranting"},
    {"type":"paragraph","text":"Kegiatan pembentukan ini merupakan langkah awal dalam memperkuat organisasi IPNU dan IPPNU di tingkat ranting. Acara diawali dengan sambutan Ketua PAC IPNU IPPNU Kecamatan Tambakrejo, yang menyampaikan tentang apa itu IPNU IPPNU serta menjelaskan tentang kegiatan apa saja yang biasa dilakukan di tingkatan ranting."},
    {"type":"spacer","height":"20"},
    {"type":"heading","level":"h3","text":"Dukungan dari Tokoh Masyarakat"},
    {"type":"paragraph","text":"Bapak Kiai Kahar selaku Ketua Tanfidz Desa Napis memberikan sambutan dan dukungan penuh terhadap terbentuknya Pimpinan Ranting IPNU IPPNU Desa Napis. Beliau memberikan motivasi dan arahan kepada para peserta pimpinan ranting."},
    {"type":"spacer","height":"20"},
    {"type":"heading","level":"h3","text":"Hasil Pemilihan Pimpinan Ranting"},
    {"type":"paragraph","text":"Agenda utama kemudian dilanjutkan dengan pemilihan Ketua Pimpinan Ranting IPNU dan IPPNU Desa Napis oleh para pengurus PAC. Dari hasil pemilihan tersebut, terpilih:"},
    {"type":"list","style":"unordered","items":["Ketua PR IPNU Desa Napis: M. Denis Saputra","Ketua PR IPPNU Desa Napis: Evita Cahaya"]},
    {"type":"spacer","height":"20"},
    {"type":"heading","level":"h3","text":"Penutupan dengan Suasana Kebersamaan"},
    {"type":"paragraph","text":"Setelah seluruh rangkaian acara inti selesai, kegiatan ditutup dengan bakar-bakar sosis bersama. Kegiatan ini menjadi momen kebersamaan yang hangat untuk mempererat rasa kekeluargaan dan solidaritas antar kader serta peserta yang hadir."},
    {"type":"spacer","height":"20"},
    {"type":"paragraph","text":"Dengan terbentuknya Pimpinan Ranting IPNU IPPNU Desa Napis, diharapkan ke depan organisasi ini dapat menjadi penggerak kegiatan pelajar yang aktif, solid, dan berkontribusi positif bagi masyarakat Desa Napis."}
  ]',
  'Berita',
  'IPNU,IPPNU,Organisasi,Tambakrejo',
  'published',
  1,
  NOW()
);
