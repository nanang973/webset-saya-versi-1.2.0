# 🎨 PANDUAN CUSTOMIZATION

Panduan lengkap untuk mengustomisasi website sesuai kebutuhan Anda.

---

## 📝 Mengubah Data Profil

### Method 1: Edit Database (Recommended)

**File:** Di tabel `profile` di database

1. Buka phpMyAdmin: `http://localhost/phpmyadmin`
2. Pilih database `portfolio_db`
3. Pilih tabel `profile`
4. Klik icon **Edit** di baris pertama
5. Update data:
   - `name` → Nama lengkap
   - `title` → Job title (IoT Developer, etc)
   - `bio` → Deskripsi singkat
   - `email` → Email Anda
   - `phone` → No telp/WhatsApp
   - `location` → Kota/lokasi
   - Social media URLs

6. Klik **Save**

### Method 2: Edit HTML Manual (Untuk sekarang)

**File:** `index.php`, `pages/about.php`, `pages/contact.php`

Cari dan ganti:
```php
// Contoh di index.php
<h1 class="hero-title">Hi, Saya <span class="text-primary">Nanang</span></h1>

// Ubah jadi nama Anda
<h1 class="hero-title">Hi, Saya <span class="text-primary">Nama Anda</span></h1>
```

---

## 🎨 Mengubah Warna Theme

### File: `assets/css/style.css`

Cari bagian `:root` (baris awal):

```css
:root {
    /* Colors */
    --primary: #3b82f6;           /* Biru - Ubah di sini */
    --primary-dark: #1e40af;      /* Dark blue */
    --secondary: #8b5cf6;         /* Ungu */
    --bg-dark: #0f172a;           /* Background gelap */
    --bg-darker: #020617;         /* Lebih gelap lagi */
    --bg-card: #1e293b;           /* Card background */
    --bg-hover: #334155;          /* Hover background */
    --text-light: #f1f5f9;        /* Text color */
    --text-muted: #94a3b8;        /* Muted text */
    --border-color: #334155;      /* Border color */
    --success: #10b981;           /* Hijau success */
    --danger: #ef4444;            /* Merah danger */
}
```

### Contoh Mengubah Warna Primary (Biru → Hijau)

```css
:root {
    --primary: #10b981;           /* Ganti dari biru ke hijau */
    --primary-dark: #059669;      /* Hijau darker */
    /* ... rest tetap sama ... */
}
```

### Website akan otomatis berubah warna ke hijau! 🟢

---

## 🔤 Mengubah Font

### File: `includes/header.php`

Cari bagian Google Fonts:

```html
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
```

### Ganti ke Font Lain

Contoh menggunakan font **Raleway**:

```html
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;500;600;700&display=swap" rel="stylesheet">
```

Kemudian di `assets/css/style.css`, ubah:

```css
body {
    font-family: 'Raleway', sans-serif;  /* Ganti dari Poppins ke Raleway */
}
```

[Lihat font lain di Google Fonts](https://fonts.google.com/)

---

## 📱 Mengubah Informasi Kontak

### File: `pages/contact.php`

Cari dan ganti:

```php
<a href="mailto:nanang@example.com">nanang@example.com</a>
<!-- Ubah email -->

<a href="https://wa.me/62xxxx">+62 xxx xxx xxxx</a>
<!-- Ubah nomor WhatsApp -->

<p>Kota, Provinsi, Indonesia</p>
<!-- Ubah lokasi -->
```

### Social Media Links

Di `includes/footer.php`:

```php
<a href="#"><i class="fab fa-github"></i></a>
<!-- Ganti # dengan URL GitHub Anda -->

<a href="#"><i class="fab fa-linkedin"></i></a>
<!-- Ganti # dengan URL LinkedIn Anda -->

<a href="#"><i class="fab fa-instagram"></i></a>
<!-- Ganti # dengan URL Instagram Anda -->
```

---

## 💼 Mengubah Skill & Proficiency

### Method 1: Database (Recommended)

1. Buka phpMyAdmin
2. Pilih tabel `skills`
3. Edit data:
   - `name` → Nama skill
   - `category` → Kategori (IoT, Web, Tools)
   - `proficiency` → Level 0-100
   - `icon` → Icon dari Font Awesome

### Method 2: Edit HTML Manual

**File:** `pages/skills.php`

```html
<div class="skill-item">
    <div class="skill-header">
        <span>ESP32</span>
        <span>90%</span>
    </div>
    <div class="progress-bar">
        <div class="progress" style="width: 90%"></div>
    </div>
</div>
```

Update nilai:
- Span pertama: Nama skill
- Span kedua: Persentase (0-100)
- `width: 90%` → Ubah ke persentase yang sama

---

## 🖼️ Menambah Gambar Profile

### Upload Gambar

1. Buat folder `assets/images/` jika belum ada
2. Upload gambar (format: jpg, png, webp)
3. Nama file: `profile.jpg` (contoh)

### Edit HTML untuk Menampilkan Gambar

**File:** `pages/about.php`

Ganti bagian placeholder:

```html
<div class="image-placeholder">
    <i class="fas fa-user-circle"></i>
</div>

<!-- UBAH MENJADI -->

<div class="image-placeholder">
    <img src="<?php echo ASSETS_URL; ?>images/profile.jpg" alt="Profil" style="width: 300px; height: 300px; border-radius: 1rem; object-fit: cover;">
</div>
```

---

## 📝 Menambah Artikel Blog

### Via Admin Dashboard (Recommended)

1. Login: `http://localhost/webset01/portfolio/admin/`
2. Klik **Blog Posts**
3. Klik **+ Tambah Artikel**
4. Isi form:
   - Judul artikel
   - Kategori
   - Konten
   - Status (draft/published)
5. Klik **Simpan**

Artikel akan muncul di halaman blog otomatis!

### Via Database Manual

1. Buka phpMyAdmin
2. Pilih tabel `blog_posts`
3. Klik **Insert** (atau +)
4. Isi data:
   - `title` → Judul
   - `category` → Kategori
   - `content` → Isi artikel (bisa HTML)
   - `status` → 'published' (untuk publik) atau 'draft'

---

## 🎯 Menambah Portfolio / Proyek

### Via Admin Dashboard

1. Login admin panel
2. Klik **Portfolio** (coming soon)
3. Klik **+ Tambah Portfolio**
4. Isi form dengan detail proyek Anda

### Manual di Database

1. Buka phpMyAdmin
2. Pilih tabel `portfolios`
3. Klik **Insert**
4. Isi data:
   - `title` → Judul proyek
   - `description` → Deskripsi
   - `category` → Kategori (iot, web, business)
   - `link` → URL live project
   - `github_link` → URL GitHub
   - `technologies` → Tech yang digunakan (pisahkan dengan comma)

---

## 🔗 Update Social Media Links

### Footer Social Links

**File:** `includes/footer.php`

```html
<div class="social-links">
    <a href="https://github.com/username"><i class="fab fa-github"></i></a>
    <a href="https://linkedin.com/in/username"><i class="fab fa-linkedin"></i></a>
    <a href="https://instagram.com/username"><i class="fab fa-instagram"></i></a>
    <a href="https://twitter.com/username"><i class="fab fa-twitter"></i></a>
</div>
```

Ganti `username` dengan username Anda di masing-masing platform.

---

## 🎭 Mengubah Hero Section

### File: `index.php`

```html
<h1 class="hero-title">Hi, Saya <span class="text-primary">Nanang</span></h1>
<p class="hero-subtitle">Mahasiswa Teknik Informatika | IoT Developer | Web Developer</p>
<p class="hero-description">Passion saya adalah menciptakan solusi digital inovatif dan mempelajari teknologi terbaru dalam dunia IoT dan Web Development.</p>
```

Ubah sesuai profil Anda.

---

## 🎨 Mengubah Icon Hero

**File:** `index.php`

```html
<div class="hero-icon">
    <i class="fas fa-code"></i>  <!-- Ubah icon ini -->
</div>
```

Icon tersedia dari [Font Awesome](https://fontawesome.com/icons).

Contoh icon lain:
- `fa-laptop` - Laptop
- `fa-mobile` - Mobile
- `fa-server` - Server
- `fa-robot` - Robot
- `fa-zap` - Lightning bolt
- dll...

---

## 🌐 Update Base URL (Jika Pindah Server)

**File:** `includes/config.php`

```php
define('BASE_URL', 'http://localhost/webset01/portfolio/');
define('ASSETS_URL', BASE_URL . 'assets/');
```

Jika hosting di domain berbeda:

```php
define('BASE_URL', 'https://nanangkhasan.com/');
define('ASSETS_URL', BASE_URL . 'assets/');
```

---

## 🔐 Mengubah Password Admin

### Cara Aman (Hashing)

1. Buat file `create_password.php` di folder `admin/`:

```php
<?php
$password = 'password_baru_anda';
$hashed = password_hash($password, PASSWORD_DEFAULT);
echo "Copy hash ini: " . $hashed;
?>
```

2. Kunjungi: `http://localhost/webset01/portfolio/admin/create_password.php`
3. Copy hash yang muncul
4. Buka phpMyAdmin → tabel `admin_users`
5. Edit user admin → field `password` → paste hash
6. Save

**Catatan:** Jangan lupa hapus file `create_password.php` setelah selesai!

---

## 📱 Responsive Customization

### Mobile Breakpoints

**File:** `assets/css/style.css` (di bagian bawah)

```css
@media (max-width: 768px) {
    /* Tablet & mobile besar */
}

@media (max-width: 480px) {
    /* Mobile kecil */
}
```

Edit CSS di sini untuk customize tampilan mobile.

---

## 🚀 Optimasi SEO

### Meta Tags

**File:** `includes/header.php`

```html
<meta name="description" content="Portfolio pribadi Nanang Khasan Bisri">
```

Update untuk setiap halaman di variable `$page_title`.

### Update Favicon

1. Buat file `favicon.ico` (32x32 px)
2. Upload ke folder root `portfolio/`
3. Favicon otomatis muncul di tab browser

---

## ✉️ Setup Email Notifications (Optional)

**File:** `pages/contact.php`

```php
// Tambahkan di bagian submit form:
mail('email_tujuan@example.com', $subject, $message_content);
```

Butuh konfigurasi SMTP di `php.ini`.

---

## 📊 Google Analytics (Optional)

Tambahkan tracking code di `includes/header.php`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_TRACKING_ID"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'GA_TRACKING_ID');
</script>
```

Ganti `GA_TRACKING_ID` dengan ID tracking Anda.

---

## 💡 Pro Tips

### 1. Backup Database Secara Berkala
```bash
mysqldump -u root portfolio_db > backup_portfolio.sql
```

### 2. Test Responsive Design
- Buka DevTools (F12)
- Klik device toggle (tablet/mobile icon)
- Test semua halaman

### 3. Optimize Images
- Gunakan tools: [TinyPNG](https://tinypng.com/) atau [Squoosh](https://squoosh.app/)
- Hemat bandwidth & loading time

### 4. Use Version Control
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/username/portfolio.git
git push -u origin main
```

---

## 📚 Resources Helpful

- [Font Awesome Icons](https://fontawesome.com/)
- [Google Fonts](https://fonts.google.com/)
- [CSS Tricks](https://css-tricks.com/)
- [PHP Manual](https://www.php.net/manual/)
- [MySQL Documentation](https://dev.mysql.com/doc/)

---

**Happy Customizing! 🎨**
