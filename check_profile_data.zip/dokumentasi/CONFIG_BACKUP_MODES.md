# 🔧 PRODUCTION CONFIG BACKUP

Simpan file ini untuk nanti ketika mau switch ke mode hosting!

---

## 📍 Mode Hosting - Pengaturan untuk nanangkhasan.my.id

Gunakan config ini saat sudah di-upload ke hosting:

### Database (Hosting)
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'nanang');
define('DB_PASS', '');  // Ganti dengan password database hosting Anda
define('DB_NAME', 'portofolio_db');  // Atau nama database yang ada di hosting
```

### Base URL (Hosting)
```php
// MODE HOSTING - Hardcoded
define('BASE_URL', 'https://nanangkhasan.my.id/');
define('ASSETS_URL', 'https://nanangkhasan.my.id/assets/');
```

---

## 💻 Mode Lokal - Pengaturan Sekarang

Saat ini menggunakan mode LOKAL dengan:

### Database (Lokal)
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');  // Kosong
define('DB_NAME', 'portofolio_db');
```

### Base URL (Lokal - Auto-detect)
Auto-detect berdasarkan `localhost`:
- Local: `http://localhost/webset 3.0.0/`
- Atau: `http://127.0.0.1/webset 3.0.0/`

---

## 🔄 Cara Switch Mode

### Saat Upload ke Hosting:
1. Update database credentials untuk hosting di config.php
2. Or buat conditional dalam config.php seperti saat ini

### Kembali ke Lokal:
Tidak perlu apa-apa! Config sudah auto-detect localhost.

---

## 🔐 Security Headers (Sama di semua mode)
```php
// Content Security Policy - Allow cdnjs untuk Font Awesome
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://fonts.googleapis.com; style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com; img-src 'self' data: https:; connect-src 'self'");

// HTTPS Enforcement (allow localhost untuk development)
$is_localhost = in_array($_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1', 'localhost:80']);
if (!$is_localhost && $_SERVER['SERVER_PORT'] != 443 && empty($_SERVER['HTTPS'])) {
    $redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('HTTP/1.1 301 Moved Permanently');
    header('Location: ' . $redirect);
    exit;
}
```

---

## ✅ Checklist Sebelum Deploy

- [ ] Update DB credentials untuk hosting
- [ ] Update BASE_URL sesuai domain hosting
- [ ] Test database connection di hosting
- [ ] Clear cache browser
- [ ] Test semua halaman (Home, Blog, Portfolio, dll)
- [ ] Test admin login
- [ ] Test upload gambar/file
- [ ] Monitor error log di hosting

---

**Simpan backup ini untuk referensi nanti!** 📋
