# 🔧 PANDUAN INSTALASI LENGKAP

Panduan step-by-step untuk setup website portfolio locally.

---

## ✅ Prerequisites

Pastikan sudah terinstall:
- [XAMPP](https://www.apachefriends.org/) (terbaru)
- Text Editor ([VS Code](https://code.visualstudio.com/), Notepad++, etc)
- Browser (Chrome, Firefox, Safari)

---

## 📋 STEP 1: Persiapan XAMPP

### Start Services
1. Buka **XAMPP Control Panel**
2. Klik tombol **Start** untuk:
   - Apache
   - MySQL

Status akan berubah hijau ✅

![xampp-start](https://via.placeholder.com/300x200?text=XAMPP+Started)

---

## 📂 STEP 2: Copy Folder Project

### Lokasi Folder
Project harus berada di: `D:\XAMPP\htdocs\webset01\portfolio\`

### Cara Copy
1. Download/Extract file project
2. Pastikan struktur folder sudah benar:
   ```
   D:\XAMPP\htdocs\webset01\portfolio\
   ├── index.php
   ├── admin/
   ├── pages/
   ├── assets/
   ├── includes/
   └── portfolio_db.sql
   ```

---

## 🗄️ STEP 3: Setup Database

### Opsi A: Menggunakan phpMyAdmin (Recommended)

1. **Buka phpMyAdmin**
   - Kunjungi: `http://localhost/phpmyadmin`
   - Login (default: username: root, password: kosong)

2. **Buat Database**
   - Klik menu **Databases**
   - Di kolom "Create database", ketik: `portfolio_db`
   - Pilih collation: `utf8mb4_general_ci`
   - Klik **Create**

3. **Import SQL File**
   - Pilih database `portfolio_db` (klik di sidebar kiri)
   - Klik menu **Import**
   - Klik **Choose File** dan pilih `portfolio_db.sql`
   - Klik **Import**

   Selesai! Database sudah setup dengan tabel dan data default.

### Opsi B: Menggunakan Command Line

```bash
# Buka CMD dan navigasi ke XAMPP
cd D:\XAMPP\mysql\bin

# Import database
mysql -u root < "D:\XAMPP\htdocs\webset01\portfolio\portfolio_db.sql"

# Verifikasi (optional)
mysql -u root -e "SHOW DATABASES;"
```

---

## ⚙️ STEP 4: Konfigurasi Project

### File: `includes/config.php`

Cek database configuration sudah benar:

```php
define('DB_HOST', 'localhost');    // Host database
define('DB_USER', 'root');         // User MySQL
define('DB_PASS', '');             // Password MySQL (biasanya kosong)
define('DB_NAME', 'portfolio_db'); // Nama database
```

**Catatan:** Jika MySQL Anda pakai password, ubah `''` menjadi password-nya.

### Contoh Jika Ada Password MySQL

```php
define('DB_PASS', 'password123'); // Jika ada password
```

---

## 🚀 STEP 5: Akses Website

### Buka Browser

1. **Homepage:**
   ```
   http://localhost/webset01/portfolio/
   ```

2. **Admin Panel:**
   ```
   http://localhost/webset01/portfolio/admin/
   ```

**Selamat!** Website sudah bisa diakses 🎉

---

## 🔐 STEP 6: Login ke Admin

### Login Credentials

Default account yang sudah dibuat:
- **Username:** `admin`
- **Password:** `admin123`

### Langkah Login

1. Kunjungi: `http://localhost/webset01/portfolio/admin/`
2. Masukkan username: `admin`
3. Masukkan password: `admin123`
4. Klik **Login**

### ⚠️ PENTING: Ganti Password

Setelah login pertama kali, **segera ganti password**:
1. Edit user di database (menggunakan phpMyAdmin)
2. Atau tambahkan fitur "change password" (akan dibuat kemudian)

---

## 🧪 STEP 7: Testing

### Test Halaman Public

Cek semua halaman berjalan baik:

| Halaman | URL | Status |
|---------|-----|--------|
| Home | `http://localhost/webset01/portfolio/` | ✅ |
| About | `/pages/about.php` | ✅ |
| Skills | `/pages/skills.php` | ✅ |
| Portfolio | `/pages/portfolio.php` | ✅ |
| Blog | `/pages/blog.php` | ✅ |
| Contact | `/pages/contact.php` | ✅ |

### Test Admin Panel

| Fitur | URL | Test Case |
|-------|-----|-----------|
| Login | `/admin/` | Masuk dengan admin/admin123 |
| Dashboard | `/admin/dashboard.php` | Lihat stats |
| Blog CRUD | `/admin/blog-posts.php` | Tambah/Edit/Hapus artikel |
| Logout | `/admin/logout.php` | Kembali ke login |

### Test Database

Masuk phpMyAdmin dan cek:
- ✅ Database `portfolio_db` exist
- ✅ Tabel `blog_posts`, `portfolios`, `skills`, etc exist
- ✅ User `admin` ada di tabel `admin_users`

---

## 🔍 Troubleshooting

### ❌ Error: "Koneksi gagal"

**Masalah:** Database tidak bisa terkoneksi

**Solusi:**
1. Pastikan MySQL sudah start (XAMPP Control Panel)
2. Cek file `includes/config.php` - apakah setting benar?
3. Cek username & password MySQL yang benar

```bash
# Test koneksi di CMD
mysql -u root -p

# Jika ditanya password, tekan Enter (jika kosong) atau masukkan password
```

### ❌ Error: "Database portfolio_db not found"

**Masalah:** Database belum dibuat

**Solusi:**
1. Buka phpMyAdmin: `http://localhost/phpmyadmin`
2. Import file `portfolio_db.sql`
3. Atau jalankan di MySQL command:
```bash
mysql -u root < portfolio_db.sql
```

### ❌ Error: "Cannot load admin/dashboard.php"

**Masalah:** Folder/file belum diupload dengan benar

**Solusi:**
1. Cek struktur folder di `D:\XAMPP\htdocs\webset01\portfolio\`
2. Pastikan folder `admin/` ada dan berisi file `dashboard.php`, `login.php`, dll
3. Reload page di browser

### ❌ Halaman Putih (Blank)

**Masalah:** Error PHP yang tidak ditampilkan

**Solusi:**
1. Buka file `includes/config.php`
2. Tambahkan di awal file:
```php
ini_set('display_errors', 1);
error_reporting(E_ALL);
```
3. Reload page - akan terlihat error message-nya

### ❌ Admin Login Gagal

**Masalah:** Username/password salah atau user tidak ada

**Solusi:**
1. Cek tabel `admin_users` di phpMyAdmin
2. Pastikan ada user dengan username = `admin`
3. Password default: `admin123`

Jika lupa password, edit di phpMyAdmin:
```php
// Generate password hash untuk "admin123"
password_hash('admin123', PASSWORD_DEFAULT);
```

---

## 📚 Referensi File

### Konfigurasi
- `includes/config.php` - Database & constants
- `.htaccess` - Server configuration

### Database
- `portfolio_db.sql` - Database schema & default data

### Dokumentasi
- `README.md` - Overview & features
- `INSTALLATION.md` - File ini

---

## ✨ Setup Selesai!

Website portfolio Anda sudah siap digunakan dan dikembangkan.

### Next Step:

1. ✅ Customisasi data profil (di database atau edit manual)
2. ✅ Tambahkan portfolio/proyek baru via admin
3. ✅ Tulis artikel blog
4. ✅ Ganti password admin
5. ✅ Deploy ke hosting (nantinya)

---

## 📞 Help & Support

Jika ada masalah:

1. **Check Error Log**
   - Buka file: `D:\XAMPP\apache\logs\error.log`
   
2. **Check Browser Console**
   - Tekan `F12` → Console → lihat error message

3. **Check Database**
   - Buka phpMyAdmin dan cek tabel-tabel

4. **Test Configuration**
   - Buat file test.php dengan isi:
   ```php
   <?php
   phpinfo();
   ?>
   ```
   - Kunjungi: `http://localhost/webset01/portfolio/test.php`

---

**Happy Coding! 🚀**

Semoga website portofolio Anda sukses dan professional!
