# ANALYTICS DASHBOARD - DOKUMENTASI FITUR

## 📊 Fitur Analytics yang Telah Ditambahkan

Sistem analytics telah berhasil ditambahkan ke dashboard admin untuk melacak traffic dan statistik website Anda.

### ✅ Fitur-Fitur Analytics

#### 1. **Tracking Otomatis**
- Setiap kunjungan ke halaman publik secara otomatis tercatat
- Sistem mencatat:
  - URL halaman yang dikunjungi
  - IP Address pengunjung
  - User Agent (browser/device)
  - Referrer (dari mana pengunjung berasal)
  - Waktu kunjungan
  - Hanya admin pages tidak ditrack untuk efisiensi

#### 2. **Statistik Real-Time di Dashboard**
Menampilkan 4 metrik utama:
- **Total Kunjungan**: Total semua kunjungan ke website
- **Pengunjung Unik**: Jumlah IP Address berbeda yang mengakses
- **Halaman Dikunjungi**: Total jumlah halaman unik yang diakses
- **Kunjungan Hari Ini**: Kunjungan pada tanggal sekarang

#### 3. **Grafik Kunjungan 7 Hari Terakhir**
- Visualisasi menggunakan Chart.js
- Menampilkan 2 metrik:
  - Total kunjungan per hari
  - Pengunjung unik per hari
- Auto-update setiap 30 detik

#### 4. **Halaman Paling Populer**
Tabel menunjukkan:
- URL halaman
- Total kunjungan ke halaman tersebut
- Pengunjung unik
- Waktu kunjungan terakhir

Diurutkan dari halaman paling banyak dikunjungi

#### 5. **Kunjungan Terbaru**
Tabel real-time menampilkan:
- 20 kunjungan terakhir
- URL halaman yang dikunjungi
- IP Address pengunjung
- Waktu kunjungan

### 📁 File-File Yang Ditambahkan/Dimodifikasi

1. **includes/config.php** (MODIFIED)
   - Tambah: Fungsi `trackPageVisit()` untuk mencatat setiap kunjungan
   - Implementasi: 5-menit debounce per IP untuk mencegah double-count
   - Hanya track halaman publik (bukan admin pages)

2. **admin/analytics.php** (NEW)
   - Halaman dashboard analytics utama
   - Styling dengan gradient cards dan Chart.js
   - AJAX auto-refresh setiap 30 detik
   - Responsive design untuk mobile

3. **admin/api/get-analytics.php** (NEW)
   - API endpoint untuk fetch data analytics
   - Mengembalikan JSON dengan statistik lengkap
   - Protected: hanya bisa diakses jika sudah login

4. **admin/sidebar.php** (MODIFIED)
   - Tambah: Menu item "Analytics" dengan icon chart-line
   - Link ke analytics.php

5. **add_analytics_table.sql** (NEW)
   - SQL script untuk membuat tabel page_visits
   - Membuat VIEW daily_stats untuk statistik harian
   - Membuat VIEW page_popularity untuk analisis halaman populer

### 🗄️ Database Schema

#### Tabel `page_visits`
```sql
CREATE TABLE page_visits (
  id              INT PRIMARY KEY AUTO_INCREMENT
  page_url        VARCHAR(255)
  page_title      VARCHAR(255)
  referrer        VARCHAR(255)
  user_agent      TEXT
  ip_address      VARCHAR(45)
  created_at      TIMESTAMP (indexed for fast queries)
)
```

**Indexes untuk performance:**
- `idx_page_url` - untuk query berdasarkan halaman
- `idx_created_at` - untuk query berdasarkan tanggal
- `idx_ip_address` - untuk tracking pengunjung unik

#### View `daily_stats`
Menampilkan statistik harian:
- Tanggal
- Total kunjungan
- Pengunjung unik
- Jumlah halaman unik yang diakses

#### View `page_popularity`
Menampilkan popularitas halaman:
- URL halaman
- Jumlah kunjungan
- Pengunjung unik
- Waktu kunjungan terakhir

### 🎯 Cara Menggunakan

#### Akses Analytics Dashboard
1. Login ke admin panel: `http://localhost/webset01/portfolio/admin/`
2. Username: `admin` | Password: `admin123`
3. Klik menu "Analytics" di sidebar
4. Dashboard akan menampilkan statistik real-time

#### Fitur-Fitur pada Analytics Dashboard
- **Stat Cards**: Menampilkan 4 metrik utama (Total, Unik, Halaman, Hari ini)
- **Grafik 7 Hari**: Hover untuk melihat detail per hari
- **Tabel Populer**: Scroll horizontal untuk mobile
- **Tabel Terbaru**: Melihat 20 kunjungan terakhir

#### Auto-Refresh
- Dashboard auto-refresh setiap 30 detik
- Tidak perlu refresh manual
- Data selalu up-to-date

### 💡 Cara Kerja Tracking

#### Ketika User Mengakses Halaman Publik:
1. `config.php` dimuat
2. Fungsi `trackPageVisit()` dipanggil
3. Sistem cek apakah IP sudah visit dalam 5 menit terakhir
4. Jika belum, data kunjungan dicatat ke tabel `page_visits`
5. Jika sudah, tidak dicatat (untuk menghindari spam)

#### Data Yang Dicatat:
- URL yang dikunjungi: `/webset01/portfolio/pages/about.php`
- IP pengunjung: `192.168.1.100`
- Browser/Device: User-Agent string
- Dari mana (referrer): URL sebelumnya
- Waktu: Timestamp saat ini

### 📊 Query Data Analytics

Jika ingin query langsung di MySQL:

**Total kunjungan:**
```sql
SELECT COUNT(*) FROM page_visits;
```

**Pengunjung unik:**
```sql
SELECT COUNT(DISTINCT ip_address) FROM page_visits;
```

**Halaman paling populer:**
```sql
SELECT page_url, COUNT(*) as visits 
FROM page_visits 
GROUP BY page_url 
ORDER BY visits DESC;
```

**Statistik harian:**
```sql
SELECT * FROM daily_stats LIMIT 7;
```

### 🔒 Keamanan

- Analytics hanya bisa diakses jika sudah login (protected by auth_check.php)
- Tracking tidak mencatat admin pages
- IP address disimpan untuk analisis (bukan untuk identifikasi personal)
- CSRF protection pada login
- Session validation di setiap request

### 📈 Performa

- Tracking menggunakan query yang dioptimasi dengan index
- Hanya cek 5 menit terakhir (tidak scan seluruh tabel)
- View queries aggregated untuk response cepat
- AJAX loading tanpa page reload

### 🎨 Design

- Gradient cards dengan warna berbeda per metrik
- Chart.js untuk visualisasi yang smooth
- Responsive design (mobile, tablet, desktop)
- Dark theme sesuai dengan design website
- Icon Font Awesome untuk visual yang menarik

### ⚡ Performance Tips

1. Data tracking 5 menit debounce: Mencegah pencatatan spam dari bot
2. Indexed columns: Query cepat bahkan dengan data besar
3. View aggregation: Tidak perlu compute ulang setiap query
4. Ajax partial reload: Hanya update data, tidak reload halaman

### 🚀 Skalabilitas Masa Depan

Sistem ini bisa dikembangkan dengan:
- Export analytics ke CSV/PDF
- Custom date range selection
- Filter by page/referrer/device
- Real-time notifications for traffic spikes
- Heatmap tracking
- Scroll depth tracking
- Form completion tracking

---

**Status**: ✅ Sistem Analytics Aktif dan Berfungsi
**Installation**: Otomatis - sudah terintegrasi ke config.php
**Database**: Sudah dibuat tabel page_visits, daily_stats, page_popularity
**Testing**: Data sample sudah diinsert untuk demo

