# 🚀 QUICK START - Advanced Visual Blog Builder

## ⚡ 3 Langkah Cepat

### **Step 1: Setup Database**
Buka di browser:
```
http://localhost/webset%203.0.0/setup-blog.php
```
✅ Tunggu sampai muncul "Setup selesai!"

---

### **Step 2: Login Admin**
```
http://localhost/webset%203.0.0/admin/login.php
```
Username: admin
Password: admin123 (atau password Anda)

---

### **Step 3: Mulai Buat Artikel!**

**Opsi A - Buat Baru:**
```
Admin Dashboard > Blog > Tombol "Buat Artikel Baru"
atau langsung:
http://localhost/webset%203.0.0/admin/blog-builder.php
```

**Opsi B - Kelola Artikel:**
```
http://localhost/webset%203.0.0/admin/blog-articles.php
```

---

## 📝 Interface Blog Builder

```
┌─────────────────────────────────────────────────────────┐
│  Left Panel (Editor)        │   Right Panel (Preview)   │
├─────────────────────────────────────────────────────────┤
│ • Judul                     │   Live Preview             │
│ • Slug                      │   Real-time update         │
│ • Kategori                  │   Tampilan Artikel         │
│ • Featured Image            │   sesuai asli              │
│ • Excerpt                   │                           │
│ • Tags                      │                           │
│                             │                           │
│ ┌──────────────────────┐   │                           │
│ │ Tambah Blok:         │   │                           │
│ │ • Heading            │   │                           │
│ │ • Paragraph          │   │                           │
│ │ • Image              │   │                           │
│ │ • Quote              │   │                           │
│ │ • Code               │   │                           │
│ │ • Video              │   │                           │
│ │ • List               │   │                           │
│ │ • Spacer             │   │                           │
│ └──────────────────────┘   │                           │
│                             │                           │
│ ┌──────────────────────┐   │                           │
│ │ Blok yang ditambah:  │   │                           │
│ │ 1. Heading (H2)      │↑↓ │ Preview update...         │
│ │ 2. Paragraph         │↑↓ │                           │
│ │ 3. Image             │↑↓ │                           │
│ └──────────────────────┘   │                           │
└─────────────────────────────────────────────────────────┘
                              
              [Batal] [Simpan Draft] [Publish]
```

---

## 🎯 Workflow Membuat Artikel

1. **Isi Informasi Dasar:**
   - Judul: "Pembentukan PR IPNU IPPNU Desa Napis"
   - Slug: auto-generate
   - Kategori: Berita
   - Featured Image: https://example.com/image.jpg

2. **Tambah Blok Konten:**
   - Heading (H3) → Intro
   - Paragraph → Isi
   - Image → Foto acara
   - List → Hasil pemilihan
   - Paragraph → Penutup

3. **Preview & Edit:**
   - Lihat preview di kanan
   - Urutkan blok dengan tombol ↑↓
   - Hapus blok yang tidak perlu

4. **Publish:**
   - **Simpan Draft** = Belum terlihat publik
   - **Publish** = Langsung live di website

---

## 💡 Pro Tips

### **Gambar Eksternal (Hemat Storage!):**
1. Upload ke: [Cloudinary](https://cloudinary.com) (gratis 25GB)
2. Copy public URL
3. Paste di "Featured Image" atau Image block

### **Video:**
- YouTube: Klik Share > Embed > Copy src
- Contoh: `https://www.youtube.com/embed/VIDEO_ID`

### **SEO:**
- **Slug:** gunakan huruf, angka, dash → `pembentukan-pr-ipnu`
- **Excerpt:** ringkasan singkat 50-100 kata
- **Tags:** pisahkan dengan koma → `IPNU, IPPNU, Organisasi`

### **Editing:**
- Edit existing? Buka dari Blog > Edit (icon pensil)
- Hapus artikel? Blog > Delete (icon trash)

---

## 📊 Performa & Storage

| Metrik | Nilai |
|--------|-------|
| Per artikel | ~10-15 KB |
| 100 artikel | ~1.5 MB |
| Hosting 1GB | Cukup untuk 50-70+ artikel |
| Database | Sangat ringan |
| Load time | ⚡ Super cepat |

---

## 🔒 Security

- ✅ Login required
- ✅ SQL injection protection
- ✅ HTML sanitized
- ✅ Prepared statements

---

## 🆘 Bantuan Cepat

| Masalah | Solusi |
|--------|--------|
| Halaman blank | Refresh F5 atau cache clear |
| Gambar not loaded | Check URL valid & accessible |
| Slug error | Make it unique |
| Publish button disabled | Check semua field terisi |
| Database error | Buka setup-blog.php lagi |

---

## 📂 File Penting

```
/admin/blog-builder.php      ← Editor utama
/admin/blog-articles.php     ← List & manage
/admin/blog-view.php         ← Display artikel
/admin/api/blog-save.php     ← Save API
/setup-blog.php              ← Database setup
/BLOG_BUILDER_GUIDE.md       ← Dokumentasi lengkap
```

---

## ✨ Fitur Yang Dioptimalkan

✅ **Hemat Storage** → JSON + External Images
✅ **Fast Query** → Indexed database
✅ **User Friendly** → Visual drag-drop
✅ **Production Ready** → Tested & Secure
✅ **Mobile Responsive** → Desktop-first
✅ **SEO Friendly** → Slug, Meta, Tags
✅ **Easy Management** → All-in-one interface

---

## 🎓 Contoh Artikel

Di blog-articles.php sudah ada 1 sample artikel yang bisa diedit/dihapus.

---

**Status:** ✅ SIAP DIGUNAKAN
**Tanggal:** 23 January 2026
**Version:** 1.0 - Advanced Visual Blog Builder

Selamat membuat artikel! 🚀
