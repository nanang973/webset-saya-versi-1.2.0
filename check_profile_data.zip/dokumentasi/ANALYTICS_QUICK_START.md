# 📊 ANALYTICS QUICK START

## Akses Analytics Dashboard

### Langkah 1: Login Admin
```
URL: http://localhost/webset01/portfolio/admin/
Username: admin
Password: admin123
```

### Langkah 2: Klik Analytics
Di sidebar sebelah kiri, klik menu **"Analytics"** (icon grafik)

### Langkah 3: Lihat Statistik
Dashboard akan menampilkan:
- 4 statistik utama (Total, Unik, Halaman, Hari ini)
- Grafik kunjungan 7 hari
- Daftar halaman paling populer
- Kunjungan terbaru

---

## 📈 Statistik yang Ditampilkan

### 1. Total Kunjungan
- Jumlah semua akses ke website
- Contoh: 15 kunjungan

### 2. Pengunjung Unik  
- Berapa IP address berbeda
- Contoh: 12 pengunjung unik

### 3. Halaman Dikunjungi
- Total halaman berbeda yang diakses
- Contoh: 6 halaman

### 4. Kunjungan Hari Ini
- Akses pada hari sekarang saja
- Contoh: 3 kunjungan

---

## 🔥 Halaman Paling Populer

Menampilkan halaman mana yang paling banyak dikunjungi:

| Halaman | Kunjungan | Pengunjung | Terakhir |
|---------|-----------|-----------|---------|
| Homepage | 6 | 5 | 14:30 |
| Skills | 3 | 3 | 14:28 |
| About | 2 | 2 | 14:25 |

---

## 📱 Cara Kerja Tracking

### Tracking Otomatis
✅ Setiap kunjungan halaman publik dicatat otomatis

### Data Yang Dicatat
- URL halaman
- IP address pengunjung
- Browser/Device (User Agent)
- Waktu kunjungan
- Referrer (dari mana datang)

### Debounce 5 Menit
- IP yang sama dalam 5 menit hanya dicatat 1x
- Cegah pencatatan spam dari bot
- Lebih akurat

### Admin Pages Tidak Ditrack
- Halaman `/admin/` tidak dicatat
- Fokus pada traffic halaman publik

---

## 🎯 Use Cases

### Monitoring Traffic
- Lihat berapa banyak orang akses website
- Pantau trending halaman

### Optimize Content
- Lihat halaman mana yang paling diminati
- Perbaiki halaman yang jarang dikunjungi

### Track Growth
- Monitor pertumbuhan traffic setiap hari
- Analisis tren 7 hari

### Understand Visitors
- Lihat device/browser yang digunakan
- Ketahui dari mana pengunjung datang

---

## 💾 Database

**Tabel**: `page_visits`
- Menyimpan setiap kunjungan
- 15 records dalam demo

**View**: `daily_stats`
- Statistik per hari

**View**: `page_popularity`
- Ranking halaman

---

## 🔍 Contoh Skenario

### Skenario 1: Cek Traffic Harian
1. Login ke admin
2. Buka Analytics
3. Lihat "Kunjungan Hari Ini"
4. Cek grafik untuk trend

### Skenario 2: Halaman Mana Populer
1. Login ke admin
2. Buka Analytics
3. Scroll ke "Halaman Paling Populer"
4. Lihat tabel urutannya

### Skenario 3: Monitor Pengunjung Baru
1. Login ke admin
2. Buka Analytics
3. Scroll ke "Kunjungan Terbaru"
4. Lihat IP dan waktu terbaru

---

## ⚙️ Pengaturan Tracking

### Ubah Debounce Time
Di `includes/config.php`, cari:
```php
AND created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
```
Ubah `5 MINUTE` ke waktu yang diinginkan

### Exclude Halaman dari Tracking
Di `trackPageVisit()` function, tambahkan:
```php
if (strpos($current_page, '/pages/contact.php') !== false) {
    return;
}
```

---

## 📊 Query Langsung Database

### Total Visit Hari Ini
```sql
SELECT COUNT(*) FROM page_visits 
WHERE DATE(created_at) = CURDATE();
```

### Halaman Paling Populer
```sql
SELECT page_url, COUNT(*) as visits 
FROM page_visits 
GROUP BY page_url 
ORDER BY visits DESC LIMIT 5;
```

### Pengunjung Unik
```sql
SELECT COUNT(DISTINCT ip_address) FROM page_visits;
```

---

## ✨ Fitur Auto-Refresh

- Dashboard auto-refresh **setiap 30 detik**
- Data selalu up-to-date
- Tidak perlu refresh manual
- Bisa dipantau realtime

---

## 🚀 Next Steps

### Sekarang Bisa:
✅ Monitor traffic real-time  
✅ Lihat halaman populer  
✅ Track growth  
✅ Understand visitors  

### Bisa Dikembangkan Ke:
📥 Export data ke CSV/PDF  
📅 Custom date range  
🔍 Filter by device/browser  
🎨 Heatmap tracking  
🔔 Alert notifications  

---

## 📞 Support

Jika ada pertanyaan atau error:
1. Check browser console (F12)
2. Check MySQL error logs
3. Verify database tables exist
4. Clear browser cache

---

**Happy Analytics! 📊**

