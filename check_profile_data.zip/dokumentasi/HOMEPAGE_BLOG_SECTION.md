# 📰 Halaman Home - Bagian Blog & Artikel Terbaru

Panduan lengkap untuk mengatur dan mengkustomisasi bagian **Blog & Artikel Terbaru** di halaman home.

---

## 🎯 Overview

Bagian ini menampilkan **3 artikel blog terbaru** yang dipublikasikan di halaman home, dengan fitur:
- ✅ Tampilan card modern dan responsif
- ✅ Preview gambar artikel
- ✅ Kategori artikel
- ✅ Deskripsi singkat (preview)
- ✅ Tanggal publikasi
- ✅ Link ke artikel lengkap
- ✅ Animasi hover yang menarik

---

## 📁 File Yang Terlibat

### **Frontend (Public)**

| File | Fungsi |
|------|--------|
| `index.php` | Halaman home yang menampilkan bagian blog |
| `assets/css/style.css` | Styling untuk blog section |
| `assets/js/main.js` | Interaksi/animasi blog cards |

### **Backend (Database)**

| Database | Tabel | Field Penting |
|----------|-------|---------------|
| `portfolio_db` | `blog_posts` | `id`, `title`, `category`, `description`, `content`, `featured_image`, `created_at`, `status` |

---

## 🔧 Cara Kerja

### **1. Data Source - Blog Posts**

Artikel diambil dari database tabel `blog_posts`:

```php
// File: index.php (baris ~25)
$featured_blogs = $conn->query(
    "SELECT * FROM blog_posts 
     WHERE status = 'published' 
     ORDER BY created_at DESC 
     LIMIT 3"
)->fetch_all(MYSQLI_ASSOC);
```

**Penjelasan:**
- `WHERE status = 'published'` → Hanya tampilkan artikel yang sudah dipublikasikan
- `ORDER BY created_at DESC` → Urutkan dari terbaru ke terlama
- `LIMIT 3` → Ambil hanya 3 artikel teratas

---

### **2. Ekstraksi Konten**

Artikel menggunakan format JSON block editor. Ada dua helper function untuk ekstraksi:

#### **Function 1: extractImageFromContent()**
```php
function extractImageFromContent($content) {
    // Mencari dan mengambil gambar pertama dari block editor
    // Jika tidak ada, fallback ke featured_image atau image field
}
```

#### **Function 2: extractTextPreview()**
```php
function extractTextPreview($content, $length = 150) {
    // Mengambil teks preview (deskripsi singkat)
    // Default 150 karakter
}
```

**Fallback Priority:**
1. **$blog['description']** → Jika ada deskripsi khusus
2. **extractTextPreview()** → Dari konten artikel
3. Jika tidak ada → Tampilkan teks kosong

---

### **3. HTML Structure**

```html
<!-- Bagian Blog & Artikel Terbaru -->
<section class="blog-section">
    <div class="container">
        <h2 class="section-title">Blog & Artikel Terbaru</h2>
        
        <!-- Blog Grid -->
        <div class="blog-grid">
            <!-- Setiap artikel ditampilkan sebagai card -->
            <article class="blog-card">
                <div class="blog-image">
                    <!-- Gambar artikel atau placeholder -->
                </div>
                <div class="blog-content">
                    <span class="blog-category">Kategori</span>
                    <h3 class="blog-title">Judul Artikel</h3>
                    <p class="blog-desc">Deskripsi preview...</p>
                    <div class="blog-meta">
                        <span>Tanggal publikasi</span>
                        <a href="#" class="btn-link">Baca Selengkapnya →</a>
                    </div>
                </div>
            </article>
        </div>
        
        <!-- Tombol "Lihat Semua Artikel" -->
        <div class="text-center mt-40">
            <a href="pages/blog.php" class="btn btn-primary">Lihat Semua Artikel</a>
        </div>
    </div>
</section>
```

---

## 🎨 Styling CSS

Semua styling ada di: `assets/css/style.css` (baris ~669-790)

### **Key CSS Classes:**

| Class | Fungsi |
|-------|--------|
| `.blog-section` | Container section |
| `.blog-grid` | Grid layout (auto-fill, 3 kolom pada desktop) |
| `.blog-card` | Card individual |
| `.blog-image` | Area gambar (tinggi 200px) |
| `.blog-content` | Area konten artikel |
| `.blog-category` | Badge kategori |
| `.blog-title` | Judul artikel |
| `.blog-desc` | Deskripsi/preview |
| `.blog-meta` | Meta info (tanggal + link) |

### **Responsive Design:**

```css
/* Desktop (> 768px) */
.blog-grid {
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 25px;
}

/* Tablet & Mobile (≤ 768px) */
@media (max-width: 768px) {
    .blog-grid {
        grid-template-columns: 1fr;
    }
}
```

---

## ⚙️ Cara Mengatur

### **1. Mengubah Judul Bagian**

**File:** `index.php` (baris ~172)

```php
// Cari:
<h2 class="section-title animate-slide-up">Blog & Artikel Terbaru</h2>

// Ubah ke:
<h2 class="section-title animate-slide-up">Artikel & Tips Terbaru</h2>
```

---

### **2. Mengubah Jumlah Artikel Ditampilkan**

**File:** `index.php` (baris ~25)

```php
// Cari:
$featured_blogs = $conn->query(
    "SELECT * FROM blog_posts WHERE status = 'published' 
     ORDER BY created_at DESC LIMIT 3"
)->fetch_all(MYSQLI_ASSOC);

// Ubah "LIMIT 3" menjadi jumlah yang diinginkan
// Contoh: LIMIT 5 (tampilkan 5 artikel)
```

---

### **3. Mengubah Teks Tombol "Lihat Semua Artikel"**

**File:** `index.php` (baris ~216)

```php
// Cari:
<a href="pages/blog.php" class="btn btn-primary">Lihat Semua Artikel</a>

// Ubah teks button ke:
<a href="pages/blog.php" class="btn btn-primary">Baca Semua Artikel</a>
```

---

### **4. Mengubah Styling Blog Cards**

Edit di `assets/css/style.css`:

#### **Ukuran Gambar:**
```css
.blog-image {
    height: 200px;  /* Ubah ke nilai yang diinginkan */
}
```

#### **Warna Category Badge:**
```css
.blog-category {
    background: rgba(59, 130, 246, 0.2);  /* Ubah color */
    color: var(--primary);
}
```

#### **Ukuran Gap Antar Card:**
```css
.blog-grid {
    gap: 25px;  /* Ubah ke spacing yang diinginkan */
}
```

---

## 📝 Menambah Artikel Baru

### **Via Admin Dashboard:**

1. Buka: `http://localhost/webset-3.0.0/admin/blog-builder.php`
2. Klik **"Tambah Artikel Baru"**
3. Isi detail:
   - **Judul:** Judul artikel
   - **Kategori:** Pilih kategori (e.g., "Web Dev", "Tips")
   - **Konten:** Buat konten dengan block editor
   - **Deskripsi:** Ringkasan singkat (opsional)
   - **Featured Image:** URL gambar
4. Klik **"Publish"**

### **Artikel akan otomatis muncul di:**
- ✅ Halaman Home (Blog & Artikel Terbaru)
- ✅ Halaman `/pages/blog.php` (Semua artikel)
- ✅ Halaman detail artikel (individual)

---

## 🎯 Best Practices

### **1. Deskripsi Artikel**

Isi field **deskripsi** untuk hasil yang lebih baik:
```
✅ BAIK:
"Panduan lengkap setup IoT dengan Arduino dan sensor DHT11"

❌ KURANG:
"Tutorial Arduino"
```

### **2. Featured Image**

Gunakan gambar dengan dimensi:
- **Ideal:** 1200 x 630px
- **Min:** 600 x 400px
- **Format:** JPG, PNG (ukuran < 500KB)

### **3. Kategori**

Gunakan kategori yang konsisten:
- Web Development
- IoT & Hardware
- Tips & Tricks
- Tutorial

### **4. Judul Artikel**

Buat judul yang SEO-friendly:
```
✅ BAIK:
"Cara Setup Database MySQL di XAMPP untuk Pemula"

❌ KURANG:
"Setup Database"
```

---

## 🔗 Link Terkait

- **Blog Builder Guide:** [BLOG_BUILDER_GUIDE.md](BLOG_BUILDER_GUIDE.md)
- **Blog Builder Quick Start:** [BLOG_BUILDER_QUICKSTART.md](BLOG_BUILDER_QUICKSTART.md)
- **Customization:** [CUSTOMIZATION.md](CUSTOMIZATION.md)
- **Database Structure:** [README.md](README.md)

---

## 📱 Responsive Behavior

| Device | Tampilan |
|--------|----------|
| **Desktop (≥1024px)** | 3 kolom grid |
| **Tablet (768-1024px)** | 2 kolom grid |
| **Mobile (<768px)** | 1 kolom grid (full width) |

---

## 🐛 Troubleshooting

### **Artikel tidak tampil di halaman home**

**Solusi:**
1. Pastikan artikel sudah **Published** (status = 'published')
2. Check database: `SELECT * FROM blog_posts;`
3. Clear browser cache (Ctrl+Shift+Del)

### **Gambar tidak tampil**

**Solusi:**
1. Pastikan URL gambar valid dan bisa diakses
2. Check console browser (F12) untuk error messages
3. Gunakan format gambar yang valid (JPG, PNG, WebP)

### **Layout berantakan di mobile**

**Solusi:**
1. Clear cache browser
2. Cek meta viewport di `includes/header.php`
3. Test di Chrome DevTools (F12 → Responsive Mode)

---

## 📞 Support

Jika ada pertanyaan atau masalah, cek dokumentasi:
- [README.md](README.md) - Overview lengkap
- [CUSTOMIZATION.md](CUSTOMIZATION.md) - Tips customization
- [BLOG_BUILDER_GUIDE.md](BLOG_BUILDER_GUIDE.md) - Panduan blog builder

---

**Last Updated:** January 26, 2026  
**Version:** 3.0.0
