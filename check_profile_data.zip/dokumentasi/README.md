# 🎯 Portfolio Website Nanang Khasan Bisri

Website portofolio pribadi untuk **Nanang Khasan Bisri** - Mahasiswa Teknik Informatika, IoT Developer, dan Web Developer.

## 📋 Daftar Isi

- [Fitur](#-fitur)
- [Tech Stack](#-tech-stack)
- [Struktur Folder](#-struktur-folder)
- [Instalasi](#-instalasi)
- [Setup Database](#-setup-database)
- [Penggunaan](#-penggunaan)
- [Login Admin](#-login-admin)
- [Dokumentasi Halaman](#-dokumentasi-halaman)

---

## ✨ Fitur

### Halaman Publik
- ✅ **Home** - Hero section dengan animasi, quick stats
- ✅ **Tentang Saya** - Profil, pendidikan, pengalaman organisasi
- ✅ **Skills** - Skill dengan progress bar, tech stack
- ✅ **Portfolio** - Daftar proyek dengan filter kategori
- ✅ **Blog** - List artikel dengan kategori
- ✅ **Kontak** - Form kontak + informasi kontak

### Dashboard Admin
- ✅ **Login System** - Autentikasi dengan password hashing
- ✅ **Dashboard** - Overview statistik
- ✅ **Blog Management** - CRUD artikel blog
- ✅ **Portfolio Management** - Kelola portofolio (ready)
- ✅ **Responsive Design** - Mobile-friendly

### Desain & UX
- ✅ **Dark Mode Theme** - Tema gelap profesional
- ✅ **Animasi Smooth** - Scroll animation, hover effects
- ✅ **Responsive** - Works on desktop, tablet, mobile
- ✅ **Modern UI** - Minimalis dan profesional

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | HTML5, CSS3, JavaScript (Vanilla) |
| **Backend** | PHP 7.4+ |
| **Database** | MySQL 5.7+ |
| **Server** | Apache (XAMPP) |
| **Icons** | Font Awesome 6 |
| **Fonts** | Google Fonts (Poppins) |

---

## 📂 Struktur Folder

```
portfolio/
├── index.php                      # Homepage
├── portfolio_db.sql              # Database setup
├── README.md                     # Dokumentasi
│
├── includes/
│   ├── config.php               # Konfigurasi database & konstanta
│   ├── header.php               # Template navbar
│   └── footer.php               # Template footer
│
├── pages/
│   ├── about.php                # Halaman tentang saya
│   ├── skills.php               # Halaman skills
│   ├── portfolio.php            # Halaman portofolio
│   ├── blog.php                 # Halaman blog
│   ├── blog-detail.php          # Detail artikel (siap dibuat)
│   └── contact.php              # Halaman kontak
│
├── admin/
│   ├── index.php                # Redirect ke dashboard
│   ├── login.php                # Login form
│   ├── dashboard.php            # Dashboard admin
│   ├── blog-posts.php           # Manajemen blog
│   ├── portfolio.php            # Manajemen portfolio
│   └── logout.php               # Logout
│
├── assets/
│   ├── css/
│   │   ├── style.css            # Styling utama (dark mode)
│   │   └── admin.css            # Styling admin panel
│   │
│   ├── js/
│   │   ├── main.js              # Script utama (animasi, interaksi)
│   │   └── admin.js             # Script admin
│   │
│   └── images/                  # Folder gambar (kosong)
```

---

## 🚀 Instalasi

### Prerequisites
- XAMPP terinstall dan berjalan
- PHP 7.4 atau lebih tinggi
- MySQL aktif

### Langkah Instalasi

1. **Copy folder ke XAMPP**
   ```bash
   Copy folder 'portfolio' ke: D:\XAMPP\htdocs\webset01\portfolio
   ```

2. **Setup Database**
   - Buka phpMyAdmin: `http://localhost/phpmyadmin`
   - Buat database baru atau import file SQL (lihat dibawah)

3. **Update Konfigurasi**
   - Edit file `includes/config.php` jika perlu:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');           // Password MySQL (biasanya kosong)
   define('DB_NAME', 'portfolio_db');
   ```

4. **Buka Website**
   ```
   http://localhost/webset01/portfolio/
   ```

---

## 🗄️ Setup Database

### Opsi 1: Menggunakan phpMyAdmin

1. Buka phpMyAdmin: `http://localhost/phpmyadmin`
2. Klik **Import**
3. Upload file `portfolio_db.sql`
4. Klik **Import**

### Opsi 2: Menggunakan Command Line

```bash
mysql -u root < portfolio_db.sql
```

### Default Admin Account
- **Username:** `admin`
- **Password:** `admin123`

⚠️ **PENTING**: Ganti password setelah login pertama kali!

---

## 📖 Penggunaan

### Akses Website Public
```
http://localhost/webset01/portfolio/
```

Navigasi akan otomatis memunculkan menu:
- Home
- Tentang
- Skills
- Portofolio
- Blog
- Kontak
- Admin

### Akses Admin Dashboard
```
http://localhost/webset01/portfolio/admin/
```

Login dengan:
- Username: `admin`
- Password: `admin123`

---

## 🔐 Login Admin

### Halaman Login
- URL: `http://localhost/webset01/portfolio/admin/login.php`
- Atau klik link **Admin** di navbar

### Session Management
- Session berlaku selama browser tidak ditutup
- Otomatis logout setelah 24 jam (default PHP)
- Klik **Logout** untuk logout manual

### Password Security
- Password di-hash menggunakan `password_hash()` (bcrypt)
- Tidak disimpan dalam plain text di database

---

## 📄 Dokumentasi Halaman

### 1. **Home (index.php)**
Menampilkan:
- Hero section dengan nama & role
- Quick stats (total proyek, skill, pengalaman)
- Featured projects terbaru
- CTA buttons (Lihat Profil, Hubungi)

### 2. **Tentang (pages/about.php)**
Menampilkan:
- Deskripsi diri singkat
- Pendidikan
- Pengalaman organisasi (IPNU, Nanang Store)
- Timeline pengalaman

### 3. **Skills (pages/skills.php)**
Menampilkan:
- Skills dengan progress bar (IoT, Web, Tools)
- Proficiency level (0-100%)
- Tech stack icons
- Kategorisasi skill

### 4. **Portfolio (pages/portfolio.php)**
Menampilkan:
- Grid portofolio dengan filter kategori
- Kategori: All, IoT, Website, Bisnis
- Detail proyek: teknologi yang digunakan
- Link ke proyek (siap dikustomisasi)

### 5. **Blog (pages/blog.php)**
Menampilkan:
- List artikel dari database
- Kategori artikel
- Tanggal posting
- Excerpt artikel
- Link ke detail artikel

### 6. **Kontak (pages/contact.php)**
Fitur:
- Form kontak (nama, email, subjek, pesan)
- Validasi form client-side
- Simpan ke database
- Informasi kontak (email, WhatsApp, lokasi)
- Social media links

### 7. **Admin Dashboard (admin/dashboard.php)**
Menampilkan:
- Statistik (total blog, portfolio, skill, pesan)
- Recent blog posts
- Quick access ke semua fitur admin
- Sidebar navigation

### 8. **Blog Management (admin/blog-posts.php)**
Fitur:
- List semua artikel
- CRUD artikel (Create, Read, Update, Delete)
- Set status (draft/published)
- Kategori artikel
- Rich text editor ready (bisa ditambah)

---

## 🎨 Customization Guide

### Mengubah Warna Theme

Edit `assets/css/style.css` di bagian `:root`:

```css
:root {
    --primary: #3b82f6;        /* Biru - ubah di sini */
    --secondary: #8b5cf6;      /* Ungu */
    --bg-dark: #0f172a;        /* Background gelap */
    /* ... */
}
```

### Mengubah Data Profil

Edit file `includes/config.php` atau update via admin dashboard (ready untuk dibuat).

### Menambah Halaman Baru

1. Buat file baru di folder `pages/`
2. Include header & footer:
```php
<?php
require_once '../includes/config.php';
$page_title = 'Nama Halaman';
include '../includes/header.php';
?>

<!-- KONTEN HALAMAN -->

<?php include '../includes/footer.php'; ?>
```

---

## 🔧 Troubleshooting

### Error: Database Connection Failed
- Pastikan XAMPP running (Apache & MySQL aktif)
- Cek username/password di `includes/config.php`
- Pastikan database sudah dibuat

### Error: Halaman Blank
- Cek error log PHP: `D:\XAMPP\apache\logs\error.log`
- Enable error reporting di PHP

### Form Tidak Bisa Submit
- Pastikan database `contact_messages` table exist
- Cek file `pages/contact.php` permissions

---

## 📝 Next Steps / Improvements

- [ ] Tambahkan rich text editor untuk blog (TinyMCE/CKEditor)
- [ ] Implementasi image upload untuk blog & portfolio
- [ ] Tambahkan comment system di blog
- [ ] Setup email notification untuk kontak form
- [ ] Implementasi search functionality
- [ ] Add Google Analytics
- [ ] Optimize SEO (meta tags, sitemap)
- [ ] Add PWA support (offline functionality)
- [ ] Implementasi caching system
- [ ] Add dark/light mode toggle
- [ ] Mobile app integration

---

## 📞 Support & Contact

Untuk pertanyaan atau bantuan:
- Email: nanang@example.com
- WhatsApp: +62xxxx
- Instagram: @nanang_khasan

---

## 📄 License

Free to use for personal and commercial projects.

---

## 🙏 Terima Kasih

Website ini dibuat dengan ❤️ untuk membangun portofolio profesional.

**Happy Coding! 🚀**
