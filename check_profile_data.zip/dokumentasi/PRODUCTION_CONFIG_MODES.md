# 📁 CONFIG LOKAL vs HOSTING

Dokumentasi lengkap untuk switch antara mode lokal dan mode hosting.

---

## 🔴 MODE HOSTING (Untuk nanangkhasan.my.id)

**Simpan untuk nanti!**

### config.php - MODE HOSTING
```php
<?php
/**
 * KONFIGURASI DATABASE & APLIKASI
 * Website Portofolio Nanang Khasan Bisri
 * MODE: HOSTING (nanangkhasan.my.id)
 */

// Database Configuration - HOSTING
define('DB_HOST', 'localhost');
define('DB_USER', 'nanang');
define('DB_PASS', '');  // Ganti dengan password hosting Anda
define('DB_NAME', 'portofolio_db');

// Koneksi Database
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Set charset UTF-8
$conn->set_charset("utf8");

// ========== MODE HOSTING - HARDCODED ==========
define('BASE_URL', 'https://nanangkhasan.my.id/');
define('ASSETS_URL', 'https://nanangkhasan.my.id/assets/');
// =============================================

// Timezone
date_default_timezone_set('Asia/Jakarta');

// Session start
session_start();

// SECURITY HEADERS (sama untuk semua mode)
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://fonts.googleapis.com; style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com; img-src 'self' data: https:; connect-src 'self'");
header('Referrer-Policy: strict-origin-when-cross-origin');

// HTTPS Enforcement
$is_localhost = in_array($_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1', 'localhost:80']);
if (!$is_localhost && $_SERVER['SERVER_PORT'] != 443 && empty($_SERVER['HTTPS'])) {
    $redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('HTTP/1.1 301 Moved Permanently');
    header('Location: ' . $redirect);
    exit;
}

// RATE LIMITING
function checkRateLimit($identifier, $limit = 5, $window = 60) {
    $rate_limit_file = sys_get_temp_dir() . '/rate_limit_' . md5($identifier) . '.txt';
    $current_time = time();
    if (file_exists($rate_limit_file)) {
        $data = json_decode(file_get_contents($rate_limit_file), true);
        $request_times = $data['times'] ?? [];
        $request_times = array_filter($request_times, function($t) use ($current_time, $window) {
            return ($current_time - $t) < $window;
        });
        if (count($request_times) >= $limit) {
            return false;
        }
        $request_times[] = $current_time;
    } else {
        $request_times = [$current_time];
    }
    file_put_contents($rate_limit_file, json_encode(['times' => array_values($request_times)]));
    return true;
}

?>
```

---

## 🟢 MODE LOKAL (Sekarang Aktif)

**Untuk development di XAMPP lokal**

Config.php sudah auto-detect dan menggunakan:
```php
DB_HOST: localhost
DB_USER: root
DB_PASS: (kosong)
DB_NAME: portofolio_db

BASE_URL: Auto-detect ke http://localhost/webset 3.0.0/
ASSETS_URL: http://localhost/webset 3.0.0/assets/
```

---

## 🔄 Cara Switch Mode

### ✅ Switch ke MODE LOKAL (Sekarang)
✅ Sudah aktif! Config sudah auto-detect `localhost`

### 🔴 Switch ke MODE HOSTING (Nanti)
Ketika mau upload ke hosting:

**Opsi 1: Direct Edit config.php**
- Ubah `DB_USER` dari `root` ke `nanang`
- Ubah `DB_PASS` sesuai password hosting
- Ubah BASE_URL ke `https://nanangkhasan.my.id/`

**Opsi 2: Copy-Paste Code di Atas**
- Ganti seluruh isi config.php dengan "MODE HOSTING" code di atas
- Sesuaikan password dan database name kalau berbeda

---

## 📋 CHECKLIST Saat Switch ke HOSTING

- [ ] Update `DB_USER` ke `nanang` (atau username hosting Anda)
- [ ] Update `DB_PASS` dengan password yang benar
- [ ] Update `DB_NAME` kalau berbeda
- [ ] Update `BASE_URL` ke domain hosting
- [ ] Upload semua file ke hosting
- [ ] Clear browser cache
- [ ] Test di `https://nanangkhasan.my.id/`
- [ ] Test halaman lain (blog, portfolio, dll)
- [ ] Test admin login
- [ ] Monitor error log

---

## 🎯 Quick Reference

| Aspek | Lokal | Hosting |
|-------|-------|---------|
| **Host** | localhost | localhost |
| **User** | root | nanang |
| **Pass** | (kosong) | ??? |
| **DB Name** | portofolio_db | portofolio_db |
| **BASE_URL** | Auto-detect | https://nanangkhasan.my.id/ |
| **Mode** | Auto-detect | Hardcoded |

---

**Simpan dokumentasi ini untuk referensi!** 📌
