# 📚 PANDUAN LENGKAP PUBLIKASI WEBSET KE ANYHOST

Panduan step-by-step untuk mempublikasikan Portfolio CMS ke hosting Anyhost.

---

## 📋 DAFTAR ISI
1. [Persiapan & Login Hosting](#persiapan--login-hosting)
2. [Upload Database ke Anyhost](#upload-database-ke-anyhost)
3. [Membuat Database di Anyhost](#membuat-database-di-anyhost)
4. [Upload File Website](#upload-file-website)
5. [Konfigurasi Koneksi Database](#konfigurasi-koneksi-database)
6. [Testing & Troubleshooting](#testing--troubleshooting)

---

## 1️⃣ PERSIAPAN & LOGIN HOSTING

### A. Siapkan Data Berikut:
```
✓ Login Anyhost:
  - Email/Username hosting
  - Password hosting
  - Domain atau Subdomain

✓ File Website (dari folder: d:\XAMPP\htdocs\webset01\portfolio\)
  - Semua file PHP, HTML, CSS, JS
  - Folder: admin/, assets/, includes/, pages/
  - Database: portfolio_db.sql
```

### B. Login ke Anyhost:

1. Buka https://anyhost.id/ (atau sesuai domain Anyhost Anda)
2. Klik **Login** atau **Control Panel**
3. Masukkan **Email/Username** dan **Password**
4. Pilih **Domain/Hosting** yang ingin diupload

---

## 2️⃣ MEMBUAT DATABASE DI ANYHOST

### Step 1: Akses Database Management
1. Di Control Panel Anyhost, cari **Database** atau **MySQL Manager**
2. Klik **Create New Database** atau **Buat Database Baru**
3. Isi form:
   ```
   Database Name: portfolio_db
   Username: nanang_user (atau pilihan Anda)
   Password: [Buat password kuat, catat baik-baik!]
   ```
4. Klik **Create/Buat**

### Step 2: Catat Informasi Database
```
Host: localhost (biasanya)
Username: nanang_user
Password: [password yang Anda buat]
Database: portfolio_db
```

### Step 3: Import SQL File

#### Metode A: Gunakan phpMyAdmin
1. Di Control Panel Anyhost, buka **phpMyAdmin**
2. Login dengan username dan password database yang dibuat
3. Pilih database **portfolio_db** di sidebar kiri
4. Klik tab **Import**
5. Upload file **portfolio_db.sql** dari komputer Anda
6. Klik **Go** atau **Jalankan**
7. Tunggu sampai selesai (akan muncul pesan sukses)

#### Metode B: Menggunakan File Manager
1. Buka **File Manager** di Control Panel Anyhost
2. Navigate ke folder database atau setup
3. Upload file **portfolio_db.sql**
4. Jalankan melalui Terminal (jika tersedia)

---

## 3️⃣ UPLOAD FILE WEBSITE

### Step 1: Persiapkan File
Dari folder `d:\XAMPP\htdocs\webset01\portfolio\`, pastikan ada:
```
portfolio/
├── admin/
├── assets/
├── includes/
├── pages/
├── index.php
├── includes/config.php
└── [file PHP lainnya]
```

### Step 2: Upload ke Hosting

#### Menggunakan File Manager Anyhost:
1. Buka **File Manager** di Control Panel
2. Navigate ke folder **public_html** atau **www**
3. Buat folder baru bernama **portfolio** (atau nama domain Anda)
4. Upload semua folder dan file:
   - admin/
   - assets/
   - includes/
   - pages/
   - Semua file .php

#### Menggunakan FTP:
1. Download FTP Client seperti **FileZilla** atau **WinSCP**
2. Dapatkan FTP Credentials dari Control Panel:
   - FTP Host: ftp.yourdomain.com
   - FTP Username: [catat dari Anyhost]
   - FTP Password: [catat dari Anyhost]
   - FTP Port: 21 atau 22 (SSH)
3. Koneksikan ke server FTP
4. Upload folder **portfolio** ke **public_html/**

---

## 4️⃣ KONFIGURASI KONEKSI DATABASE

### Step 1: Edit File config.php

Buka file **includes/config.php** di Anyhost File Manager atau FTP:

```php
<?php
// Database Configuration

// LOCAL (XAMPP) - KOMENTARI INI
// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "portfolio_db";

// HOSTING ANYHOST - GUNAKAN INI
$servername = "localhost";           // Biasanya 'localhost' untuk shared hosting
$username = "nanang_user";           // Ganti dengan username DB dari Anyhost
$password = "password_anda";         // Ganti dengan password DB
$dbname = "portfolio_db";            // Nama database yang dibuat

// Create connection menggunakan MySQLi
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8
$conn->set_charset("utf8mb4");

// Define BASE URL
define('BASE_URL', 'https://yourdomain.com/portfolio/');  // Ganti dengan domain Anda

?>
```

### Step 2: Verifikasi Konfigurasi
1. Buka file ini via Text Editor di File Manager atau FTP
2. Pastikan informasi database benar
3. Ganti `yourdomain.com` dengan domain Anda
4. Save file

---

## 5️⃣ TESTING & VERIFIKASI

### Test 1: Akses Website
1. Buka browser
2. Ketik: `https://yourdomain.com/portfolio/`
3. Jika halaman home muncul, database berhasil terhubung ✓

### Test 2: Akses Admin Dashboard
1. Buka: `https://yourdomain.com/portfolio/admin/login.php`
2. Login dengan:
   - Username: `nanang`
   - Password: `admin123`
3. Jika berhasil login, database sudah terhubung ✓

### Test 3: Cek Database Connection
Buat file **test_db.php** di folder portfolio:

```php
<?php
require_once 'includes/config.php';

if ($conn->connect_error) {
    echo "❌ Koneksi Gagal: " . $conn->connect_error;
} else {
    echo "✓ Koneksi Berhasil ke Database!<br>";
    
    // Test query
    $result = $conn->query("SELECT COUNT(*) as total FROM portfolios");
    $row = $result->fetch_assoc();
    echo "✓ Total Portfolio: " . $row['total'] . "<br>";
}
?>
```

Akses: `https://yourdomain.com/portfolio/test_db.php`

---

## 🔧 TROUBLESHOOTING

### ❌ Error: "Connection failed"
**Solusi:**
1. Pastikan username dan password database benar
2. Hubungi Anyhost support untuk verifikasi
3. Cek di phpMyAdmin apakah user sudah dibuat

### ❌ Error: "mysqli_connect(): (HY000/2002): Can't connect to MySQL server"
**Solusi:**
1. Database host mungkin bukan 'localhost'
2. Minta info dari Anyhost support:
   - Database Host
   - Database Port (biasanya 3306)
3. Update config.php dengan host yang benar

### ❌ Error 404: File tidak ditemukan
**Solusi:**
1. Pastikan semua file sudah terupload
2. Cek struktur folder di hosting sama dengan lokal
3. Verifikasi path di File Manager

### ❌ Upload file gagal
**Solusi:**
1. Gunakan FTP daripada File Manager (lebih stabil)
2. Upload dalam batch, bukan sekaligus
3. Pastikan file permission sudah benar (644 untuk file, 755 untuk folder)

---

## 📝 CHECKLIST PUBLIKASI

```
Database Setup:
☐ Database "portfolio_db" sudah dibuat
☐ User database sudah dibuat
☐ SQL file sudah di-import
☐ Data sudah ada di phpMyAdmin

File Upload:
☐ Folder admin/ terupload
☐ Folder assets/ terupload
☐ Folder includes/ terupload
☐ Folder pages/ terupload
☐ Semua file .php terupload
☐ .htaccess terupload

Konfigurasi:
☐ includes/config.php sudah diedit
☐ Database credentials benar
☐ BASE_URL sudah diupdate

Testing:
☐ Halaman home bisa diakses
☐ Login admin berfungsi
☐ Database terhubung dengan baik
☐ All features working
```

---

## 📞 INFORMASI PENTING

### Credentials Anyhost:
```
Email/Username: [Catat di sini]
Password: [Catat di sini]
Domain: [Catat di sini]
```

### Database Credentials:
```
Host: localhost
Username: nanang_user
Password: [Password yang Anda buat]
Database: portfolio_db
```

### FTP Credentials (jika ada):
```
Host: ftp.yourdomain.com
Username: [Dari Anyhost]
Password: [Dari Anyhost]
Port: 21
```

---

## ✅ SELESAI!

Jika semua langkah berhasil, website Anda sudah **live** di Anyhost! 🎉

### Website Anda dapat diakses di:
- **Home:** https://yourdomain.com/portfolio/
- **Admin:** https://yourdomain.com/portfolio/admin/login.php
- **Portfolio:** https://yourdomain.com/portfolio/pages/portfolio.php
- **Blog:** https://yourdomain.com/portfolio/pages/blog.php
- **About:** https://yourdomain.com/portfolio/pages/about.php
- **Contact:** https://yourdomain.com/portfolio/pages/contact.php

---

## 🆘 BUTUH BANTUAN?

Jika ada error:
1. Catat error message yang muncul
2. Hubungi Support Anyhost dengan error message tersebut
3. Lampirkan screenshot
4. Mereka biasanya response cepat dan helpful

**Good luck! 🚀**
