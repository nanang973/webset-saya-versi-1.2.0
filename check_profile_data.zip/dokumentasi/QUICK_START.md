# ✅ QUICK START CHECKLIST

Checklist cepat untuk setup & launch portfolio website.

---

## 🚀 SETUP (15 MENIT)

### 1. Persiapan Files
- [ ] Copy folder `portfolio` ke `D:\XAMPP\htdocs\webset01\portfolio\`
- [ ] Pastikan struktur folder benar (ada admin/, pages/, assets/, includes/)
- [ ] Verifikasi file `portfolio_db.sql` ada di root

### 2. Database
- [ ] Start XAMPP (Apache + MySQL)
- [ ] Buka `http://localhost/phpmyadmin`
- [ ] Create database: `portfolio_db`
- [ ] Import `portfolio_db.sql`
- [ ] Verifikasi tabel-tabel sudah ada (9 tabel)

### 3. Konfigurasi
- [ ] Cek `includes/config.php` - pastikan DB credentials benar
- [ ] Verifikasi BASE_URL sesuai
- [ ] Test koneksi: buka `http://localhost/webset01/portfolio/`

### 4. Admin Setup
- [ ] Login ke admin: `http://localhost/webset01/portfolio/admin/`
- [ ] Username: `admin` | Password: `admin123`
- [ ] Verifikasi dashboard muncul
- [ ] **GANTI PASSWORD SEGERA!**

---

## 📝 CUSTOMIZATION (30 MENIT)

### Data Profil
- [ ] Update nama di `index.php` (hero section)
- [ ] Update profil bio di `pages/about.php`
- [ ] Update kontak di `pages/contact.php`
- [ ] Update social media links di `includes/footer.php`

### Content
- [ ] Tambah 3-5 artikel blog via admin
- [ ] Publish setidaknya 1 artikel
- [ ] Update skills di `pages/skills.php` (atau via admin nantinya)
- [ ] Upload portfolio projects (6-8 proyek)

### Styling
- [ ] Review warna theme (biru/ungu sudah bagus)
- [ ] Test responsiveness di mobile/tablet (F12)
- [ ] Update favicon (optional)

---

## ✨ CONTENT (1-2 JAM)

### Homepage
- [ ] Hero title
- [ ] Hero subtitle
- [ ] Hero description
- [ ] CTA buttons link benar

### About Page
- [ ] Lengkapi bio
- [ ] Pendidikan
- [ ] Organisasi experience

### Skills Page
- [ ] Minimal 8 skills
- [ ] Set proficiency level (0-100)
- [ ] Kategori skill jelas

### Portfolio Page
- [ ] Minimal 6 projects
- [ ] Kategori: IoT, Web, Business
- [ ] Tech tags lengkap
- [ ] Links ke project/GitHub (optional)

### Blog Page
- [ ] Minimal 3 articles
- [ ] Status: published
- [ ] Category filled
- [ ] Content meaningful

### Contact Page
- [ ] Email terisi
- [ ] WhatsApp link benar
- [ ] Lokasi update
- [ ] Social media links aktif

---

## 🔒 SECURITY (15 MENIT)

### Authentication
- [ ] Admin password sudah diganti (PENTING!)
- [ ] Test logout berfungsi
- [ ] Pastikan `/admin/` butuh login

### Database
- [ ] Backup database: `mysqldump -u root portfolio_db > backup.sql`
- [ ] Pastikan file `config.php` tidak terekspose (sudah di .gitignore)

### Sensitive Files
- [ ] Pastikan `.htaccess` melindungi file sensitif
- [ ] Test: akses `includes/config.php` langsung → should blocked/forbidden

---

## 🧪 TESTING (30 MENIT)

### Public Pages
- [ ] Homepage loading ✅
- [ ] About page accessible ✅
- [ ] Skills dengan progress bar ✅
- [ ] Portfolio dengan filter ✅
- [ ] Blog list muncul ✅
- [ ] Contact form submit ✅
- [ ] Footer links work ✅
- [ ] Navbar active state correct ✅

### Admin Panel
- [ ] Login form bekerja ✅
- [ ] Dashboard stats akurat ✅
- [ ] Blog CRUD semua fungsi ✅
- [ ] Logout work ✅
- [ ] Session timeout work ✅

### Mobile Responsive
- [ ] Hamburger menu work ✅
- [ ] All pages readable di mobile ✅
- [ ] Forms usable ✅
- [ ] Images scale correctly ✅

### Performance
- [ ] Homepage load < 2 detik ✅
- [ ] No console errors ✅
- [ ] Images optimized ✅

---

## 📚 DOCUMENTATION (10 MENIT)

- [ ] README.md - read & understand ✅
- [ ] INSTALLATION.md - complete ✅
- [ ] CUSTOMIZATION.md - bookmarked ✅
- [ ] File QUICK_START.md ini - completed ✅

---

## 🚀 DEPLOYMENT (Optional, untuk nanti)

Ketika siap untuk upload ke hosting:

- [ ] Test di localhost 100% done
- [ ] Backup database
- [ ] Backup files
- [ ] Choose hosting (Niagahoster, Hostinger, etc)
- [ ] Upload via FTP
- [ ] Create database di hosting
- [ ] Import database
- [ ] Update config.php (server info)
- [ ] Update BASE_URL
- [ ] Test website di live server
- [ ] Setup domain
- [ ] Setup SSL (HTTPS)
- [ ] Configure email notifications (optional)

---

## 📋 File Directory Structure

Verify struktur lengkap:

```
portfolio/
├── index.php ✅
├── portfolio_db.sql ✅
├── .htaccess ✅
│
├── includes/
│   ├── config.php ✅
│   ├── header.php ✅
│   └── footer.php ✅
│
├── pages/
│   ├── about.php ✅
│   ├── skills.php ✅
│   ├── portfolio.php ✅
│   ├── blog.php ✅
│   └── contact.php ✅
│
├── admin/
│   ├── index.php ✅
│   ├── login.php ✅
│   ├── dashboard.php ✅
│   ├── blog-posts.php ✅
│   ├── portfolio.php ✅
│   └── logout.php ✅
│
├── assets/
│   ├── css/
│   │   ├── style.css ✅
│   │   └── admin.css ✅
│   ├── js/
│   │   ├── main.js ✅
│   │   └── admin.js ✅
│   └── images/ (kosong)
│
├── README.md ✅
├── INSTALLATION.md ✅
├── CUSTOMIZATION.md ✅
└── QUICK_START.md ✅ (file ini)
```

---

## 🎯 Post-Launch Checklist

Setelah website live:

- [ ] Monitor error logs
- [ ] Backup database weekly
- [ ] Update content regularly (blog)
- [ ] Add more projects
- [ ] Collect visitor analytics
- [ ] Get feedback dari viewers
- [ ] Improve SEO
- [ ] Share dengan recruiter/employer
- [ ] Keep WordPress/CMS secure
- [ ] Monitor website uptime

---

## ⏱️ Time Estimate

| Task | Time |
|------|------|
| Setup & Database | 15 min |
| Customization | 30 min |
| Add Content | 60-120 min |
| Security | 15 min |
| Testing | 30 min |
| Documentation | 10 min |
| **TOTAL** | **160-210 min (3 jam)** |

---

## 🆘 Quick Fixes

### Website tidak loading?
1. Pastikan Apache & MySQL running
2. Cek folder path benar
3. Cek config.php

### Admin login gagal?
1. Pastikan MySQL running
2. Pastikan database imported
3. Cek username/password

### Halaman blank?
1. Enable error display di config.php
2. Check browser console (F12)
3. Check error log di XAMPP

### Database error?
1. Reimport portfolio_db.sql
2. Verify admin_users table ada
3. Check credentials di config.php

---

## 💬 Need Help?

Cek file dokumentasi:
1. **README.md** - Overview & features
2. **INSTALLATION.md** - Setup detail
3. **CUSTOMIZATION.md** - Personalisasi

---

## 🎉 You're Done!

Website portfolio Anda sudah siap digunakan!

**Next step:** Share ke recruiter, teman, dan gunakan untuk job hunting! 🚀

---

**Happy Coding & Best of Luck! 💪**
